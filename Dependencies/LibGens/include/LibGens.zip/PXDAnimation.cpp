//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "PXDAnimation.h"

#include <acl/decompression/decompress.h>
#include <acl/decompression/decompression_settings.h>

namespace LibGens {
	struct PXDACLWriter final : public acl::track_writer {
		vector<rtm::qvvf> &transforms;

		explicit PXDACLWriter(vector<rtm::qvvf> &t) : transforms(t) {}

		void RTM_SIMD_CALL write_rotation(uint32_t index, rtm::quatf_arg0 rotation) {
			transforms[index].rotation = rotation;
		}

		void RTM_SIMD_CALL write_translation(uint32_t index, rtm::vector4f_arg0 translation) {
			transforms[index].translation = translation;
		}

		void RTM_SIMD_CALL write_scale(uint32_t index, rtm::vector4f_arg0 scale) {
			transforms[index].scale = scale;
		}
	};

	static void readCompressedChunk(File *file, size_t chunk_offset, unsigned int expected_tracks, unsigned int expected_frames, vector<vector<PXDTransform>> &out_frames) {
		file->goToAddress(chunk_offset);
		unsigned int acl_chunk_size = 0;
		file->readInt32(&acl_chunk_size);

		file->goToAddress(chunk_offset);
		unsigned char *acl_buffer = new unsigned char[acl_chunk_size];
		file->read(acl_buffer, acl_chunk_size);

		acl::error_result acl_result;
		const acl::compressed_tracks *compressed_anim = acl::make_compressed_tracks(acl_buffer, &acl_result);

		acl::decompression_context<acl::default_transform_decompression_settings> context;
		if (!compressed_anim || !context.initialize(*compressed_anim)) {
			out_frames.clear();
			delete[] acl_buffer;
			return;
		}

		uint32_t track_count = compressed_anim->get_num_tracks();
		uint32_t frame_count = compressed_anim->get_num_samples_per_track();
		float sample_rate = compressed_anim->get_sample_rate();
		float duration = compressed_anim->get_duration();

		vector<rtm::qvvf> pose(track_count);
		PXDACLWriter writer(pose);

		out_frames.resize(frame_count);
		for (uint32_t f = 0; f < frame_count; f++) {
			float sample_time = rtm::scalar_min(float(f) / sample_rate, duration);
			context.seek(sample_time, acl::sample_rounding_policy::none);
			context.decompress_tracks(writer);

			out_frames[f].resize(track_count);
			for (uint32_t t = 0; t < track_count; t++) {
				float rx = rtm::quat_get_x(pose[t].rotation);
				float ry = rtm::quat_get_y(pose[t].rotation);
				float rz = rtm::quat_get_z(pose[t].rotation);
				float rw = rtm::quat_get_w(pose[t].rotation);
				float tx = rtm::vector_get_x(pose[t].translation);
				float ty = rtm::vector_get_y(pose[t].translation);
				float tz = rtm::vector_get_z(pose[t].translation);
				float bl = rtm::vector_get_w(pose[t].translation);
				float sx = rtm::vector_get_x(pose[t].scale);
				float sy = rtm::vector_get_y(pose[t].scale);
				float sz = rtm::vector_get_z(pose[t].scale);
				float sw = rtm::vector_get_w(pose[t].scale);
				out_frames[f][t].rotation = Quaternion(rw, rx, ry, rz);
				out_frames[f][t].position = Vector3(tx, ty, tz);
				out_frames[f][t].bone_length = bl;
				out_frames[f][t].scale = Vector3(sx, sy, sz);
				out_frames[f][t].scale_w = sw;
			}
		}

		delete[] acl_buffer;
	}

	static void readUncompressedChunk(File *file, size_t chunk_offset, unsigned int track_count, unsigned int frame_count, vector<PXDTrackKeyframes> &out_tracks) {
		const size_t data_start = LIBGENS_PXD_ANIMATION_DATA_START;

		out_tracks.resize(track_count);

		for (unsigned int t = 0; t < track_count; t++) {
			file->goToAddress(chunk_offset + t * 0x48);

			unsigned int loc_count = 0;
			file->readInt32(&loc_count);
			file->goToAddress(file->getCurrentAddress() + 4);
			unsigned int loc_frame_offset_raw = 0;
			file->readInt32(&loc_frame_offset_raw);
			size_t loc_frame_offset = loc_frame_offset_raw + data_start;
			file->goToAddress(file->getCurrentAddress() + 4);
			unsigned int loc_data_offset_raw = 0;
			file->readInt32(&loc_data_offset_raw);
			size_t loc_data_offset = loc_data_offset_raw + data_start;
			file->goToAddress(file->getCurrentAddress() + 4);

			unsigned int rot_count = 0;
			file->readInt32(&rot_count);
			file->goToAddress(file->getCurrentAddress() + 4);
			unsigned int rot_frame_offset_raw = 0;
			file->readInt32(&rot_frame_offset_raw);
			size_t rot_frame_offset = rot_frame_offset_raw + data_start;
			file->goToAddress(file->getCurrentAddress() + 4);
			unsigned int rot_data_offset_raw = 0;
			file->readInt32(&rot_data_offset_raw);
			size_t rot_data_offset = rot_data_offset_raw + data_start;
			file->goToAddress(file->getCurrentAddress() + 4);

			unsigned int scale_count = 0;
			file->readInt32(&scale_count);
			file->goToAddress(file->getCurrentAddress() + 4);
			unsigned int scale_frame_offset_raw = 0;
			file->readInt32(&scale_frame_offset_raw);
			size_t scale_frame_offset = scale_frame_offset_raw + data_start;
			file->goToAddress(file->getCurrentAddress() + 4);
			unsigned int scale_data_offset_raw = 0;
			file->readInt32(&scale_data_offset_raw);
			size_t scale_data_offset = scale_data_offset_raw + data_start;

			out_tracks[t].loc_frames.resize(loc_count);
			out_tracks[t].loc_values.resize(loc_count);
			for (unsigned int i = 0; i < loc_count; i++) {
				file->goToAddress(loc_frame_offset + i * 2);
				file->readInt16(&out_tracks[t].loc_frames[i]);
				file->goToAddress(loc_data_offset + i * 0x10);
				float x = 0, y = 0, z = 0;
				file->readFloat32(&x);
				file->readFloat32(&y);
				file->readFloat32(&z);
				out_tracks[t].loc_values[i] = Vector3(x, y, z);
			}

			out_tracks[t].rot_frames.resize(rot_count);
			out_tracks[t].rot_values.resize(rot_count);
			for (unsigned int i = 0; i < rot_count; i++) {
				file->goToAddress(rot_frame_offset + i * 2);
				file->readInt16(&out_tracks[t].rot_frames[i]);
				file->goToAddress(rot_data_offset + i * 0x10);
				float x = 0, y = 0, z = 0, w = 0;
				file->readFloat32(&x);
				file->readFloat32(&y);
				file->readFloat32(&z);
				file->readFloat32(&w);
				out_tracks[t].rot_values[i] = Quaternion(w, x, y, z);
			}

			out_tracks[t].scale_frames.resize(scale_count);
			out_tracks[t].scale_values.resize(scale_count);
			for (unsigned int i = 0; i < scale_count; i++) {
				file->goToAddress(scale_frame_offset + i * 2);
				file->readInt16(&out_tracks[t].scale_frames[i]);
				file->goToAddress(scale_data_offset + i * 0x10);
				float x = 0, y = 0, z = 0;
				file->readFloat32(&x);
				file->readFloat32(&y);
				file->readFloat32(&z);
				out_tracks[t].scale_values[i] = Vector3(x, y, z);
			}
		}
	}

	PXDAnimation::PXDAnimation() : is_additive(false), is_compressed(false), duration(0), frame_count(0), track_count(0), frame_rate(30.0f), has_root_motion(false) {
	}

	PXDAnimation::PXDAnimation(string filename) : is_additive(false), is_compressed(false), duration(0), frame_count(0), track_count(0), frame_rate(30.0f), has_root_motion(false) {
		File file(filename, LIBGENS_FILE_READ_BINARY);
		if (file.valid()) {
			name = File::nameFromFilenameNoExtension(filename);
			size_t dot_pos = name.find(".anm");
			if (dot_pos != string::npos) {
				name = name.substr(0, dot_pos);
			}
			read(&file);
			file.close();
		}
	}

	PXDAnimation::~PXDAnimation() {
	}

	void PXDAnimation::read(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_PXD_ANIMATION_ERROR_FILE);
			return;
		}

		const size_t data_start = LIBGENS_PXD_ANIMATION_DATA_START;

		unsigned int file_size = 0;
		file->goToAddress(8);
		file->readInt32(&file_size);

		file->goToAddress(data_start);
		char magic[5] = {};
		file->read(magic, 4);
		if (string(magic) != LIBGENS_PXD_ANIMATION_MAGIC) {
			Error::addMessage(Error::EXCEPTION, LIBGENS_PXD_ANIMATION_ERROR_MAGIC);
			return;
		}

		unsigned int version = 0;
		file->readInt32(&version);
		if (version != LIBGENS_PXD_ANIMATION_VERSION) {
			Error::addMessage(Error::EXCEPTION, LIBGENS_PXD_ANIMATION_ERROR_VERSION);
			return;
		}

		unsigned char flag_additive = 0;
		unsigned char flag_compressed = 0;
		file->readUChar(&flag_additive);
		file->readUChar(&flag_compressed);
		is_additive = (flag_additive == 1);
		is_compressed = (flag_compressed == 8);

		file->goToAddress(data_start + 0x18);
		file->readFloat32(&duration);
		file->readInt32(&frame_count);
		if (duration != 0.0f && frame_count > 1) {
			frame_rate = (float)(frame_count - 1) / duration;
		}
		else {
			frame_rate = 30.0f;
		}

		unsigned int track_count_low = 0;
		file->readInt32(&track_count_low);
		track_count = track_count_low;
		file->goToAddress(file->getCurrentAddress() + 4);

		unsigned int main_offset_low = 0;
		file->readInt32(&main_offset_low);
		file->goToAddress(file->getCurrentAddress() + 4);
		size_t main_offset = 0;
		if (main_offset_low) {
			main_offset = main_offset_low + data_start;
		}

		unsigned int root_offset_low = 0;
		file->readInt32(&root_offset_low);
		file->goToAddress(file->getCurrentAddress() + 4);
		size_t root_offset = 0;
		if (root_offset_low) {
			root_offset = root_offset_low + data_start;
		}

		if (root_offset > (file_size - data_start) || root_offset == 0) {
			root_offset = 0;
		}

		has_root_motion = (root_offset != 0);

		if (is_compressed) {
			if (main_offset) {
				readCompressedChunk(file, main_offset, track_count, frame_count, compressed_frames);
			}
			if (root_offset) {
				readCompressedChunk(file, root_offset, 1, frame_count, root_frames);
			}
		}
		else {
			if (main_offset) {
				readUncompressedChunk(file, main_offset, track_count, frame_count, uncompressed_tracks);
			}
			if (root_offset) {
				readUncompressedChunk(file, root_offset, 1, frame_count, uncompressed_root_tracks);
			}
		}
	}

	string PXDAnimation::getName() {
		return name;
	}

	void PXDAnimation::setName(string v) {
		name = v;
	}

	bool PXDAnimation::getIsAdditive() {
		return is_additive;
	}

	bool PXDAnimation::getIsCompressed() {
		return is_compressed;
	}

	float PXDAnimation::getDuration() {
		return duration;
	}

	unsigned int PXDAnimation::getFrameCount() {
		return frame_count;
	}

	unsigned int PXDAnimation::getTrackCount() {
		return track_count;
	}

	float PXDAnimation::getFrameRate() {
		return frame_rate;
	}

	bool PXDAnimation::getHasRootMotion() {
		return has_root_motion;
	}

	vector<vector<PXDTransform>> &PXDAnimation::getCompressedFrames() {
		return compressed_frames;
	}

	vector<vector<PXDTransform>> &PXDAnimation::getRootFrames() {
		return root_frames;
	}

	vector<PXDTrackKeyframes> &PXDAnimation::getUncompressedTracks() {
		return uncompressed_tracks;
	}

	vector<PXDTrackKeyframes> &PXDAnimation::getUncompressedRootTracks() {
		return uncompressed_root_tracks;
	}
};
