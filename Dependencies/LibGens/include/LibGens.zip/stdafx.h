//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

using namespace std;

#ifdef _M_X64
// Prevent std::byte conflict with Windows byte typedef
#define byte windows_byte_t
#include <Windows.h>
#undef byte
typedef unsigned char byte;

#include <stack>
#include <list>
#include <set>
#include <iterator>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <ctype.h>

#define XXH_STATIC_LINKING_ONLY
#include "xxhash/xxhash.h"
#include "tinyxml/tinyxml.h"
#include "meshoptimizer/meshoptimizer.h"
#include "MathGens.h"
#include "Error.h"
#include "Endian.h"
#include "File.h"

#else

#define byte windows_byte_t
#include <Windows.h>
#undef byte
typedef unsigned char byte;

#include <stack>
#include <list>
#include <set>
#include <iterator>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <ctype.h>

// Common Headers only should be pre-compiled
#define XXH_STATIC_LINKING_ONLY
#include "xxhash/xxhash.h"
#include "tinyxml/tinyxml.h"
#include "meshoptimizer/meshoptimizer.h"
#include "MathGens.h"
#include "Error.h"
#include "Endian.h"
#include "File.h"

#endif // !_M_X64