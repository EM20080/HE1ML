//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "Bone.h"
#include "Mesh.h"
#include "Model.h"
#include "MorphModel.h"
#include "Submesh.h"
#include "TerrainGroup.h"
#include "Vertex.h"
#include "VertexFormat.h"
#include "SampleChunkNode.h"
#include "SampleChunkProperty.h"

namespace LibGens {
	Model::Model() {
		meshes.clear();
		bones.clear();
		properties.clear();
		name="";
		filename="";
		terrain_mode = false;
		has_instances = true;
		topology=TRIANGLE_STRIP;
	}

	Model::Model(string filename_p) {
		File file(filename_p, LIBGENS_FILE_READ_BINARY);
		filename=filename_p;
		
		name = filename;
		size_t sep = name.find_last_of("\\/");
		if (sep != std::string::npos) {
			name = name.substr(sep + 1, name.size() - sep - 1);
		}
	
		size_t dot = name.find_last_of(".");
		if (dot != string::npos) {
			name = name.substr(0, dot);
		}

		terrain_mode = (filename.find(LIBGENS_TERRAIN_MODEL_EXTENSION) != string::npos);
		topology = TRIANGLE_STRIP;

		if (file.valid()) {
			file.readHeader();
			read(&file);
			file.close();
		}
	}

	Model::Model(File *file, bool terrain_mode_p) {
		if (!file) return;

		terrain_mode = terrain_mode_p;
		topology = TRIANGLE_STRIP;

		file->readHeader();
		read(file);
	}

	void Model::read(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_MODEL_ERROR_MESSAGE_NULL_FILE);
			return;
		}

		if (file->getRootNodeType() == LIBGENS_FILE_HEADER_ROOT_TYPE_LOST_WORLD) {
			readSampleChunkHeader(file);
			return;
		}

		size_t header_address = file->getCurrentAddress();

		if (file->getRootNodeType() >= 1000) {
			Error::addMessage(Error::EXCEPTION, LIBGENS_MODEL_ERROR_PS3_HEADER);
			return;
		}
		else if (file->getRootNodeType() >= 5) {
			unsigned int mesh_count = 0;
			size_t mesh_table_address = 0;

			file->readInt32BE(&mesh_count);
			file->readInt32BEA(&mesh_table_address);

			meshes.reserve(mesh_count);
			for (size_t i = 0; i < mesh_count; i++) {
				size_t mesh_address = 0;
				file->goToAddress(mesh_table_address + i * file->getAddressSize());
				file->readInt32BEA(&mesh_address);
				file->goToAddress(mesh_address);

				Mesh* mesh = new Mesh();
				mesh->read(file, topology);
				mesh->buildAABB();
				meshes.push_back(mesh);
			}

			file->goToAddress(header_address + 2 * file->getAddressSize());
		}
		else {
			Mesh* mesh = new Mesh();
			mesh->read(file, topology);
			mesh->buildAABB();
			meshes.push_back(mesh);

			file->goToAddress(header_address + 6 * file->getAddressSize());
		}

		if (!terrain_mode) {
			readSkeleton(file);
		}
		else 
		{
			if (file->getRootNodeType() >= 5) {
				size_t mesh_name_address = 0;

				file->readInt32BEA(&mesh_name_address);
				if (!file->get64BitAddressMode()) {
					file->readInt32BE(&has_instances);
				}

				// Read Name
				file->goToAddress(mesh_name_address);
				file->readString(&name);
			}

			buildAABB();
		}
	}

	void Model::readSkeleton(File* file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_MODEL_ERROR_MESSAGE_NULL_FILE);
			return;
		}

		size_t header_address = file->getCurrentAddress();

		unsigned int morph_model_count = 0;
		size_t morph_models_address = 0;

		if (file->getRootNodeType() >= 4) {
			file->readInt32BE(&morph_model_count);
			file->readInt32BEA(&morph_models_address);
		}

		unsigned int bone_total = 0;
		size_t bone_definition_table_address = 0;
		size_t bone_matrix_address = 0;
		size_t global_aabb_address = 0;

		file->readInt32BE(&bone_total);
		file->readInt32BEA(&bone_definition_table_address);
		file->readInt32BEA(&bone_matrix_address);

		if (file->getRootNodeType() >= 2) {
			file->readInt32BEA(&global_aabb_address);
		}

		if (file->getRootNodeType() >= 4) {
			for (size_t i = 0; i < morph_model_count; i++) {
				file->goToAddress(morph_models_address + i * file->getAddressSize());
				size_t address = 0;
				file->readInt32BEA(&address);
				file->goToAddress(address);

				MorphModel* morph_model = new MorphModel();
				morph_model->read(file, topology);
				morph_models.push_back(morph_model);
			}
		}

		bones.reserve(bone_total);
		for (size_t i = 0; i < bone_total; i++) {
			file->goToAddress(bone_definition_table_address + i * file->getAddressSize());
			size_t address = 0;
			file->readInt32BEA(&address);
			file->goToAddress(address);

			Bone* bone = new Bone();
			bone->readDescription(file);
			file->goToAddress(bone_matrix_address + i * 64);
			bone->readMatrix(file);
			bones.push_back(bone);
		}

		if (file->getRootNodeType() >= 2) {
			file->goToAddress(global_aabb_address);
			global_aabb.read(file);
		}
		else {
			buildAABB();
		}
	}
	
	void Model::readSampleChunkHeader(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_MODEL_ERROR_MESSAGE_NULL_FILE);
			return;
		}

		SampleChunkNode root_node;
		root_node.read(file);

		SampleChunkNode *property_node = root_node.find("SCAParam");
		if (property_node) {
			vector<SampleChunkNode *> property_nodes = property_node->getNodes();
			for (vector<SampleChunkNode *>::iterator it = property_nodes.begin(); it != property_nodes.end(); it++) {
				properties.push_back(new SampleChunkProperty(*it));
			}
		}

		SampleChunkNode* topology_node = root_node.find("Topology");
		if (topology_node) {
			topology = (Topology)topology_node->getValue();
		}

		SampleChunkNode *contexts_node = root_node.find("Contexts", false);
		if (contexts_node) {
			file->setRootNodeType(max(contexts_node->getValue(), 5u));
			file->goToAddress(contexts_node->getDataAddress());
			read(file);
			file->setRootNodeType(LIBGENS_FILE_HEADER_ROOT_TYPE_LOST_WORLD);
		}
	}

	void Model::save(string filename_p, int root_type) {
		if ((root_type == LIBGENS_MODEL_ROOT_DYNAMIC_FORCES) || (root_type == LIBGENS_MODEL_ROOT_DYNAMIC_SHADOW_RAW)) {
			File file(filename_p, LIBGENS_FILE_WRITE_BINARY);

			if (file.valid()) {
				int data_root_type = (bones.size() > 256) ? LIBGENS_MODEL_ROOT_DYNAMIC_HE2_2 : LIBGENS_MODEL_ROOT_DYNAMIC_GENERATIONS;
				Topology old_topology = topology;
				topology = (root_type == LIBGENS_MODEL_ROOT_DYNAMIC_SHADOW_RAW) ? TRIANGLE_LIST : TRIANGLE_STRIP;
				file.prepareHeader(LIBGENS_FILE_HEADER_ROOT_TYPE_LOST_WORLD);
				writeSampleChunkHeader(&file, data_root_type, LIBGENS_MODEL_SAMPLE_CHUNK_HE2);
				file.fixPadding(16);
				file.writeHeader(true);
				file.close();
				topology = old_topology;
			}

			return;
		}

		if ((root_type == LIBGENS_MODEL_ROOT_DYNAMIC_FRONTIERS) || (root_type == LIBGENS_MODEL_ROOT_DYNAMIC_SHADOW)) {
			vector<Model *> lod_models;
			vector<unsigned char> lod_cascades;
			vector<float> lod_distances;
			lod_models.push_back(this);
			lod_cascades.push_back(31);
			lod_distances.push_back(-1.0f);
			save(filename_p, lod_models, lod_cascades, lod_distances, root_type);
			return;
		}

		File file(filename_p, LIBGENS_FILE_WRITE_BINARY);

		if (file.valid()) {
			file.prepareHeader(root_type == LIBGENS_MODEL_ROOT_DYNAMIC_GENERATIONS_2024 ? LIBGENS_MODEL_ROOT_DYNAMIC_GENERATIONS : root_type);
			vector<Submesh *> changed_submeshes;
			vector<VertexFormat *> old_vertex_formats;

			if (root_type == LIBGENS_MODEL_ROOT_DYNAMIC_GENERATIONS_2024) {
				file.set64BitAddressMode(true);
				for (vector<Mesh *>::iterator it = meshes.begin(); it != meshes.end(); it++) {
					for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
						vector<Submesh *> submeshes = (*it)->getSubmeshes(slot);
						for (vector<Submesh *>::iterator submesh = submeshes.begin(); submesh != submeshes.end(); submesh++) {
							VertexFormat *vertex_format = (*submesh)->getVertexFormat();
							if (vertex_format) {
								changed_submeshes.push_back(*submesh);
								old_vertex_formats.push_back(new VertexFormat(vertex_format));
							}
						}
					}
				}
				changeVertexFormat(terrain_mode ? LIBGENS_VERTEX_FORMAT_GENERATIONS_2024_TERRAIN : LIBGENS_VERTEX_FORMAT_GENERATIONS_2024);
			}

			write(&file);

			for (size_t i = 0; i < changed_submeshes.size(); i++) {
				changed_submeshes[i]->setVertexFormat(old_vertex_formats[i]);
				delete old_vertex_formats[i];
			}

			file.writeHeader(true);
			file.close();
		}
	}

	void Model::save(string filename_p, vector<Model *> lod_models, vector<unsigned char> lod_cascades, vector<float> lod_distances, int root_type) {
		if ((root_type != LIBGENS_MODEL_ROOT_DYNAMIC_FORCES) && (root_type != LIBGENS_MODEL_ROOT_DYNAMIC_FRONTIERS) && (root_type != LIBGENS_MODEL_ROOT_DYNAMIC_SHADOW)) {
			save(filename_p, root_type);
			return;
		}

		if (!lod_models.size()) {
			lod_models.push_back(this);
			lod_cascades.push_back(31);
			lod_distances.push_back(-1.0f);
		}

		while (lod_cascades.size() < lod_models.size()) {
			lod_cascades.push_back(31);
		}

		while (lod_distances.size() < lod_models.size()) {
			lod_distances.push_back(-1.0f);
		}

		size_t lod_count = lod_models.size();
		if (lod_count > 32) {
			lod_count = 32;
		}

		vector<size_t> lod_order;
		for (size_t i = 0; i < lod_count; i++) {
			lod_order.push_back(i);
		}

		std::sort(lod_order.begin(), lod_order.end(), [&](size_t a, size_t b) {
			return lod_cascades[a] < lod_cascades[b];
		});

		vector< vector<unsigned char> > resource_datas;
		for (size_t i = 0; i < lod_count; i++) {
			Model *model = lod_models[lod_order[i]];
			int data_root_type = (model->bones.size() > 256) ? LIBGENS_MODEL_ROOT_DYNAMIC_HE2_2 : LIBGENS_MODEL_ROOT_DYNAMIC_GENERATIONS;
			Topology old_topology = model->topology;
			model->topology = ((root_type == LIBGENS_MODEL_ROOT_DYNAMIC_FRONTIERS) || (root_type == LIBGENS_MODEL_ROOT_DYNAMIC_SHADOW)) ? TRIANGLE_LIST : TRIANGLE_STRIP;
			File resource_file;
			resource_file.writeNull(16);
			resource_file.setRootNodeAddress(16);
			resource_file.setRootNodeType(LIBGENS_FILE_HEADER_ROOT_TYPE_LOST_WORLD);
			model->writeSampleChunkHeader(&resource_file, data_root_type, LIBGENS_MODEL_SAMPLE_CHUNK_HE2);
			resource_file.fixPadding(16);

			size_t offset_table_address = resource_file.getCurrentAddress();
			resource_file.sortAddressTable();
			list<size_t> offset_table = resource_file.getAddressTable();

			for (list<size_t>::iterator it = offset_table.begin(); it != offset_table.end(); it++) {
				unsigned int offset = (unsigned int)*it;
				resource_file.writeInt32BE(&offset);
			}

			size_t resource_size = resource_file.getFileSize();
			unsigned int root_size = (unsigned int)resource_size | 0x80000000u;
			unsigned int root_signature = LIBGENS_FILE_HEADER_ROOT_TYPE_LOST_WORLD;
			unsigned int root_offset_table_address = (unsigned int)(offset_table_address - 16);
			unsigned int root_offset_table_size = (unsigned int)offset_table.size();

			resource_file.goToAddress(0);
			resource_file.writeInt32BE(&root_size);
			resource_file.writeInt32BE(&root_signature);
			resource_file.writeInt32BE(&root_offset_table_address);
			resource_file.writeInt32BE(&root_offset_table_size);

			vector<unsigned char> resource_data = resource_file.detach();
			for (list<size_t>::iterator it = offset_table.begin(); it != offset_table.end(); it++) {
				size_t address = 16 + *it;
				if ((address + 4) <= resource_data.size()) {
					unsigned int real_offset = ((unsigned int)resource_data[address] << 24) | ((unsigned int)resource_data[address + 1] << 16) | ((unsigned int)resource_data[address + 2] << 8) | resource_data[address + 3];
					int relative_offset = (int)(real_offset - (unsigned int)address + 16);

					resource_data[address] = (unsigned char)(relative_offset & 0xFF);
					resource_data[address + 1] = (unsigned char)((relative_offset >> 8) & 0xFF);
					resource_data[address + 2] = (unsigned char)((relative_offset >> 16) & 0xFF);
					resource_data[address + 3] = (unsigned char)((relative_offset >> 24) & 0xFF);
				}
			}

			resource_datas.push_back(resource_data);
			model->topology = old_topology;
		}

		File file(filename_p, LIBGENS_FILE_WRITE_BINARY);
		if (!file.valid()) {
			return;
		}

		unsigned char ch = 0;

		file.writeString("NEDARC");
		ch = 'V';
		file.writeUChar(&ch);
		ch = '1';
		file.writeUChar(&ch);

		size_t archive_size_address = file.getCurrentAddress();
		file.writeNull(4);
		file.writeString("arc");
		ch = 0;
		file.writeUChar(&ch);
		file.fixPadding();

		file.writeString("NEDLDI");
		ch = 'V';
		file.writeUChar(&ch);
		ch = '1';
		file.writeUChar(&ch);
		file.writeString("lodinfo");
		ch = 0;
		file.writeUChar(&ch);
		file.fixPadding();

		size_t lod_size_address = file.getCurrentAddress();
		file.writeNull(4);
		size_t lod_data_address = file.getCurrentAddress();
		ch = 4;
		if (lod_cascades[lod_order[lod_count - 1]] != 31) {
			ch |= 0x80;
		}
		file.writeUChar(&ch);
		ch = (unsigned char)lod_count;
		file.writeUChar(&ch);
		file.fixPadding();

		for (size_t i = 0; i < lod_count; i++) {
			unsigned char cascade = lod_cascades[lod_order[i]];
			if (cascade > 31) {
				cascade = 31;
			}

			unsigned int cascade_flag = 1u << cascade;
			file.writeInt32BE(&cascade_flag);
		}
		file.writeNull((32 - lod_count) * 4);

		for (size_t i = 0; i < lod_count; i++) {
			float lod_distance = lod_distances[lod_order[i]];
			file.writeFloat32BE(&lod_distance);
		}
		file.writeNull((32 - lod_count) * 4);

		for (size_t i = 0; i < lod_count; i++) {
			ch = lod_cascades[lod_order[i]];
			if (ch > 31) {
				ch = 31;
			}

			file.writeUChar(&ch);
		}
		file.writeNull(32 - lod_count);
		file.fixPadding();

		unsigned int lod_size = (unsigned int)(file.getCurrentAddress() - lod_data_address);
		file.goToAddress(lod_size_address);
		file.writeInt32BE(&lod_size);
		file.goToEnd();

		for (size_t i = 0; i < lod_count; i++) {
			file.writeString("NEDMDL");
			ch = 'V';
			file.writeUChar(&ch);
			ch = '5';
			file.writeUChar(&ch);
			file.writeString("model");
			ch = 0;
			file.writeUChar(&ch);
			file.fixPadding();

			size_t model_size_address = file.getCurrentAddress();
			file.writeNull(4);
			size_t model_data_address = file.getCurrentAddress();
			file.write(resource_datas[i].data(), resource_datas[i].size());
			file.fixPadding();

			unsigned int model_size = (unsigned int)(file.getCurrentAddress() - model_data_address);
			file.goToAddress(model_size_address);
			file.writeInt32BE(&model_size);
			file.goToEnd();
		}

		unsigned int archive_size = (unsigned int)(file.getCurrentAddress() - archive_size_address);
		file.goToAddress(archive_size_address);
		file.writeInt32BE(&archive_size);
		file.close();
	}

	void Model::write(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_MODEL_ERROR_MESSAGE_WRITE_NULL_FILE);
			return;
		}

		if (file->getRootNodeType() == LIBGENS_FILE_HEADER_ROOT_TYPE_LOST_WORLD) {
			writeSampleChunkHeader(file);
			return;
		}

		if ((file->getRootNodeType() == LIBGENS_MODEL_ROOT_DYNAMIC_GENERATIONS) && file->get64BitAddressMode()) {
			writeGenerations2024(file);
			return;
		}

		size_t table_address = file->getCurrentAddress();
		size_t address_size = file->getAddressSize();
		unsigned int mesh_count = meshes.size();
		size_t model_table_address = 0;
		size_t model_name_address = 0;
		size_t model_table_slot_address = 0;
		size_t model_name_slot_address = 0;

		size_t morph_models_address = 0;
		unsigned int morph_model_count = morph_models.size();
		unsigned int bone_count = bones.size();
		size_t bone_definition_table_address = 0;
		size_t bone_matrix_address = 0;
		size_t global_aabb_address = 0;
		size_t morph_models_slot_address = 0;
		size_t bone_definition_table_slot_address = 0;
		size_t bone_matrix_slot_address = 0;
		size_t global_aabb_slot_address = 0;
		size_t end_slot_address = 0;

		if (file->getRootNodeType() >= 5) {
			file->writeInt32BE(&mesh_count);
			model_table_slot_address = file->writeNullAddress();
		}
		else {
			file->writeNull(24);
		}

		if (!terrain_mode) {
			if (file->getRootNodeType() >= 4) {
				file->writeInt32BE(&morph_model_count);
				morph_models_slot_address = file->writeNullAddress();
			}

			file->writeInt32BE(&bone_count);
			bone_definition_table_slot_address = file->writeNullAddress();
			bone_matrix_slot_address = file->writeNullAddress();

			if (file->getRootNodeType() >= 2) {
				global_aabb_slot_address = file->writeNullAddress();

				if (file->getRootNodeType() == 2) {
					end_slot_address = file->writeNullAddress();
				}
			}
		}

		if (file->getRootNodeType() >= 5) {
			if (terrain_mode) {
				model_name_slot_address = file->writeNullAddress();
				if (!file->get64BitAddressMode()) {
					file->writeInt32BE(&has_instances);
				}
			}

			vector<size_t> mesh_addresses;
			model_table_address = file->writeNullAddressTable(mesh_count);

			for (size_t i = 0; i < mesh_count; i++) {
				if (file->get64BitAddressMode()) file->fixPadding(8);
				mesh_addresses.push_back(file->getCurrentAddress());
				meshes[i]->write(file, topology);
			}

			file->goToAddress(model_table_address);
			for (size_t i = 0; i < mesh_count; i++) {
				file->goToAddress(model_table_address + i * address_size);
				file->writeInt32BEA(&mesh_addresses[i]);
			}
		}
		else if (!meshes.empty()) {
			file->goToAddress(table_address);
			meshes[0]->write(file, topology);
		}

		file->goToEnd();
		file->fixPadding();

		if (!terrain_mode) {
			if (file->getRootNodeType() >= 4) {
				vector<size_t> morph_model_addresses;
				if (morph_model_count) {
					morph_models_address = file->writeNullAddressTable(morph_model_count);
				}

				for (size_t i = 0; i < morph_model_count; i++) {
					morph_model_addresses.push_back(file->getCurrentAddress());
					morph_models[i]->write(file, topology);
				}

				for (size_t i = 0; i < morph_model_count; i++) {
					file->goToAddress(morph_models_address + i * address_size);
					file->writeInt32BEA(&morph_model_addresses[i]);
				}
				file->goToEnd();
			}

			vector<size_t> bone_definition_addresses;
			bone_definition_table_address = file->writeNullAddressTable(bone_count);

			for (size_t i = 0; i < bone_count; i++) {
				bone_definition_addresses.push_back(file->getCurrentAddress());
				bones[i]->writeDescription(file);
			}

			for (size_t i = 0; i < bone_count; i++) {
				file->goToAddress(bone_definition_table_address + i * address_size);
				file->writeInt32BEA(&bone_definition_addresses[i]);
			}
			file->goToEnd();

			bone_matrix_address = file->getCurrentAddress();
			Matrix4 he2_orientation_matrix;
			he2_orientation_matrix.m[1][1] = 0.0f;
			he2_orientation_matrix.m[1][2] = 1.0f;
			he2_orientation_matrix.m[2][1] = -1.0f;
			he2_orientation_matrix.m[2][2] = 0.0f;

			for (size_t i = 0; i < bone_count; i++) {
				if (topology == TRIANGLE_LIST) {
					Matrix4 matrix = he2_orientation_matrix * bones[i]->getMatrix();
					matrix.write(file);
				}
				else {
					bones[i]->writeMatrix(file);
				}
			}

			if (file->getRootNodeType() >= 2) {
				global_aabb_address = file->getCurrentAddress();
				global_aabb.write(file);
			}
		}
		else if (file->getRootNodeType() >= 5) {
			model_name_address = file->getCurrentAddress();
			file->writeString(&name);
			file->fixPadding();
		}

		if (file->getRootNodeType() >= 5) {
			file->goToAddress(model_table_slot_address);
			file->writeInt32BEA(&model_table_address);
		}
		else {
			file->goToAddress(table_address + 24);
		}

		if (!terrain_mode) {
			if (file->getRootNodeType() >= 4) {
				if (morph_model_count) {
					file->goToAddress(morph_models_slot_address);
					file->writeInt32BEA(&morph_models_address);
				}
			}

			file->goToAddress(bone_definition_table_slot_address);
			file->writeInt32BEA(&bone_definition_table_address);
			file->goToAddress(bone_matrix_slot_address);
			file->writeInt32BEA(&bone_matrix_address);

			if (file->getRootNodeType() >= 2) {
				file->goToAddress(global_aabb_slot_address);
				file->writeInt32BEA(&global_aabb_address);

				if (file->getRootNodeType() == 2) {
					size_t end_address = global_aabb_address + 24;
					file->goToAddress(end_slot_address);
					file->writeInt32BEA(&end_address);
				}
			}
		}
		else if (file->getRootNodeType() >= 5) {
			file->goToAddress(model_name_slot_address);
			file->writeInt32BEA(&model_name_address);
		}

		file->goToEnd();
	}

	void Model::writeGenerations2024(File *file) {
		struct TextureInfo {
			size_t record_address;
			size_t name_slot_address;
			size_t name_address;
			string name;
			unsigned int id;
		};

		struct SubmeshInfo {
			Submesh *submesh;
			size_t header_address;
			size_t material_slot_address;
			size_t material_address;
			size_t faces_count;
			size_t faces_address;
			size_t faces_slot_address;
			size_t vertices_count;
			size_t vertex_size;
			size_t vertices_address;
			size_t vertices_slot_address;
			size_t vertex_format_address;
			size_t vertex_format_slot_address;
			size_t bone_count;
			size_t bones_address;
			size_t bones_slot_address;
			size_t texture_table_address;
			size_t texture_table_slot_address;
			vector<TextureInfo> textures;
		};

		struct MeshInfo {
			Mesh *mesh;
			size_t header_address;
			size_t table_address[LIBGENS_MODEL_SUBMESH_SLOTS];
			size_t table_slot_address[LIBGENS_MODEL_SUBMESH_SLOTS];
			size_t water_total_header_slot_address;
			size_t water_table_header_slot_address;
			size_t water_string_slot_address;
			size_t water_total_slot_address;
			size_t water_table_slot_address;
			size_t water_string_address;
			size_t water_total_address;
			size_t water_table_address;
			vector<SubmeshInfo> submeshes[LIBGENS_MODEL_SUBMESH_SLOTS];
		};

		size_t address_size = file->getAddressSize();
		size_t root_address = file->getCurrentAddress();
		unsigned int mesh_count = meshes.size();
		unsigned int bone_count = bones.size();
		size_t mesh_table_slot_address = 0;
		size_t morph_table_slot_address = 0;
		size_t bone_definition_table_slot_address = 0;
		size_t bone_matrix_slot_address = 0;
		size_t global_aabb_slot_address = 0;
		size_t model_name_slot_address = 0;
		size_t mesh_table_address = 0;
		size_t bone_definition_table_address = 0;
		size_t bone_matrix_address = 0;
		size_t global_aabb_address = 0;
		size_t model_name_address = 0;
		vector<size_t> mesh_addresses;
		vector<size_t> bone_definition_addresses;
		vector<size_t> bone_name_slot_addresses;
		vector<size_t> bone_name_addresses;
		vector<MeshInfo> mesh_infos;

		file->writeInt32BE(&mesh_count);
		mesh_table_slot_address = file->writeNullAddress();

		if (!terrain_mode) {
			unsigned int morph_count = morph_models.size();
			file->writeInt32BE(&morph_count);
			morph_table_slot_address = file->writeNullAddress();
			file->writeInt32BE(&bone_count);
			bone_definition_table_slot_address = file->writeNullAddress();
			bone_matrix_slot_address = file->writeNullAddress();
			global_aabb_slot_address = file->writeNullAddress();

			bone_matrix_address = file->getCurrentAddress();
			for (size_t i = 0; i < bone_count; i++) {
				bones[i]->writeMatrix(file);
			}

			global_aabb_address = file->getCurrentAddress();
			global_aabb.write(file);
		}
		else {
			model_name_slot_address = file->writeNullAddress();
		}

		mesh_infos.reserve(mesh_count);
		for (size_t mesh_index = 0; mesh_index < mesh_count; mesh_index++) {
			MeshInfo mesh_info = {};
			mesh_info.mesh = meshes[mesh_index];

			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				vector<Submesh *> submeshes = mesh_info.mesh->getSubmeshes(slot);
				mesh_info.submeshes[slot].reserve(submeshes.size());

				for (vector<Submesh *>::iterator it = submeshes.begin(); it != submeshes.end(); it++) {
					SubmeshInfo submesh_info = {};
					submesh_info.submesh = *it;
					vector<unsigned short> faces = submesh_info.submesh->getFacesIndices();
					vector<Polygon> face_polygons = submesh_info.submesh->getFaces();
					vector<Vertex *> vertices = submesh_info.submesh->getVertices();
					vector<unsigned short> bone_table = submesh_info.submesh->getBoneTable();
					vector<string> texture_units = submesh_info.submesh->getTextureUnits();
					vector<unsigned int> texture_ids = submesh_info.submesh->getTextureIDs();
					VertexFormat *vertex_format = submesh_info.submesh->getVertexFormat();

					submesh_info.faces_count = (topology == TRIANGLE_LIST) ? face_polygons.size() * 3 : faces.size();
					submesh_info.vertices_count = vertices.size();
					submesh_info.vertex_size = vertex_format ? vertex_format->getSize() : 0;
					submesh_info.bone_count = bone_table.size();

					submesh_info.faces_address = file->getCurrentAddress();
					if (topology == TRIANGLE_LIST) {
						for (size_t i = 0; i < face_polygons.size(); i++) {
							file->writeInt16BE(&face_polygons[i].c);
							file->writeInt16BE(&face_polygons[i].b);
							file->writeInt16BE(&face_polygons[i].a);
						}
					}
					else {
						for (size_t i = 0; i < faces.size(); i++) {
							file->writeInt16BE(&faces[i]);
						}
					}
					file->fixPadding();

					submesh_info.vertices_address = file->getCurrentAddress();
					for (vector<Vertex *>::iterator vertex = vertices.begin(); vertex != vertices.end(); vertex++) {
						(*vertex)->write(file, vertex_format);
					}

					submesh_info.vertex_format_address = file->getCurrentAddress();
					if (vertex_format) vertex_format->write(file);

					submesh_info.bones_address = file->getCurrentAddress();
					for (size_t i = 0; i < bone_table.size(); i++) {
						if (file->getRootNodeType() >= LIBGENS_MODEL_ROOT_DYNAMIC_HE2_2) {
							file->writeInt16BE(&bone_table[i]);
						}
						else {
							unsigned char bone = (unsigned char)bone_table[i];
							file->writeUChar(&bone);
						}
					}

					submesh_info.textures.reserve(texture_units.size());
					for (size_t i = 0; i < texture_units.size(); i++) {
						TextureInfo texture_info = {};
						texture_info.name = texture_units[i];
						texture_info.id = (i < texture_ids.size()) ? texture_ids[i] : 0;
						submesh_info.textures.push_back(texture_info);
					}

					mesh_info.submeshes[slot].push_back(submesh_info);
				}
			}

			mesh_infos.push_back(mesh_info);
		}

		mesh_table_address = file->writeNullAddressTable(mesh_count);

		if (!terrain_mode && bone_count) {
			bone_definition_table_address = file->writeNullAddressTable(bone_count);
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				size_t submesh_count = mesh_infos[mesh_index].submeshes[slot].size();
				if (submesh_count) {
					if (terrain_mode && (slot == LIBGENS_MODEL_SUBMESH_SLOT_WATER)) {
						mesh_infos[mesh_index].water_string_slot_address = file->writeNullAddress();
						mesh_infos[mesh_index].water_total_slot_address = file->writeNullAddress();
						mesh_infos[mesh_index].water_table_slot_address = file->writeNullAddress();
					}
					else {
						mesh_infos[mesh_index].table_address[slot] = file->writeNullAddressTable(submesh_count);
					}
				}
			}
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				for (size_t i = 0; i < mesh_infos[mesh_index].submeshes[slot].size(); i++) {
					SubmeshInfo &submesh_info = mesh_infos[mesh_index].submeshes[slot][i];
					if (submesh_info.textures.size()) {
						submesh_info.texture_table_address = file->writeNullAddressTable(submesh_info.textures.size());
					}
				}
			}
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			MeshInfo &mesh_info = mesh_infos[mesh_index];
			mesh_info.header_address = file->getCurrentAddress();
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				unsigned int submesh_count = mesh_info.submeshes[slot].size();
				file->writeInt32BE(&submesh_count);
				mesh_info.table_slot_address[slot] = file->writeNullAddress();
				if (slot == LIBGENS_MODEL_SUBMESH_SLOT_WATER) {
					mesh_info.water_total_header_slot_address = file->writeNullAddress();
					mesh_info.water_table_header_slot_address = file->writeNullAddress();
					file->writeNull(64);
				}
			}
		}

		if (!terrain_mode) {
			bone_definition_addresses.reserve(bone_count);
			bone_name_slot_addresses.reserve(bone_count);
			for (size_t i = 0; i < bone_count; i++) {
				bone_definition_addresses.push_back(file->getCurrentAddress());
				unsigned int parent = bones[i]->getParentIndex();
				file->writeInt32BE(&parent);
				bone_name_slot_addresses.push_back(file->writeNullAddress());
			}
		}
		else {
			for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
				MeshInfo &mesh_info = mesh_infos[mesh_index];
				size_t submesh_count = mesh_info.submeshes[LIBGENS_MODEL_SUBMESH_SLOT_WATER].size();
				if (submesh_count) {
					mesh_info.water_total_address = file->getCurrentAddress();
					unsigned int water_total = submesh_count;
					file->writeInt32BE(&water_total);
					mesh_info.water_table_address = file->writeNullAddressTable(submesh_count);
				}
			}
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				for (size_t i = 0; i < mesh_infos[mesh_index].submeshes[slot].size(); i++) {
					SubmeshInfo &submesh_info = mesh_infos[mesh_index].submeshes[slot][i];
					submesh_info.header_address = file->getCurrentAddress();
					submesh_info.material_slot_address = file->writeNullAddress();
					unsigned int faces_count = submesh_info.faces_count;
					file->writeInt32BE(&faces_count);
					submesh_info.faces_slot_address = file->writeNullAddress();
					unsigned int vertices_count = submesh_info.vertices_count;
					unsigned int vertex_size = submesh_info.vertex_size;
					file->writeInt32BE(&vertices_count);
					file->writeInt32BE(&vertex_size);
					submesh_info.vertices_slot_address = file->writeNullAddress();
					submesh_info.vertex_format_slot_address = file->writeNullAddress();
					unsigned int bone_count = submesh_info.bone_count;
					file->writeInt32BE(&bone_count);
					submesh_info.bones_slot_address = file->writeNullAddress();
					unsigned int texture_count = submesh_info.textures.size();
					file->writeInt32BE(&texture_count);
					submesh_info.texture_table_slot_address = file->writeNullAddress();
				}
			}
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				for (size_t i = 0; i < mesh_infos[mesh_index].submeshes[slot].size(); i++) {
					SubmeshInfo &submesh_info = mesh_infos[mesh_index].submeshes[slot][i];
					for (size_t texture_index = 0; texture_index < submesh_info.textures.size(); texture_index++) {
						TextureInfo &texture_info = submesh_info.textures[texture_index];
						texture_info.record_address = file->writeNullAddress();
						file->writeInt32BE(&texture_info.id);
					}
				}
			}
		}

		if (terrain_mode) {
			model_name_address = file->getCurrentAddress();
			file->writeString(&name);
			for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
				MeshInfo &mesh_info = mesh_infos[mesh_index];
				if (mesh_info.submeshes[LIBGENS_MODEL_SUBMESH_SLOT_WATER].size()) {
					mesh_info.water_string_address = file->getCurrentAddress();
					string water_string = mesh_info.mesh->getWaterSlotString();
					file->writeString(&water_string);
				}
			}
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				for (size_t i = 0; i < mesh_infos[mesh_index].submeshes[slot].size(); i++) {
					SubmeshInfo &submesh_info = mesh_infos[mesh_index].submeshes[slot][i];
					submesh_info.material_address = file->getCurrentAddress();
					string material_name = submesh_info.submesh->getMaterialName();
					file->writeString(&material_name);
					for (size_t texture_index = 0; texture_index < submesh_info.textures.size(); texture_index++) {
						TextureInfo &texture_info = submesh_info.textures[texture_index];
						texture_info.name_address = file->getCurrentAddress();
						file->writeString(&texture_info.name);
					}
				}
			}
		}

		if (terrain_mode) {
			file->fixPadding();
		}
		else {
			bone_name_addresses.reserve(bone_count);
			for (size_t i = 0; i < bone_count; i++) {
				bone_name_addresses.push_back(file->getCurrentAddress());
				string bone_name = bones[i]->getName();
				file->writeString(&bone_name);
			}
			file->fixPadding();
		}

		file->goToAddress(mesh_table_slot_address);
		file->writeInt32BEA(&mesh_table_address);
		for (size_t i = 0; i < mesh_infos.size(); i++) {
			file->goToAddress(mesh_table_address + i * address_size);
			file->writeInt32BEA(&mesh_infos[i].header_address);
		}

		if (terrain_mode) {
			file->goToAddress(model_name_slot_address);
			file->writeInt32BEA(&model_name_address);
		}
		else {
			if (bone_count) {
				file->goToAddress(bone_definition_table_slot_address);
				file->writeInt32BEA(&bone_definition_table_address);
				for (size_t i = 0; i < bone_count; i++) {
					file->goToAddress(bone_definition_table_address + i * address_size);
					file->writeInt32BEA(&bone_definition_addresses[i]);
				}
			}
			file->goToAddress(bone_matrix_slot_address);
			file->writeInt32BEA(&bone_matrix_address);
			file->goToAddress(global_aabb_slot_address);
			file->writeInt32BEA(&global_aabb_address);
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			MeshInfo &mesh_info = mesh_infos[mesh_index];
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				if (terrain_mode && (slot == LIBGENS_MODEL_SUBMESH_SLOT_WATER) && mesh_info.submeshes[slot].size()) {
					file->goToAddress(mesh_info.table_slot_address[slot]);
					file->writeInt32BEA(&mesh_info.water_string_slot_address);
					file->goToAddress(mesh_info.water_total_header_slot_address);
					file->writeInt32BEA(&mesh_info.water_total_slot_address);
					file->goToAddress(mesh_info.water_table_header_slot_address);
					file->writeInt32BEA(&mesh_info.water_table_slot_address);

					file->goToAddress(mesh_info.water_string_slot_address);
					file->writeInt32BEA(&mesh_info.water_string_address);
					file->goToAddress(mesh_info.water_total_slot_address);
					file->writeInt32BEA(&mesh_info.water_total_address);
					file->goToAddress(mesh_info.water_table_slot_address);
					file->writeInt32BEA(&mesh_info.water_table_address);

					for (size_t i = 0; i < mesh_info.submeshes[slot].size(); i++) {
						file->goToAddress(mesh_info.water_table_address + i * address_size);
						file->writeInt32BEA(&mesh_info.submeshes[slot][i].header_address);
					}
					continue;
				}

				if (mesh_info.table_address[slot]) {
					file->goToAddress(mesh_info.table_slot_address[slot]);
					file->writeInt32BEA(&mesh_info.table_address[slot]);
					for (size_t i = 0; i < mesh_info.submeshes[slot].size(); i++) {
						file->goToAddress(mesh_info.table_address[slot] + i * address_size);
						file->writeInt32BEA(&mesh_info.submeshes[slot][i].header_address);
					}
				}
			}
		}

		for (size_t mesh_index = 0; mesh_index < mesh_infos.size(); mesh_index++) {
			for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
				for (size_t i = 0; i < mesh_infos[mesh_index].submeshes[slot].size(); i++) {
					SubmeshInfo &submesh_info = mesh_infos[mesh_index].submeshes[slot][i];
					if (submesh_info.texture_table_address) {
						file->goToAddress(submesh_info.texture_table_slot_address);
						file->writeInt32BEA(&submesh_info.texture_table_address);
						for (size_t texture_index = 0; texture_index < submesh_info.textures.size(); texture_index++) {
							file->goToAddress(submesh_info.texture_table_address + texture_index * address_size);
							file->writeInt32BEA(&submesh_info.textures[texture_index].record_address);
						}
					}

					file->goToAddress(submesh_info.material_slot_address);
					file->writeInt32BEA(&submesh_info.material_address);
					file->goToAddress(submesh_info.faces_slot_address);
					file->writeInt32BEA(&submesh_info.faces_address);
					file->goToAddress(submesh_info.vertices_slot_address);
					file->writeInt32BEA(&submesh_info.vertices_address);
					file->goToAddress(submesh_info.vertex_format_slot_address);
					file->writeInt32BEA(&submesh_info.vertex_format_address);
					if (submesh_info.bone_count) {
						file->goToAddress(submesh_info.bones_slot_address);
						file->writeInt32BEA(&submesh_info.bones_address);
					}

					for (size_t texture_index = 0; texture_index < submesh_info.textures.size(); texture_index++) {
						TextureInfo &texture_info = submesh_info.textures[texture_index];
						file->goToAddress(texture_info.record_address);
						file->writeInt32BEA(&texture_info.name_address);
					}
				}
			}
		}

		if (!terrain_mode) {
			for (size_t i = 0; i < bone_count; i++) {
				file->goToAddress(bone_name_slot_addresses[i]);
				file->writeInt32BEA(&bone_name_addresses[i]);
			}
		}

		file->goToEnd();
	}
	
	void Model::writeSampleChunkHeader(File *file, int root_type, int sample_chunk_type) {
		SampleChunkNode root_node("Model", 1);
		
		if (properties.size()) {
			SampleChunkNode *property_node = root_node.newNode("NodesExt", 1)->newNode("NodePrms", 0)->newNode("SCAParam", 1);
			for (vector<SampleChunkProperty *>::iterator it = properties.begin(); it != properties.end(); it++) {
				property_node->addNode((*it)->toSampleChunkNode());
			}
		}

		if (topology == TRIANGLE_LIST) {
			SampleChunkNode* topology_node = new SampleChunkNode();
			topology_node->setName("Topology");
			topology_node->setValue(topology);
			root_node.addNode(topology_node);
		}

		if ((sample_chunk_type == LIBGENS_MODEL_SAMPLE_CHUNK_HE2) && (topology == TRIANGLE_LIST)) {
			root_node.newNode("UserAABB", 0);
		}

		SampleChunkNode *contexts_node = new SampleChunkNode();
		contexts_node->setName("Contexts");
		contexts_node->setData(this, root_type);
		root_node.addNode(contexts_node);

		root_node.write(file, true);
	}

	list<Vertex *> Model::getVertexList() {
		list<Vertex *> vertices;
		list<Vertex *> mesh_vertices;

		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			mesh_vertices=(*it)->getVertexList();

			for (list<Vertex *>::iterator it_v=mesh_vertices.begin(); it_v!=mesh_vertices.end(); it_v++) {
				vertices.push_back(*it_v);
			}
		}

		return vertices;
	}

	list<unsigned int> Model::getFaceList() {
		list<unsigned int> faces;
		list<unsigned int> mesh_faces;
		unsigned int face_offset=0;

		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			mesh_faces=(*it)->getFaceList();

			for (list<unsigned int>::iterator it_f=mesh_faces.begin(); it_f!=mesh_faces.end(); it_f++) {
				faces.push_back((*it_f) + face_offset);
			}

			face_offset += (*it)->getVertexList().size();
		}

		return faces;
	}

	void Model::addMesh(Mesh *mesh) {
		if (mesh) {
			meshes.push_back(mesh);
		}
	}

	void Model::addBone(Bone *bone) {
		if (bone) {
			bones.push_back(bone);
		}
	}

	void Model::mergeModel(Model *model, LibGens::Matrix4 transform, float uv2_left, float uv2_right, float uv2_top, float uv2_bottom) {
		vector<Mesh *> merge_meshes = model->getMeshes();
		for (std::vector<Mesh *>::iterator it=merge_meshes.begin(); it!=merge_meshes.end(); it++) {
			cloneMesh(*it, transform, uv2_left, uv2_right, uv2_top, uv2_bottom);
		}

		buildAABB();
	}

	void Model::cloneMesh(Mesh *mesh, LibGens::Matrix4 transform, float uv2_left, float uv2_right, float uv2_top, float uv2_bottom) {
		Mesh *clone_mesh = new Mesh(mesh, transform, uv2_left, uv2_right, uv2_top, uv2_bottom);
		meshes.push_back(clone_mesh);
	}

	Model::~Model() {
		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			delete (*it);
		}
		meshes.clear();

		for (vector<Bone *>::iterator it=bones.begin(); it!=bones.end(); it++) {
			delete (*it);
		}
		bones.clear();
	}

	list<string> Model::getMaterialNames() {
		list<string> material_names;
		list<string> mesh_material_names;

		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			mesh_material_names=(*it)->getMaterialNames();

			for (list<string>::iterator it_s=mesh_material_names.begin(); it_s!=mesh_material_names.end(); it_s++) {
				bool found=false;

				for (list<string>::iterator it_m=material_names.begin(); it_m!=material_names.end(); it_m++) {
					if ((*it_m) == (*it_s)) {
						found = true;
						break;
					}
				}

				if (!found) material_names.push_back(*it_s);
			}
		}

		return material_names;
	}

	vector<unsigned int> Model::getMaterialMappings(list<string> &material_names) {
		vector<unsigned int> material_mappings;
		vector<unsigned int> mesh_material_mappings;

		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			mesh_material_mappings=(*it)->getMaterialMappings(material_names);

			for (size_t i=0; i<mesh_material_mappings.size(); i++) {
				material_mappings.push_back(mesh_material_mappings[i]);
			}
		}

		return material_mappings;
	}


	void Model::getTotalData(list<Vertex *> &vertex_list, list<unsigned int> &face_list, list<string> &material_names, vector<unsigned int> &material_mappings) {
		vertex_list = getVertexList();
		face_list = getFaceList();
		material_names = getMaterialNames();
		material_mappings = getMaterialMappings(material_names);
	}


	void Model::fixVertexFormatForPC() {
		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			(*it)->fixVertexFormatForPC();
		}

		for (auto it = morph_models.begin(); it != morph_models.end(); ++it)
			(*it)->fixVertexFormatForPC();
	}

	void Model::buildAABB() {
		global_aabb.reset();

		for (std::vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			(*it)->buildAABB();
			global_aabb.merge((*it)->getAABB());
		}
	}

	AABB Model::getAABB() {
		return global_aabb;
	}

	void Model::setTerrainMode(bool v) {
		terrain_mode = v;
		has_instances = v;
	}

	vector<Bone *> Model::getBones() {
		return bones;
	}

	int Model::getBoneIndexByName(string bone_name) {
		for (size_t i=0; i<bones.size(); i++) {
			if (bones[i]->getName() == bone_name) {
				return i;
			}
		}

		return -1;
	}

	vector<Mesh *> Model::getMeshes() {
		return meshes;
	}

	void Model::setName(string v) {
		name=v;
	}

	string Model::getName() {
		return name;
	}

	string Model::getFilename() {
		return filename;
	}

	unsigned int Model::getEstimatedMemorySize() {
		unsigned int memory_size = 0;
		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			memory_size += (*it)->getEstimatedMemorySize();
		}
		return memory_size;
	}

	void Model::changeVertexFormat(int format) {
		for (vector<Mesh *>::iterator it=meshes.begin(); it!=meshes.end(); it++) {
			(*it)->changeVertexFormat(format);
		}
	}

    bool Model::getPropertyValue(string name, unsigned& value) {
		if (name.size() > 8) name = name.substr(0, 8);

		for (vector<SampleChunkProperty*>::iterator it = properties.begin(); it != properties.end(); it++) {
			if ((*it)->getName() == name) {
				value = (*it)->getValue();
				return true;
			}
		}
		return false;
    }

    void Model::setPropertyValue(string name, unsigned int value) {
		if (name.size() > 8) name = name.substr(0, 8);
		
		for (vector<SampleChunkProperty *>::iterator it = properties.begin(); it != properties.end(); it++) {
			if ((*it)->getName() == name) {
				(*it)->setValue(value);
				return;
			}
		}

		properties.push_back(new SampleChunkProperty(name, value));
	}

	vector<MorphModel*> Model::getMorphModels() {
		return morph_models;
	}

	void Model::addMorphModel(MorphModel* morph_model) {
		morph_models.push_back(morph_model);
	}
};
