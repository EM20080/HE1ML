//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#ifndef HAVOK_5_5_0

#if defined(_WIN64) || defined(_M_X64) || defined(__x86_64__)
#ifndef _M_X64
#define _M_X64
#endif
#endif

#include "FBX.h"
#include "FBXManager.h"
#include "Material.h"
#include "MaterialLibrary.h"
#include "Texture.h"
#include "Bone.h"
#include "Model.h"
#include "MorphModel.h"
#include "Submesh.h"
#include "Vertex.h"
#include "TerrainInstance.h"

#include "Havok.h"
#include "HavokSkeletonCache.h"
#include "HavokAnimationCache.h"
#include "PXDSkeleton.h"
#include "PXDAnimation.h"
#ifdef _M_X64
#include "hklib/hka_animationbinding.hpp"
#include "hklib/hka_annotationtrack.hpp"
#endif
#include <algorithm>
#include <cctype>
#include <string>
#include <unordered_map>

namespace LibGens {
#ifdef _M_X64
	static std::string normalizeBoneName(std::string_view name) {
		if (name.empty()) {
			return {};
		}

		std::string out{name};
		size_t lt_pos = out.find("@LT");
		if (lt_pos != std::string::npos) {
			out.resize(lt_pos);
		}

		for (char &ch : out) {
			ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
		}
		return out;
	}
#endif
	void FBXManager::exportFBX(FBX *fbx, string filename) {
		int lFileFormat = sdk_manager->GetIOPluginRegistry()->GetNativeWriterFormat();

		FbxExporter* lExporter = FbxExporter::Create(sdk_manager, "");
		bool lExportStatus = lExporter->Initialize(filename.c_str(), lFileFormat, sdk_manager->GetIOSettings());

		if(!lExportStatus) {
			printf("Call to FbxExporter::Initialize() failed.\n");
			printf("Error returned: %s\n\n", lExporter->GetStatus().GetErrorString());
			return;
		}

		FbxScene* lScene = fbx->getScene();
		lScene->GetGlobalSettings().SetAxisSystem(FbxAxisSystem::OpenGL); // Matches with the game despite the name
		lScene->GetGlobalSettings().SetSystemUnit(FbxSystemUnit::m);

		// Export scene
		lExporter->Export(lScene);
		lExporter->Destroy();

#ifdef _M_X64
		delete fbx;
#endif
	}


	FbxSurfacePhong *FBX::addMaterial(Material *material) {
		FbxSurfacePhong* lMaterial = NULL;

		FbxString lMaterialName = material->getName().c_str();
		FbxString lShadingName  = "Phong";
		FbxDouble3 lBlack(0.0, 0.0, 0.0);
		FbxDouble3 lDiffuseColor(1.0, 1.0, 1.0);

		lMaterial = FbxSurfacePhong::Create(scene, lMaterialName.Buffer());
		// Generate primary and secondary colors.
		lMaterial->Emissive.Set(lBlack);
		lMaterial->Ambient.Set(lBlack);
		lMaterial->AmbientFactor.Set(1.0);
		// Add texture for diffuse channel
		lMaterial->Diffuse.Set(lDiffuseColor);
		lMaterial->DiffuseFactor.Set(1.0);
		lMaterial->ShadingModel.Set(lShadingName);
		lMaterial->Shininess.Set(0.0);
		lMaterial->Specular.Set(lBlack);
		lMaterial->SpecularFactor.Set(0.0);

		// Set texture properties.
		Texture *texture_unit = material->getTextureByUnit("diffuse");
		if (texture_unit) {
			FbxFileTexture* lTexture = FbxFileTexture::Create(scene, texture_unit->getTexset().c_str());
			lTexture->SetFileName((material->getFolder() + texture_unit->getName() + LIBGENS_TEXTURE_FILE_EXTENSION).c_str());
			lTexture->SetTextureUse(FbxTexture::eStandard);
			lTexture->SetMappingType(FbxTexture::eUV);
			lTexture->SetMaterialUse(FbxFileTexture::eModelMaterial);
			lTexture->SetSwapUV(false);
			lTexture->SetTranslation(0.0, 0.0);
			lTexture->SetScale(1.0, 1.0);
			lTexture->SetRotation(0.0, 0.0);
			lTexture->UVSet.Set("UVChannel_1");
			if (lMaterial) lMaterial->Diffuse.ConnectSrcObject(lTexture);
		}

		if (texture_unit) {
			FbxFileTexture* lTexture = FbxFileTexture::Create(scene, (texture_unit->getTexset()+"_ambient").c_str());
			lTexture->SetFileName((material->getFolder() + texture_unit->getName() + LIBGENS_TEXTURE_FILE_EXTENSION).c_str());
			lTexture->SetTextureUse(FbxTexture::eStandard);
			lTexture->SetMappingType(FbxTexture::eUV);
			lTexture->SetMaterialUse(FbxFileTexture::eModelMaterial);
			lTexture->SetSwapUV(false);
			lTexture->SetTranslation(0.0, 0.0);
			lTexture->SetScale(1.0, 1.0);
			lTexture->SetRotation(0.0, 0.0);
			lTexture->UVSet.Set("UVChannel_2");
			if (lMaterial) lMaterial->Ambient.ConnectSrcObject(lTexture);
		}

		return lMaterial;
	}

#if !defined(_M_X64) && !defined(_WIN64)
	FbxNode *FBX::addHavokBone(FbxNode *parent_node, unsigned int parent_index, vector<FbxNode *> &skeleton_bones, hkaSkeleton *skeleton) {
		FbxNode *root_bone=NULL;
		for (int b=0; b<skeleton->m_bones.getSize(); b++) {
			hkaBone &bone           = skeleton->m_bones[b];
#ifdef HAVOK_5_5_0
			string bone_name        = bone.m_name;
#else
			string bone_name        = ToString(bone.m_name);
#endif
			size_t model_bone_index = 0;
			bool found=false;

			if (skeleton->m_parentIndices[b] != parent_index) {
				continue;
			}

			FbxSkeleton* lSkeletonRootAttribute = FbxSkeleton::Create(scene, bone_name.c_str());
			if (parent_index == -1) lSkeletonRootAttribute->SetSkeletonType(FbxSkeleton::eRoot);
			else lSkeletonRootAttribute->SetSkeletonType(FbxSkeleton::eLimbNode);

			FbxNode* bone_node = FbxNode::Create(scene, bone_name.c_str());
			bone_node->SetNodeAttribute(lSkeletonRootAttribute);
			root_bone = bone_node;

			hkQsTransform ref = skeleton->m_referencePose[b];
			bone_node->LclTranslation.Set(FbxVector4(ref.getTranslation()(0), ref.getTranslation()(1), ref.getTranslation()(2)));
			//bone_node->LclScaling.Set(FbxVector4(ref.getScale()(0), ref.getScale()(1), ref.getScale()(2)));
			FbxQuaternion lcl_quat(ref.getRotation()(0), ref.getRotation()(1), ref.getRotation()(2), ref.getRotation()(3));
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(lcl_quat);
			bone_node->LclRotation.Set(lcl_rotation);

			skeleton_bones[b] = bone_node;
			parent_node->AddChild(bone_node);

			bind_pose->Add(bone_node, bone_node->EvaluateGlobalTransform());

			addHavokBone(bone_node, b, skeleton_bones, skeleton);
		}
		return root_bone;
	}

	
	// Create a skeleton with 2 segments.
	FbxNode *FBX::addHavokSkeleton(vector<FbxNode *> &skeleton_bones, hkaSkeleton *skeleton) {
		FbxNode *lRootNode = scene->GetRootNode();
		FbxNode *skeleton_root_bone=addHavokBone(lRootNode, -1, skeleton_bones, skeleton);
		return skeleton_root_bone;
	}

	void FBX::addHavokAnimation(vector<FbxNode *> &skeleton_bones, hkaSkeleton *skeleton, hkaAnimationBinding *animation_binding, hkaAnimation *animation, const string& animation_name) {
		// Create an animation control
		hkaDefaultAnimationControl* ac = new hkaDefaultAnimationControl(animation_binding);

		// Create a new animated skeleton if not already created
		if (!animated_skeleton) {
			animated_skeleton = new hkaAnimatedSkeleton(skeleton);
		}
		animated_skeleton->addAnimationControl( ac );
		ac->removeReference();

		FbxAnimStack* lAnimStack = FbxAnimStack::Create(scene, animation_name.c_str());
		FbxAnimLayer* lAnimLayer = FbxAnimLayer::Create(scene, animation_name.c_str());
		lAnimStack->AddMember(lAnimLayer);
		FbxTimeSpan local_time_span(FbxTimeSeconds(0.0), FbxTimeSeconds((double)animation->m_duration));
		lAnimStack->SetLocalTimeSpan(local_time_span);

		for (int i = 0; i < animation->getNumOriginalFrames(); i++) {
			// Set animation time
			FbxTime lTime;
			lTime.SetSecondDouble((double)i / (double)(animation->getNumOriginalFrames() - 1) * (double)animation->m_duration);
			ac->setLocalTime((float)lTime.GetSecondDouble());

			hkaPose pose(animated_skeleton->getSkeleton());
			animated_skeleton->sampleAndCombineAnimations(pose.accessUnsyncedPoseLocalSpace().begin(), pose.getFloatSlotValues().begin());

			for (int j=0; j<skeleton->m_bones.getSize(); j++) {
#ifdef HAVOK_5_5_0
				string bone_name = skeleton->m_bones[j].m_name;
#else
				string bone_name = ToString(skeleton->m_bones[j].m_name);
#endif

				for (size_t bone_index=0; bone_index<skeleton_bones.size(); bone_index++) {
					if (bone_name == skeleton_bones[bone_index]->GetName()) {
						hkQsTransform transform_local = pose.getBoneLocalSpace(j);
						hkQsTransform transform_model = hkQsTransform::IDENTITY;

						hkInt16 parent_index = skeleton->m_parentIndices[j];
						if ((parent_index >= 0) && (parent_index < (int) skeleton_bones.size())) {
							transform_model = pose.getBoneModelSpace(parent_index);
						}

						hkVector4 ts_m = transform_model.getScale();
						hkVector4 tt = transform_local.getTranslation();
						hkQuaternion tr = transform_local.getRotation();
						hkVector4 ts = transform_local.getScale();

						tt = hkVector4(tt(0) / ts_m(0), tt(1) / ts_m(0), tt(2) / ts_m(0));


						//printfErrorMessage(LOG, "%s at %f: %f %f %f %f\n", bone_name.c_str(), current_frame, (float)tt(0), (float)tt(1), (float)tt(2), (float)tt(3));
						//printfErrorMessage(LOG, "%s at %f: %f %f %f %f\n", bone_name.c_str(), current_frame, (float)ts(0), (float)ts(1), (float)ts(2), (float)ts(3));

						FbxAnimCurve* curveTX = skeleton_bones[bone_index]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
						FbxAnimCurve* curveTY = skeleton_bones[bone_index]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
						FbxAnimCurve* curveTZ = skeleton_bones[bone_index]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

						FbxAnimCurve* curveRX = skeleton_bones[bone_index]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
						FbxAnimCurve* curveRY = skeleton_bones[bone_index]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
						FbxAnimCurve* curveRZ = skeleton_bones[bone_index]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

						FbxAnimCurve* curveSX = skeleton_bones[bone_index]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
						FbxAnimCurve* curveSY = skeleton_bones[bone_index]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
						FbxAnimCurve* curveSZ = skeleton_bones[bone_index]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

						if (curveTX) {
							curveTX->KeyModifyBegin();
							int lKeyIndex = curveTX->KeyAdd(lTime);
							curveTX->KeySetValue(lKeyIndex, tt(0));
							curveTX->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveTX->KeyModifyEnd();
						}

						if (curveTY) {
							curveTY->KeyModifyBegin();
							int lKeyIndex = curveTY->KeyAdd(lTime);
							curveTY->KeySetValue(lKeyIndex, tt(1));
							curveTY->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveTY->KeyModifyEnd();
						}

						if (curveTZ) {
							curveTZ->KeyModifyBegin();
							int lKeyIndex = curveTZ->KeyAdd(lTime);
							curveTZ->KeySetValue(lKeyIndex, tt(2));
							curveTZ->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveTZ->KeyModifyEnd();
						}
						
						if (curveSX) {
							curveSX->KeyModifyBegin();
							int lKeyIndex = curveSX->KeyAdd(lTime);
							curveSX->KeySetValue(lKeyIndex, ts(0));
							curveSX->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveSX->KeyModifyEnd();
						}

						if (curveSY) {
							curveSY->KeyModifyBegin();
							int lKeyIndex = curveSY->KeyAdd(lTime);
							curveSY->KeySetValue(lKeyIndex, ts(0));
							curveSY->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveSY->KeyModifyEnd();
						}

						if (curveSZ) {
							curveSZ->KeyModifyBegin();
							int lKeyIndex = curveSZ->KeyAdd(lTime);
							curveSZ->KeySetValue(lKeyIndex, ts(0));
							curveSZ->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveSZ->KeyModifyEnd();
						}

						FbxQuaternion lcl_quat(tr(0), tr(1), tr(2), tr(3));
						FbxVector4 lcl_rotation;
						lcl_rotation.SetXYZ(lcl_quat);
						
						if (curveRX) {
							curveRX->KeyModifyBegin();
							int lKeyIndex = curveRX->KeyAdd(lTime);
							curveRX->KeySetValue(lKeyIndex, lcl_rotation[0]);
							curveRX->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveRX->KeyModifyEnd();
						}

						if (curveRY) {
							curveRY->KeyModifyBegin();
							int lKeyIndex = curveRY->KeyAdd(lTime);
							curveRY->KeySetValue(lKeyIndex, lcl_rotation[1]);
							curveRY->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveRY->KeyModifyEnd();
						}

						if (curveRZ) {
							curveRZ->KeyModifyBegin();
							int lKeyIndex = curveRZ->KeyAdd(lTime);
							curveRZ->KeySetValue(lKeyIndex, lcl_rotation[2]);
							curveRZ->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
							curveRZ->KeyModifyEnd();
						}

						break;
					}
				}
			}
		}

		// Apply unroll filter to fix flickering when interpolating
		FbxAnimCurveFilterUnroll lFilter;

		for (size_t i = 0; i < skeleton_bones.size(); i++)
		{
			FbxAnimCurve* lCurve[3];

			lCurve[0] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
			lCurve[1] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
			lCurve[2] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);

			if (lCurve[0] && lCurve[1] && lCurve[2] && lFilter.NeedApply(lCurve, 3))
				lFilter.Apply(lCurve, 3);
		}
	}
#endif

#ifdef _M_X64
	FbxNode *FBX::addHavokBone(FbxNode *parent_node, unsigned int parent_index, vector<FbxNode *> &skeleton_bones, hkaSkeleton *skeleton) {
		FbxNode *root_bone = NULL;
		if (!skeleton) {
			return root_bone;
		}

		int parent_bone_id = (parent_index == (unsigned int)-1) ? -1 : (int)parent_index;
		size_t bone_count = skeleton->GetNumBones();

		for (size_t b = 0; b < bone_count; b++) {
			int16 bone_parent_id = skeleton->GetBoneParentID(b);
			if (bone_parent_id != parent_bone_id) {
				continue;
			}

			string bone_name = string(skeleton->GetBoneName(b));
			size_t lt_pos = bone_name.find("@LT");
			if (lt_pos != string::npos) {
				bone_name = bone_name.substr(0, lt_pos);
			}

			FbxSkeleton* lSkeletonRootAttribute = FbxSkeleton::Create(scene, bone_name.c_str());
			if (parent_bone_id == -1) {
				lSkeletonRootAttribute->SetSkeletonType(FbxSkeleton::eRoot);
			}
			else {
				lSkeletonRootAttribute->SetSkeletonType(FbxSkeleton::eLimbNode);
			}

			FbxNode* bone_node = FbxNode::Create(scene, bone_name.c_str());
			bone_node->SetNodeAttribute(lSkeletonRootAttribute);
			root_bone = bone_node;

			const hkQTransform *ref = skeleton->GetBoneTM(b);
			if (ref) {
				bone_node->LclTranslation.Set(FbxVector4(ref->translation[0], ref->translation[1], ref->translation[2]));
				FbxQuaternion lcl_quat(ref->rotation[0], ref->rotation[1], ref->rotation[2], ref->rotation[3]);
				FbxVector4 lcl_rotation;
				lcl_rotation.SetXYZ(lcl_quat);
				bone_node->LclRotation.Set(lcl_rotation);
			}

			if (b < skeleton_bones.size()) {
				skeleton_bones[b] = bone_node;
			}
			parent_node->AddChild(bone_node);
			bind_pose->Add(bone_node, bone_node->EvaluateGlobalTransform());

			addHavokBone(bone_node, (unsigned int)b, skeleton_bones, skeleton);
		}

		return root_bone;
	}

	FbxNode *FBX::addHavokSkeleton(vector<FbxNode *> &skeleton_bones, hkaSkeleton *skeleton) {
		FbxNode *lRootNode = scene->GetRootNode();
		return addHavokBone(lRootNode, (unsigned int)-1, skeleton_bones, skeleton);
	}

	void FBX::addHavokAnimation(vector<FbxNode *> &skeleton_bones, hkaSkeleton *skeleton, hkaAnimationBinding *animation_binding, hkaAnimation *animation, const string& animation_name) {
		if (!skeleton || !animation) {
			return;
		}
		animation->SetReferenceSkeleton(skeleton);
		const bool ignore_scale = (animation->GetAnimationType() == HK_QUANTIZED_COMPRESSED_ANIMATION);
		FbxAnimStack* lAnimStack = FbxAnimStack::Create(scene, animation_name.c_str());
		FbxAnimLayer* lAnimLayer = FbxAnimLayer::Create(scene, animation_name.c_str());
		lAnimStack->AddMember(lAnimLayer);

		float duration = animation->Duration();
		if (duration < 0.0f) {
			duration = 0.0f;
		}
		FbxTimeSpan local_time_span(FbxTimeSeconds(0), FbxTimeSeconds(duration));
		lAnimStack->SetLocalTimeSpan(local_time_span);

		float frame_rate = (float)animation->FrameRate();
		if (frame_rate <= 0.0f) {
			frame_rate = 30.0f;
		}

		float exact_frames = duration * frame_rate;
		int frame_count = (int)exact_frames;
		if ((float)frame_count < exact_frames) {
			frame_count++;
		}
		if (frame_count < 1) {
			frame_count = 1;
		}

		vector<uni::RTSValue> sampled_transforms;
		sampled_transforms.resize(skeleton_bones.size());
		auto tracks = animation->Tracks();
		std::vector<int32> track_to_bone;
		bool use_track_map = false;

		const size_t num_tracks = animation->GetNumOfTransformTracks();
		if (skeleton && num_tracks && animation->GetNumAnnotations() == num_tracks) {
			std::unordered_map<std::string, size_t> bone_map;
			bone_map.reserve(skeleton->GetNumBones());
			for (size_t i = 0; i < skeleton->GetNumBones(); i++) {
				std::string name = normalizeBoneName(skeleton->GetBoneName(i));
				if (!name.empty() && bone_map.find(name) == bone_map.end()) {
					bone_map.emplace(std::move(name), i);
				}
			}

			track_to_bone.resize(num_tracks, -1);
			for (size_t i = 0; i < num_tracks; i++) {
				hkaAnnotationTrackPtr annot = animation->GetAnnotation(i);
				if (!annot) {
					continue;
				}
				std::string name = normalizeBoneName(annot->GetName());
				if (name.empty()) {
					continue;
				}
				auto it = bone_map.find(name);
				if (it != bone_map.end()) {
					track_to_bone[i] = static_cast<int32>(it->second);
				}
			}

			for (int32 v : track_to_bone) {
				if (v >= 0) {
					use_track_map = true;
					break;
				}
			}
		}

		for (int i = 0; i <= frame_count; i++) {
			float current_time = duration * ((float)i / (float)frame_count);
			FbxTime lTime;
			lTime.SetSecondDouble(current_time);

			for (size_t j = 0; j < sampled_transforms.size(); j++) {
				if (const hkQTransform *ref = skeleton->GetBoneTM(j)) {
					sampled_transforms[j] =
						uni::RTSValue(ref->translation, ref->rotation, ref->scale);
				}
				else {
					sampled_transforms[j] = uni::RTSValue();
				}
				if (ignore_scale) {
					sampled_transforms[j].scale = Vector4A16(1.0f, 1.0f, 1.0f, 0.0f);
				}
			}

			size_t track_index = 0;
			const size_t binding_tracks =
				animation_binding ? animation_binding->GetNumTransformTrackToBoneIndices() : 0;
			for (const auto& track : *tracks) {
				size_t bone_index = track_index;
				if (use_track_map && track_index < track_to_bone.size()) {
					const int32 mapped = track_to_bone[track_index];
					if (mapped >= 0) {
						bone_index = static_cast<size_t>(mapped);
					}
				} else if (animation_binding && track_index < binding_tracks) {
					int16 mapped = animation_binding->GetTransformTrackToBoneIndex(track_index);
					if (mapped < 0) {
						track_index++;
						continue;
					}
					bone_index = static_cast<size_t>(mapped);
				} else {
					bone_index = track->BoneIndex();
				}
				if (bone_index < sampled_transforms.size()) {
					track->GetValue(sampled_transforms[bone_index], current_time);
				}
				track_index++;
			}

			vector<float> model_scale(skeleton_bones.size(), 1.0f);
			for (size_t k = 0; k < skeleton_bones.size(); k++) {
				float local_s = ignore_scale ? 1.0f : sampled_transforms[k].scale[0];
				int16 par = skeleton->GetBoneParentID(k);
				if (par >= 0 && (size_t)par < model_scale.size()) {
					model_scale[k] = local_s * model_scale[(size_t)par];
				} else {
					model_scale[k] = local_s;
				}
			}

			for (size_t bone_index = 0; bone_index < skeleton_bones.size(); bone_index++) {
				if (!skeleton_bones[bone_index]) {
					continue;
				}

				string bone_name = string(skeleton->GetBoneName(bone_index));
				size_t lt_pos = bone_name.find("@LT");
				if (lt_pos != string::npos) {
					bone_name = bone_name.substr(0, lt_pos);
				}

				const uni::RTSValue &transform_local = sampled_transforms[bone_index];
				FbxVector4 translation(transform_local.translation[0], transform_local.translation[1], transform_local.translation[2]);

				int16 parent_id = skeleton->GetBoneParentID(bone_index);
				if (!ignore_scale && parent_id >= 0 && (size_t)parent_id < model_scale.size()) {
					float pms = model_scale[(size_t)parent_id];
					if (pms != 0.0f) {
						translation[0] /= pms;
						translation[1] /= pms;
						translation[2] /= pms;
					}
				}

				FbxQuaternion lcl_quat(transform_local.rotation[0], transform_local.rotation[1], transform_local.rotation[2], transform_local.rotation[3]);
				FbxVector4 lcl_rotation;
				lcl_rotation.SetXYZ(lcl_quat);
				// Use uniform scale (X only) to match Havok SDK behaviour, because...
				// that would squish bones if applied per component. which happened on SonicRoot + Sonic_IdleA.
				float uniform_scale = ignore_scale ? 1.0f : transform_local.scale[0];

				FbxAnimCurve* curveTX = skeleton_bones[bone_index]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
				FbxAnimCurve* curveTY = skeleton_bones[bone_index]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
				FbxAnimCurve* curveTZ = skeleton_bones[bone_index]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

				FbxAnimCurve* curveRX = skeleton_bones[bone_index]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
				FbxAnimCurve* curveRY = skeleton_bones[bone_index]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
				FbxAnimCurve* curveRZ = skeleton_bones[bone_index]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

				FbxAnimCurve* curveSX = skeleton_bones[bone_index]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
				FbxAnimCurve* curveSY = skeleton_bones[bone_index]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
				FbxAnimCurve* curveSZ = skeleton_bones[bone_index]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

				if (curveTX) {
					curveTX->KeyModifyBegin();
					int lKeyIndex = curveTX->KeyAdd(lTime);
					curveTX->KeySetValue(lKeyIndex, translation[0]);
					curveTX->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveTX->KeyModifyEnd();
				}

				if (curveTY) {
					curveTY->KeyModifyBegin();
					int lKeyIndex = curveTY->KeyAdd(lTime);
					curveTY->KeySetValue(lKeyIndex, translation[1]);
					curveTY->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveTY->KeyModifyEnd();
				}

				if (curveTZ) {
					curveTZ->KeyModifyBegin();
					int lKeyIndex = curveTZ->KeyAdd(lTime);
					curveTZ->KeySetValue(lKeyIndex, translation[2]);
					curveTZ->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveTZ->KeyModifyEnd();
				}

				if (curveSX) {
					curveSX->KeyModifyBegin();
					int lKeyIndex = curveSX->KeyAdd(lTime);
					curveSX->KeySetValue(lKeyIndex, uniform_scale);
					curveSX->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveSX->KeyModifyEnd();
				}

				if (curveSY) {
					curveSY->KeyModifyBegin();
					int lKeyIndex = curveSY->KeyAdd(lTime);
					curveSY->KeySetValue(lKeyIndex, uniform_scale);
					curveSY->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveSY->KeyModifyEnd();
				}

				if (curveSZ) {
					curveSZ->KeyModifyBegin();
					int lKeyIndex = curveSZ->KeyAdd(lTime);
					curveSZ->KeySetValue(lKeyIndex, uniform_scale);
					curveSZ->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveSZ->KeyModifyEnd();
				}

				if (curveRX) {
					curveRX->KeyModifyBegin();
					int lKeyIndex = curveRX->KeyAdd(lTime);
					curveRX->KeySetValue(lKeyIndex, lcl_rotation[0]);
					curveRX->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveRX->KeyModifyEnd();
				}

				if (curveRY) {
					curveRY->KeyModifyBegin();
					int lKeyIndex = curveRY->KeyAdd(lTime);
					curveRY->KeySetValue(lKeyIndex, lcl_rotation[1]);
					curveRY->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveRY->KeyModifyEnd();
				}

				if (curveRZ) {
					curveRZ->KeyModifyBegin();
					int lKeyIndex = curveRZ->KeyAdd(lTime);
					curveRZ->KeySetValue(lKeyIndex, lcl_rotation[2]);
					curveRZ->KeySetInterpolation(lKeyIndex, FbxAnimCurveDef::eInterpolationLinear);
					curveRZ->KeyModifyEnd();
				}
			}
		}

		FbxAnimCurveFilterUnroll lFilter;
		for (size_t i = 0; i < skeleton_bones.size(); i++) {
			if (!skeleton_bones[i]) {
				continue;
			}

			FbxAnimCurve* lCurve[3];
			lCurve[0] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
			lCurve[1] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
			lCurve[2] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);

			if (lCurve[0] && lCurve[1] && lCurve[2] && lFilter.NeedApply(lCurve, 3)) {
				lFilter.Apply(lCurve, 3);
			}
		}
	}
#endif

	FbxMesh *FBX::addTerrainInstance(TerrainInstance *instance) {
		if (!instance) return NULL;

#ifndef _M_X64
		return addNamedNode(instance->getName(), instance->getModel(), NULL, {}, instance->getMatrix());
#else
		return addNamedNode(instance->getName(), instance->getModel(), instance->getMatrix());
#endif
	}

#ifdef _M_X64

	FbxMesh *FBX::addNode(Model *model, HavokSkeletonCache *skeleton, vector<HavokAnimationCache*> animations, Matrix4 transform_matrix, bool skin) {
		string model_name = "Dummy";
		if (model) {
			model_name = model->getName();
		}

		return addNamedNode(model_name, model, skeleton, animations, transform_matrix, skin);
	}

	FbxMesh *FBX::addNamedNode(string name, Model *model, HavokSkeletonCache *skeleton, vector<HavokAnimationCache*> animations, Matrix4 transform_matrix, bool skin) {
		FbxNode* lMeshNode = NULL;
		FbxMesh* lMesh = NULL;

		if (model) {
			models.push_back(model);

			lMeshNode = FbxNode::Create(scene, name.c_str());
			lMesh = FbxMesh::Create(scene, (name + "_mesh").c_str());

			while (lMesh->CreateLayer() != 3);
			FbxLayer* lLayer = lMesh->GetLayer(0);
			FbxLayer* lLayer1 = lMesh->GetLayer(1);
			FbxLayer* lLayer2 = lMesh->GetLayer(2);
			FbxLayer* lLayer3 = lMesh->GetLayer(3);

			Vector3 position;
			Vector3 scale;
			Quaternion orientation;
			transform_matrix.decomposition(position, scale, orientation);

			lMeshNode->LclTranslation.Set(FbxVector4(position.x, position.y, position.z));
			lMeshNode->LclScaling.Set(FbxVector4(scale.x, scale.y, scale.z));

			FbxQuaternion lcl_quat(orientation.x, orientation.y, orientation.z, orientation.w);
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(lcl_quat);
			lMeshNode->LclRotation.Set(lcl_rotation);
			
			list<Vertex *> model_vertices;
			list<unsigned int> model_faces;
			list<string> material_names;
			vector<unsigned int> material_mappings;
			model->getTotalData(model_vertices, model_faces, material_names, material_mappings);

			lMesh->InitControlPoints(model_vertices.size());
			FbxVector4* lControlPoints = lMesh->GetControlPoints();

			FbxLayerElementNormal* lLayerElementNormal = (FbxLayerElementNormal*)lLayer->CreateLayerElementOfType(FbxLayerElement::eNormal);
			lLayerElementNormal->SetMappingMode(FbxLayerElement::eByControlPoint);
			lLayerElementNormal->SetReferenceMode(FbxLayerElement::eDirect);

			FbxLayerElementBinormal* lLayerElementBinormal = (FbxLayerElementBinormal*)lLayer->CreateLayerElementOfType(FbxLayerElement::eBiNormal);
			lLayerElementBinormal->SetName("UVChannel_1");
			lLayerElementBinormal->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerElementBinormal->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementTangent* lLayerElementTangent = (FbxLayerElementTangent*)lLayer->CreateLayerElementOfType(FbxLayerElement::eTangent);
			lLayerElementTangent->SetName("UVChannel_1");
			lLayerElementTangent->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerElementTangent->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementMaterial* lMaterialLayer = (FbxLayerElementMaterial*)lLayer->CreateLayerElementOfType(FbxLayerElement::eMaterial);
			lMaterialLayer->SetMappingMode(FbxLayerElement::eByPolygon);
			lMaterialLayer->SetReferenceMode(FbxLayerElement::eIndexToDirect);

			FbxLayerElementVertexColor* lLayerElementVertexColor = (FbxLayerElementVertexColor*)lLayer->CreateLayerElementOfType(FbxLayerElement::eVertexColor);
			lLayerElementVertexColor->SetMappingMode(FbxGeometryElement::eByPolygonVertex);
			lLayerElementVertexColor->SetReferenceMode(FbxGeometryElement::eIndexToDirect);

			FbxLayerElementUV* lLayerUVElement = (FbxLayerElementUV*)lLayer->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUVElement->SetName("UVChannel_1");
			lLayerUVElement->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUVElement->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementUV* lLayerUV2Element = (FbxLayerElementUV*)lLayer1->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV2Element->SetName("UVChannel_2");
			lLayerUV2Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV2Element->SetReferenceMode(FbxGeometryElement::eDirect);	
			
			FbxLayerElementUV* lLayerUV3Element = (FbxLayerElementUV*)lLayer2->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV3Element->SetName("UVChannel_3");
			lLayerUV3Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV3Element->SetReferenceMode(FbxGeometryElement::eDirect);		
			
			FbxLayerElementUV* lLayerUV4Element = (FbxLayerElementUV*)lLayer3->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV4Element->SetName("UVChannel_4");
			lLayerUV4Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV4Element->SetReferenceMode(FbxGeometryElement::eDirect);
			
			unsigned int index=0;
			for (list<Vertex *>::iterator it=model_vertices.begin(); it!=model_vertices.end(); it++) {
				Vector3 position = (*it)->getPosition();
				Vector3 normal = (*it)->getNormal();
				Vector3 binormal = (*it)->getBinormal();
				Vector3 tangent = (*it)->getTangent();
				Vector2 uv_0 = (*it)->getUV(0);
				Vector2 uv_1 = (*it)->getUV(1);
				Vector2 uv_2 = (*it)->getUV(2);
				Vector2 uv_3 = (*it)->getUV(3);
				Color   color = (*it)->getColor();

				lControlPoints[index] = FbxVector4(position.x, position.y, position.z);
				lLayerElementNormal->GetDirectArray().Add(FbxVector4(normal.x, normal.y, normal.z));
				lLayerElementBinormal->GetDirectArray().Add(FbxVector4(binormal.x, binormal.y, binormal.z));
				lLayerElementTangent->GetDirectArray().Add(FbxVector4(tangent.x, tangent.y, tangent.z));
				lLayerUVElement->GetDirectArray().Add(FbxVector2(uv_0.x, 1.0-uv_0.y));
				lLayerUV2Element->GetDirectArray().Add(FbxVector2(uv_1.x, 1.0-uv_1.y));
				lLayerUV3Element->GetDirectArray().Add(FbxVector2(uv_2.x, 1.0-uv_2.y));
				lLayerUV4Element->GetDirectArray().Add(FbxVector2(uv_3.x, 1.0-uv_3.y));
				lLayerElementVertexColor->GetDirectArray().Add(FbxColor(color.r, color.g, color.b, color.a));
				index++;
			}

			unsigned int face_index=0;
			unsigned int global_index=0;
			for (list<unsigned int>::iterator it=model_faces.begin(); it!=model_faces.end(); it++) {
				if (face_index == 0) {
					lMesh->BeginPolygon(material_mappings[global_index], -1, -1, false);
				}

				lMesh->AddPolygon((*it));

				face_index++;
				if (face_index >= 3) {
					lMesh->EndPolygon();
					face_index = 0;
				}

				lLayerElementVertexColor->GetIndexArray().Add(*it);
				global_index++;
			}

			for (list<string>::iterator it = material_names.begin(); it != material_names.end(); it++) {
				if (material_library) {
					Material* material = material_library->getMaterial(*it);
					if (material) {
						FbxSurfacePhong* lMaterial = material_map[material];
						if (!lMaterial) {
							lMaterial = addMaterial(material);
							material_map[material] = lMaterial;
						}

						if (lMaterial) {
							lMeshNode->AddMaterial(lMaterial);
						}
					}
				}
			}
			
			lMeshNode->SetNodeAttribute(lMesh);
			lMeshNode->SetShadingMode(FbxNode::eTextureShading);

			FbxNode *lRootNode = scene->GetRootNode();
			lRootNode->AddChild(lMeshNode);

			bind_pose->Add(lMeshNode, lMeshNode->EvaluateGlobalTransform());
		}

		if (skeleton && skin) {
			hkaSkeleton *havok_skeleton = skeleton->getSkeleton();
			if (havok_skeleton) {
				vector<FbxNode *> skeleton_bones;
				skeleton_bones.resize(havok_skeleton->GetNumBones(), NULL);

				addHavokSkeleton(skeleton_bones, havok_skeleton);

				if (lMeshNode) {
					skinModelToSkeleton(model, lMesh, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
				}

				for (auto* animation : animations) {
					if (animation) {
						hkaAnimationBinding *havok_animation_binding = animation->getAnimationBinding();
						hkaAnimation *havok_animation = animation->getAnimation();
						const string animation_name = File::nameFromFilenameNoExtension(animation->getName());
						addHavokAnimation(skeleton_bones, havok_skeleton, havok_animation_binding, havok_animation, animation_name);
					}
				}

				if (lMeshNode && model)
					addMorphModels(model, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
			}
		}
		else if (lMeshNode && skin && model) {
			vector<FbxNode *> skeleton_bones;
			addSkeleton(skeleton_bones, model);
			
			if (skeleton_bones.size()) {
				skinModelToSkeleton(model, lMesh, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
			}

			addMorphModels(model, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
		}
		
		return lMesh;
	}

	FbxMesh *FBX::addNamedNode(string name, Model *model, Matrix4 transform_matrix, bool skin) {
		return addNamedNode(name, model, NULL, {}, transform_matrix, skin);
	}
#endif

#ifndef _M_X64
	FbxMesh *FBX::addNode(Model *model, HavokSkeletonCache *skeleton, vector<HavokAnimationCache*> animations, Matrix4 transform_matrix, bool skin) {
		string model_name = "Dummy";

		if (model) {
			model_name=model->getName();
		}

		return addNamedNode(model_name, model, skeleton, animations, transform_matrix, skin);
	}

	FbxMesh *FBX::addNamedNode(string name, Model *model, HavokSkeletonCache *skeleton, vector<HavokAnimationCache*> animations, Matrix4 transform_matrix, bool skin) {
		FbxNode* lMeshNode = NULL;
		FbxMesh* lMesh = NULL;

		if (model) {
			models.push_back(model);

			lMeshNode = FbxNode::Create(scene, name.c_str());
			lMesh = FbxMesh::Create(scene, (name + "_mesh").c_str());

			// UVs need to be in separate layers
			while (lMesh->CreateLayer() != 3);
			FbxLayer* lLayer = lMesh->GetLayer(0);
			FbxLayer* lLayer1 = lMesh->GetLayer(1);
			FbxLayer* lLayer2 = lMesh->GetLayer(2);
			FbxLayer* lLayer3 = lMesh->GetLayer(3);

			// Build Transform
			Vector3 position;
			Vector3 scale;
			Quaternion orientation;
			transform_matrix.decomposition(position, scale, orientation);

			lMeshNode->LclTranslation.Set(FbxVector4(position.x, position.y, position.z));
			lMeshNode->LclScaling.Set(FbxVector4(scale.x, scale.y, scale.z));

			FbxQuaternion lcl_quat(orientation.x, orientation.y, orientation.z, orientation.w);
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(lcl_quat);
			lMeshNode->LclRotation.Set(lcl_rotation);
			
			// Build Submeshes
			list<Vertex *> model_vertices;
			list<unsigned int> model_faces;
			list<string> material_names;
			vector<unsigned int> material_mappings;
			model->getTotalData(model_vertices, model_faces, material_names, material_mappings);

			lMesh->InitControlPoints(model_vertices.size());
			FbxVector4* lControlPoints = lMesh->GetControlPoints();

			// Element creation needs to be in this exact order for 3DS max to read them properly.
			FbxLayerElementNormal* lLayerElementNormal = (FbxLayerElementNormal*)lLayer->CreateLayerElementOfType(FbxLayerElement::eNormal);
			lLayerElementNormal->SetMappingMode(FbxLayerElement::eByControlPoint);
			lLayerElementNormal->SetReferenceMode(FbxLayerElement::eDirect);

			FbxLayerElementBinormal* lLayerElementBinormal = (FbxLayerElementBinormal*)lLayer->CreateLayerElementOfType(FbxLayerElement::eBiNormal);
			lLayerElementBinormal->SetName("UVChannel_1");
			lLayerElementBinormal->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerElementBinormal->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementTangent* lLayerElementTangent = (FbxLayerElementTangent*)lLayer->CreateLayerElementOfType(FbxLayerElement::eTangent);
			lLayerElementTangent->SetName("UVChannel_1");
			lLayerElementTangent->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerElementTangent->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementMaterial* lMaterialLayer = (FbxLayerElementMaterial*)lLayer->CreateLayerElementOfType(FbxLayerElement::eMaterial);
			lMaterialLayer->SetMappingMode(FbxLayerElement::eByPolygon);
			lMaterialLayer->SetReferenceMode(FbxLayerElement::eIndexToDirect);

			FbxLayerElementVertexColor* lLayerElementVertexColor = (FbxLayerElementVertexColor*)lLayer->CreateLayerElementOfType(FbxLayerElement::eVertexColor);
			lLayerElementVertexColor->SetMappingMode(FbxGeometryElement::eByPolygonVertex); // 3DS Max requires exactly these modes for vertex color.
			lLayerElementVertexColor->SetReferenceMode(FbxGeometryElement::eIndexToDirect);

			FbxLayerElementUV* lLayerUVElement = (FbxLayerElementUV*)lLayer->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUVElement->SetName("UVChannel_1");
			lLayerUVElement->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUVElement->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementUV* lLayerUV2Element = (FbxLayerElementUV*)lLayer1->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV2Element->SetName("UVChannel_2");
			lLayerUV2Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV2Element->SetReferenceMode(FbxGeometryElement::eDirect);	
			
			FbxLayerElementUV* lLayerUV3Element = (FbxLayerElementUV*)lLayer2->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV3Element->SetName("UVChannel_3");
			lLayerUV3Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV3Element->SetReferenceMode(FbxGeometryElement::eDirect);		
			
			FbxLayerElementUV* lLayerUV4Element = (FbxLayerElementUV*)lLayer3->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV4Element->SetName("UVChannel_4");
			lLayerUV4Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV4Element->SetReferenceMode(FbxGeometryElement::eDirect);
			
			// Create Vertices
			unsigned int index=0;
			for (list<Vertex *>::iterator it=model_vertices.begin(); it!=model_vertices.end(); it++) {
				Vector3 position = (*it)->getPosition();
				Vector3 normal = (*it)->getNormal();
				Vector3 binormal = (*it)->getBinormal();
				Vector3 tangent = (*it)->getTangent();
				Vector2 uv_0 = (*it)->getUV(0);
				Vector2 uv_1 = (*it)->getUV(1);
				Vector2 uv_2 = (*it)->getUV(2);
				Vector2 uv_3 = (*it)->getUV(3);
				Color   color = (*it)->getColor();

				lControlPoints[index] = FbxVector4(position.x, position.y, position.z);
				lLayerElementNormal->GetDirectArray().Add(FbxVector4(normal.x, normal.y, normal.z));
				lLayerElementBinormal->GetDirectArray().Add(FbxVector4(binormal.x, binormal.y, binormal.z));
				lLayerElementTangent->GetDirectArray().Add(FbxVector4(tangent.x, tangent.y, tangent.z));
				lLayerUVElement->GetDirectArray().Add(FbxVector2(uv_0.x, 1.0-uv_0.y));
				lLayerUV2Element->GetDirectArray().Add(FbxVector2(uv_1.x, 1.0-uv_1.y));
				lLayerUV3Element->GetDirectArray().Add(FbxVector2(uv_2.x, 1.0-uv_2.y));
				lLayerUV4Element->GetDirectArray().Add(FbxVector2(uv_3.x, 1.0-uv_3.y));
				lLayerElementVertexColor->GetDirectArray().Add(FbxColor(color.r, color.g, color.b, color.a));
				index++;
			}

			// Create Faces
			unsigned int face_index=0;
			unsigned int global_index=0;
			for (list<unsigned int>::iterator it=model_faces.begin(); it!=model_faces.end(); it++) {
				if (face_index == 0) {
					lMesh->BeginPolygon(material_mappings[global_index], -1, -1, false);
				}

				lMesh->AddPolygon((*it));

				face_index++;
				if (face_index >= 3) {
					lMesh->EndPolygon();
					face_index = 0;
				}

				// Vertex color element was set to eByPolygonVertex
				lLayerElementVertexColor->GetIndexArray().Add(*it);

				global_index++;
			}

			// Add Materials
			for (list<string>::iterator it = material_names.begin(); it != material_names.end(); it++) {
				if (material_library) {
					Material* material = material_library->getMaterial(*it);
					if (material) {
						FbxSurfacePhong* lMaterial = material_map[material];
						if (!lMaterial) {
							lMaterial = addMaterial(material);
							material_map[material] = lMaterial;
						}

						if (lMaterial) {
							lMeshNode->AddMaterial(lMaterial);
						}
					}
				}
			}
			
			lMeshNode->SetNodeAttribute(lMesh);
			lMeshNode->SetShadingMode(FbxNode::eTextureShading);

			FbxNode *lRootNode = scene->GetRootNode();
			lRootNode->AddChild(lMeshNode);

			bind_pose->Add(lMeshNode, lMeshNode->EvaluateGlobalTransform());
		}

		if (skeleton && skin) {
			hkaSkeleton *havok_skeleton=skeleton->getSkeleton();
			
			if (havok_skeleton) {
				vector<FbxNode *> skeleton_bones;
				skeleton_bones.resize(havok_skeleton->m_bones.getSize(), NULL);

				addHavokSkeleton(skeleton_bones, havok_skeleton);

				if (lMeshNode) {
					skinModelToSkeleton(model, lMesh, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
				}

				for (auto* animation : animations) {
					if (animation) {
						hkaAnimationBinding *havok_animation_binding=animation->getAnimationBinding();
						hkaAnimation *havok_animation=animation->getAnimation();
						const string animation_name = File::nameFromFilenameNoExtension(animation->getName());
						addHavokAnimation(skeleton_bones, havok_skeleton, havok_animation_binding, havok_animation, animation_name);
					}
				}

				if (lMeshNode && model)
					addMorphModels(model, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
			}
		}
		
		else if (lMeshNode && skin) {
			vector<FbxNode *> skeleton_bones;
			addSkeleton(skeleton_bones, model);
			
			if (skeleton_bones.size()) {
				skinModelToSkeleton(model, lMesh, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
			}

			if (model)
				addMorphModels(model, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
		}

		return lMesh;
	}

	FbxMesh *FBX::addHavokCollision(string name, hkGeometry *geometry, Matrix4 transform) {
		FbxNode* lMeshNode = NULL;
		FbxMesh* lMesh = NULL;

		if (geometry) {
			lMeshNode = FbxNode::Create(scene, name.c_str());
			lMesh = FbxMesh::Create(scene, name.c_str());

			Vector3 position;
			Vector3 scale;
			Quaternion orientation;
			transform.decomposition(position, scale, orientation);

			lMeshNode->LclTranslation.Set(FbxVector4(position.x, position.y, position.z));
			lMeshNode->LclScaling.Set(FbxVector4(scale.x, scale.y, scale.z));

			FbxQuaternion lcl_quat(orientation.x, orientation.y, orientation.z, orientation.w);
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(lcl_quat);
			lMeshNode->LclRotation.Set(lcl_rotation);

			lMesh->InitControlPoints(geometry->m_vertices.getSize());
			FbxVector4* lControlPoints = lMesh->GetControlPoints();

			int index=0;
			for (index=0; index<geometry->m_vertices.getSize(); index++) {
				lControlPoints[index] = FbxVector4(geometry->m_vertices[index](0), 
												   geometry->m_vertices[index](1), 
												   geometry->m_vertices[index](2));
			}

			for (index=0; index<geometry->m_triangles.getSize(); index++) {
				lMesh->BeginPolygon();
				lMesh->AddPolygon(geometry->m_triangles[index].m_a);
				lMesh->AddPolygon(geometry->m_triangles[index].m_b);
				lMesh->AddPolygon(geometry->m_triangles[index].m_c);
				lMesh->EndPolygon();
			}
		
			lMeshNode->SetNodeAttribute(lMesh);
			FbxNode *lRootNode = scene->GetRootNode();
			lRootNode->AddChild(lMeshNode);
		}

		return lMesh;
	}
#endif

	void FBX::skinModelToSkeleton(Model *model, FbxMesh *model_mesh, vector<FbxNode *> &skeleton_bones, FbxAMatrix lSkinMatrix) {
		FbxSkin* lSkin = FbxSkin::Create(scene, "");
		vector<Bone *> model_bones=model->getBones();
		list<Vertex *> vertices=model->getVertexList();

		for (size_t i=0; i<skeleton_bones.size(); i++) {
			string bone_name = skeleton_bones[i]->GetName();
			bool found=false;
			size_t model_bone_index;

			for (model_bone_index = 0; model_bone_index<model_bones.size(); model_bone_index++) {
				if (model_bones[model_bone_index]->getName() == bone_name) {
					found = true;
					break;
				}
			}

			if (found) {
				FbxCluster *lCluster = FbxCluster::Create(scene, "");
				lCluster->SetLink(skeleton_bones[i]);
				lCluster->SetLinkMode(FbxCluster::eTotalOne);

				unsigned int index=0;
				for (list<Vertex *>::iterator it=vertices.begin(); it!=vertices.end(); it++) {
					for (size_t j=0; j<4; j++) {
						unsigned short bone_index = (*it)->getBoneIndex(j);
						if (bone_index != 0xFFFF) {
							unsigned char bone_weight = (*it)->getBoneWeight(j);
							float bone_weight_f = (float)bone_weight / 255.0;

							unsigned short real_bone_index=(*it)->getParent()->getBone(bone_index);
							if (real_bone_index == model_bone_index) {
								lCluster->AddControlPointIndex(index, bone_weight_f);
							}
						}
					}
					index++;
				}

				lCluster->SetTransformMatrix(lSkinMatrix);

				const Matrix4 matrix = model_bones[model_bone_index]->getMatrix().inverse();

				FbxAMatrix lXMatrix;
				lXMatrix.mData[0][0] = matrix.m[0][0]; lXMatrix.mData[0][1] = matrix.m[1][0]; lXMatrix.mData[0][2] = matrix.m[2][0]; lXMatrix.mData[0][3] = matrix.m[3][0];
				lXMatrix.mData[1][0] = matrix.m[0][1]; lXMatrix.mData[1][1] = matrix.m[1][1]; lXMatrix.mData[1][2] = matrix.m[2][1]; lXMatrix.mData[1][3] = matrix.m[3][1];
				lXMatrix.mData[2][0] = matrix.m[0][2]; lXMatrix.mData[2][1] = matrix.m[1][2]; lXMatrix.mData[2][2] = matrix.m[2][2]; lXMatrix.mData[2][3] = matrix.m[3][2];
				lXMatrix.mData[3][0] = matrix.m[0][3]; lXMatrix.mData[3][1] = matrix.m[1][3]; lXMatrix.mData[3][2] = matrix.m[2][3]; lXMatrix.mData[3][3] = matrix.m[3][3];

				lCluster->SetTransformLinkMatrix(lXMatrix);

				lSkin->AddCluster(lCluster);
			}
		}

		model_mesh->AddDeformer(lSkin);
	}

	void FBX::addMorphModels(Model *model, vector<FbxNode *> &skeleton_bones, FbxAMatrix lSkinMatrix) {
		if (!model) return;
		vector<MorphModel*> morph_models = model->getMorphModels();
		if (morph_models.empty()) return;

		vector<Bone*> model_bones = model->getBones();

		for (size_t mm_idx = 0; mm_idx < morph_models.size(); mm_idx++) {
			MorphModel* mm = morph_models[mm_idx];
			if (!mm || !mm->getMesh()) continue;
			const vector<Vertex*>& base_verts = mm->getVertices();
			if (base_verts.empty()) continue;
			list<unsigned int> face_list = mm->getMesh()->getFaceList();
			if (face_list.empty()) continue;
			list<string> mat_names     = mm->getMesh()->getMaterialNames();
			vector<unsigned int> mat_maps = mm->getMesh()->getMaterialMappings(mat_names);
			string node_name = model->getName() + "_morph_" + to_string(mm_idx);
			FbxNode* morph_node = FbxNode::Create(scene, node_name.c_str());
			FbxMesh* morph_mesh = FbxMesh::Create(scene, (node_name + "_mesh").c_str());
			while (morph_mesh->CreateLayer() != 3);
			FbxLayer* lLayer  = morph_mesh->GetLayer(0);
			FbxLayer* lLayer1 = morph_mesh->GetLayer(1);
			FbxLayer* lLayer2 = morph_mesh->GetLayer(2);
			FbxLayer* lLayer3 = morph_mesh->GetLayer(3);
			FbxLayerElementNormal* lNormal = (FbxLayerElementNormal*)lLayer->CreateLayerElementOfType(FbxLayerElement::eNormal);
			lNormal->SetMappingMode(FbxLayerElement::eByControlPoint);
			lNormal->SetReferenceMode(FbxLayerElement::eDirect);
			FbxLayerElementBinormal* lBinormal = (FbxLayerElementBinormal*)lLayer->CreateLayerElementOfType(FbxLayerElement::eBiNormal);
			lBinormal->SetName("UVChannel_1");
			lBinormal->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lBinormal->SetReferenceMode(FbxGeometryElement::eDirect);
			FbxLayerElementTangent* lTangent = (FbxLayerElementTangent*)lLayer->CreateLayerElementOfType(FbxLayerElement::eTangent);
			lTangent->SetName("UVChannel_1");
			lTangent->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lTangent->SetReferenceMode(FbxGeometryElement::eDirect);
			FbxLayerElementMaterial* lMaterialLayer = (FbxLayerElementMaterial*)lLayer->CreateLayerElementOfType(FbxLayerElement::eMaterial);
			lMaterialLayer->SetMappingMode(FbxLayerElement::eByPolygon);
			lMaterialLayer->SetReferenceMode(FbxLayerElement::eIndexToDirect);
			FbxLayerElementVertexColor* lColor = (FbxLayerElementVertexColor*)lLayer->CreateLayerElementOfType(FbxLayerElement::eVertexColor);
			lColor->SetMappingMode(FbxGeometryElement::eByPolygonVertex);
			lColor->SetReferenceMode(FbxGeometryElement::eIndexToDirect);
			FbxLayerElementUV* lUV1 = (FbxLayerElementUV*)lLayer->CreateLayerElementOfType(FbxLayerElement::eUV);
			lUV1->SetName("UVChannel_1");
			lUV1->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lUV1->SetReferenceMode(FbxGeometryElement::eDirect);
			FbxLayerElementUV* lUV2 = (FbxLayerElementUV*)lLayer1->CreateLayerElementOfType(FbxLayerElement::eUV);
			lUV2->SetName("UVChannel_2");
			lUV2->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lUV2->SetReferenceMode(FbxGeometryElement::eDirect);
			FbxLayerElementUV* lUV3 = (FbxLayerElementUV*)lLayer2->CreateLayerElementOfType(FbxLayerElement::eUV);
			lUV3->SetName("UVChannel_3");
			lUV3->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lUV3->SetReferenceMode(FbxGeometryElement::eDirect);
			FbxLayerElementUV* lUV4 = (FbxLayerElementUV*)lLayer3->CreateLayerElementOfType(FbxLayerElement::eUV);
			lUV4->SetName("UVChannel_4");
			lUV4->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lUV4->SetReferenceMode(FbxGeometryElement::eDirect);
			int ctrl_count = (int)base_verts.size();
			morph_mesh->InitControlPoints(ctrl_count);
			FbxVector4* lControlPoints = morph_mesh->GetControlPoints();
			for (int vi = 0; vi < ctrl_count; vi++) {
				Vector3 pos    = base_verts[vi]->getPosition();
				Vector3 normal = base_verts[vi]->getNormal();
				Vector3 binom  = base_verts[vi]->getBinormal();
				Vector3 tang   = base_verts[vi]->getTangent();
				Vector2 uv0    = base_verts[vi]->getUV(0);
				Vector2 uv1    = base_verts[vi]->getUV(1);
				Vector2 uv2    = base_verts[vi]->getUV(2);
				Vector2 uv3    = base_verts[vi]->getUV(3);
				Color   col    = base_verts[vi]->getColor();
				lControlPoints[vi] = FbxVector4(pos.x, pos.y, pos.z);
				lNormal->GetDirectArray().Add(FbxVector4(normal.x, normal.y, normal.z));
				lBinormal->GetDirectArray().Add(FbxVector4(binom.x, binom.y, binom.z));
				lTangent->GetDirectArray().Add(FbxVector4(tang.x, tang.y, tang.z));
				lUV1->GetDirectArray().Add(FbxVector2(uv0.x, 1.0 - uv0.y));
				lUV2->GetDirectArray().Add(FbxVector2(uv1.x, 1.0 - uv1.y));
				lUV3->GetDirectArray().Add(FbxVector2(uv2.x, 1.0 - uv2.y));
				lUV4->GetDirectArray().Add(FbxVector2(uv3.x, 1.0 - uv3.y));
				lColor->GetDirectArray().Add(FbxColor(col.r, col.g, col.b, col.a));
			}

			unsigned int face_idx = 0;
			unsigned int global_idx = 0;
			for (list<unsigned int>::iterator it = face_list.begin(); it != face_list.end(); it++) {
				if (face_idx == 0) {
					morph_mesh->BeginPolygon((int)mat_maps[global_idx], -1, -1, false);
				}
				morph_mesh->AddPolygon((int)(*it));
				face_idx++;
				if (face_idx >= 3) {
					morph_mesh->EndPolygon();
					face_idx = 0;
				}
				lColor->GetIndexArray().Add(*it);
				global_idx++;
			}

			for (list<string>::iterator it = mat_names.begin(); it != mat_names.end(); it++) {
				if (material_library) {
					Material* mat = material_library->getMaterial(*it);
					if (mat) {
						FbxSurfacePhong* lMaterial = material_map[mat];
						if (!lMaterial) {
							lMaterial = addMaterial(mat);
							material_map[mat] = lMaterial;
						}
						if (lMaterial) morph_node->AddMaterial(lMaterial);
					}
				}
			}

			morph_node->SetNodeAttribute(morph_mesh);
			morph_node->SetShadingMode(FbxNode::eTextureShading);
			scene->GetRootNode()->AddChild(morph_node);
			bind_pose->Add(morph_node, morph_node->EvaluateGlobalTransform());
			const vector<MorphTarget*>& morph_targets = mm->getMorphTargets();
			if (!morph_targets.empty()) {
				FbxBlendShape* blend_shape = FbxBlendShape::Create(scene, (node_name + "_BlendShape").c_str());

				for (size_t mt_idx = 0; mt_idx < morph_targets.size(); mt_idx++) {
					MorphTarget* mt = morph_targets[mt_idx];
					const vector<Vector3>& deltas = mt->getVertices();
					if ((int)deltas.size() != ctrl_count) continue;
					FbxBlendShapeChannel* channel = FbxBlendShapeChannel::Create(scene, mt->getName().c_str());
					FbxShape* shape = FbxShape::Create(scene, mt->getName().c_str());
					shape->InitControlPoints(ctrl_count);
					FbxVector4* shape_pts = shape->GetControlPoints();

					for (int vi = 0; vi < ctrl_count; vi++) {
						shape_pts[vi] = FbxVector4(
							lControlPoints[vi][0] + deltas[vi].x,
							lControlPoints[vi][1] + deltas[vi].y,
							lControlPoints[vi][2] + deltas[vi].z);
					}

					channel->AddTargetShape(shape);
					blend_shape->AddBlendShapeChannel(channel);
				}

				morph_mesh->AddDeformer(blend_shape);
			}

			if (!skeleton_bones.empty()) {
				vector<vector<unsigned short>> submesh_bone_tables;
				for (size_t slot = 0; slot < LIBGENS_MODEL_SUBMESH_SLOTS; slot++) {
					vector<Submesh*> subs = mm->getMesh()->getSubmeshes(slot);
					for (size_t si = 0; si < subs.size(); si++) {
						vector<unsigned short> bt = subs[si]->getBoneTable();
						if (!bt.empty()) submesh_bone_tables.push_back(bt);
					}
				}

				bool has_bone_tables = !submesh_bone_tables.empty();
				FbxSkin* lSkin = FbxSkin::Create(scene, "");
				for (size_t bi = 0; bi < skeleton_bones.size(); bi++) {
					if (!skeleton_bones[bi]) continue;
					string bone_name = skeleton_bones[bi]->GetName();
					size_t model_bone_index = 0;
					bool found = false;
					for (model_bone_index = 0; model_bone_index < model_bones.size(); model_bone_index++) {
						if (model_bones[model_bone_index]->getName() == bone_name) {
							found = true;
							break;
						}
					}
					if (!found) continue;
					FbxCluster* lCluster = FbxCluster::Create(scene, "");
					lCluster->SetLink(skeleton_bones[bi]);
					lCluster->SetLinkMode(FbxCluster::eTotalOne);
					for (int vi = 0; vi < ctrl_count; vi++) {
						Vertex* vtx = base_verts[vi];
						for (size_t j = 0; j < 4; j++) {
							unsigned short local_bone = vtx->getBoneIndex(j);
							if (local_bone == 0xFFFF) continue;
							unsigned char bw = vtx->getBoneWeight(j);
							if (bw == 0) continue;
							unsigned short global_bone = (unsigned short)model_bone_index + 1;
							if (has_bone_tables) {
								bool bone_found = false;
								for (size_t ti = 0; ti < submesh_bone_tables.size() && !bone_found; ti++) {
									if (local_bone < submesh_bone_tables[ti].size()) {
										global_bone = submesh_bone_tables[ti][local_bone];
										bone_found = true;
									}
								}
								if (!bone_found) continue;
							} else {
								global_bone = local_bone;
							}

							if (global_bone == model_bone_index) {
								lCluster->AddControlPointIndex(vi, (float)bw / 255.0f);
							}
						}
					}

					lCluster->SetTransformMatrix(lSkinMatrix);
					const Matrix4 bone_mat = model_bones[model_bone_index]->getMatrix().inverse();
					FbxAMatrix lXMatrix;
					lXMatrix.mData[0][0] = bone_mat.m[0][0]; lXMatrix.mData[0][1] = bone_mat.m[1][0]; lXMatrix.mData[0][2] = bone_mat.m[2][0]; lXMatrix.mData[0][3] = bone_mat.m[3][0];
					lXMatrix.mData[1][0] = bone_mat.m[0][1]; lXMatrix.mData[1][1] = bone_mat.m[1][1]; lXMatrix.mData[1][2] = bone_mat.m[2][1]; lXMatrix.mData[1][3] = bone_mat.m[3][1];
					lXMatrix.mData[2][0] = bone_mat.m[0][2]; lXMatrix.mData[2][1] = bone_mat.m[1][2]; lXMatrix.mData[2][2] = bone_mat.m[2][2]; lXMatrix.mData[2][3] = bone_mat.m[3][2];
					lXMatrix.mData[3][0] = bone_mat.m[0][3]; lXMatrix.mData[3][1] = bone_mat.m[1][3]; lXMatrix.mData[3][2] = bone_mat.m[2][3]; lXMatrix.mData[3][3] = bone_mat.m[3][3];
					lCluster->SetTransformLinkMatrix(lXMatrix);
					lSkin->AddCluster(lCluster);
				}

				morph_mesh->AddDeformer(lSkin);
			}
		}
	}

	void FBX::addSkeleton(vector<FbxNode *>& skeleton_bones, Model *model) {
		vector<Bone *> bones = model->getBones();
		
		FbxNode *lRootNode = scene->GetRootNode();
		skeleton_bones.reserve(bones.size());
		
		addBone(lRootNode, -1, skeleton_bones, bones);
	}
	
	void FBX::addBone(FbxNode *parent_node, unsigned int parent_index, vector<FbxNode *>& skeleton_bones, vector<Bone *>& bones) {
		for (size_t i = 0; i < bones.size(); i++) {
			if (bones[i]->getParentIndex() != parent_index) {
				continue;
			}
			
			string bone_name = bones[i]->getName();
			
			FbxNode *lBoneNode = FbxNode::Create(scene, bone_name.c_str());
			FbxSkeleton* lSkeletonRootAttribute = FbxSkeleton::Create(scene, bone_name.c_str());
			if (parent_index == -1) {
				lSkeletonRootAttribute->SetSkeletonType(FbxSkeleton::eRoot);
			}
			else {
				lSkeletonRootAttribute->SetSkeletonType(FbxSkeleton::eLimbNode);
			}
			lBoneNode->SetNodeAttribute(lSkeletonRootAttribute);
			
			Matrix4 bone_matrix = bones[i]->getMatrix().inverse();
			if (parent_index >= 0 && parent_index < bones.size()) {
				bone_matrix = bones[parent_index]->getMatrix() * bone_matrix;
			}
			
			Vector3 pos, sca;
			Quaternion ori;
			bone_matrix.decomposition(pos, sca, ori);
			
			lBoneNode->LclTranslation.Set(FbxVector4(pos.x, pos.y, pos.z));
			lBoneNode->LclScaling.Set(FbxVector4(sca.x, sca.y, sca.z));
			
			FbxQuaternion quaternion(ori.x, ori.y, ori.z, ori.w);
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(quaternion);
			lBoneNode->LclRotation.Set(lcl_rotation);
			
			parent_node->AddChild(lBoneNode);
			skeleton_bones.push_back(lBoneNode);

			bind_pose->Add(lBoneNode, lBoneNode->EvaluateGlobalTransform());
			
			addBone(lBoneNode, i, skeleton_bones, bones);
		}
	}

	FbxNode *FBX::addPXDBone(FbxNode *parent_node, unsigned int parent_index, vector<FbxNode *> &skeleton_bones, PXDSkeleton *skeleton) {
		FbxNode *root_bone = NULL;
		unsigned int bone_count = skeleton->getBoneCount();

		for (unsigned int b = 0; b < bone_count; b++) {
			short bone_parent = skeleton->getBoneParentIndex(b);
			if ((unsigned int)(bone_parent == -1 ? (unsigned int)-1 : (unsigned int)bone_parent) != parent_index) {
				continue;
			}

			string bone_name = skeleton->getBoneName(b);
			FbxNode *bone_node = FbxNode::Create(scene, bone_name.c_str());

			FbxSkeleton *skeleton_attribute = FbxSkeleton::Create(scene, bone_name.c_str());
			skeleton_attribute->SetSkeletonType(FbxSkeleton::eLimbNode);

			if (bone_parent == -1) {
				root_bone = bone_node;
			}

			bone_node->SetNodeAttribute(skeleton_attribute);

			Vector3 pos = skeleton->getBonePosition(b);
			Quaternion rot = skeleton->getBoneRotation(b);

			bone_node->LclTranslation.Set(FbxVector4(pos.x, pos.y, pos.z));
			FbxQuaternion lcl_quat(rot.x, rot.y, rot.z, rot.w);
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(lcl_quat);
			bone_node->LclRotation.Set(lcl_rotation);

			if (b < skeleton_bones.size()) {
				skeleton_bones[b] = bone_node;
			}
			parent_node->AddChild(bone_node);
			bind_pose->Add(bone_node, bone_node->EvaluateGlobalTransform());

			addPXDBone(bone_node, b, skeleton_bones, skeleton);
		}

		return root_bone;
	}

	FbxNode *FBX::addPXDSkeleton(vector<FbxNode *> &skeleton_bones, PXDSkeleton *skeleton) {
		FbxNode *lRootNode = scene->GetRootNode();

		string skel_name = skeleton->getName();
		FbxNode *skel_root = FbxNode::Create(scene, skel_name.c_str());
		FbxSkeleton *skel_attr = FbxSkeleton::Create(scene, skel_name.c_str());
		skel_attr->SetSkeletonType(FbxSkeleton::eRoot);
		skel_root->SetNodeAttribute(skel_attr);
		lRootNode->AddChild(skel_root);
		bind_pose->Add(skel_root, skel_root->EvaluateGlobalTransform());

		addPXDBone(skel_root, (unsigned int)-1, skeleton_bones, skeleton);
		return skel_root;
	}

	void FBX::addPXDAnimation(vector<FbxNode *> &skeleton_bones, PXDSkeleton *skeleton, PXDAnimation *animation) {
		if (!skeleton || !animation) {
			return;
		}

		string animation_name = animation->getName();
		FbxAnimStack *lAnimStack = FbxAnimStack::Create(scene, animation_name.c_str());
		FbxAnimLayer *lAnimLayer = FbxAnimLayer::Create(scene, animation_name.c_str());
		lAnimStack->AddMember(lAnimLayer);

		float duration = animation->getDuration();
		if (duration < 0.0f) {
			duration = 0.0f;
		}
		FbxTimeSpan local_time_span(FbxTimeSeconds(0), FbxTimeSeconds(duration));
		lAnimStack->SetLocalTimeSpan(local_time_span);

		float frame_rate = animation->getFrameRate();
		if (frame_rate <= 0.0f) {
			frame_rate = 30.0f;
		}

		unsigned int frame_count = animation->getFrameCount();
		unsigned int track_count = animation->getTrackCount();
		unsigned int bone_count = skeleton->getBoneCount();

		if (!animation->getIsCompressed()) {
			vector<PXDTrackKeyframes> &tracks = animation->getUncompressedTracks();

			struct BoneLocalTransform {
				Vector3 position;
				Quaternion rotation;
				Vector3 scale;
			};

			vector<BoneLocalTransform> carry(bone_count);
			for (unsigned int b = 0; b < bone_count; b++) {
				carry[b].position = skeleton->getBonePosition(b);
				carry[b].rotation = skeleton->getBoneRotation(b);
				carry[b].scale = Vector3(1.0f, 1.0f, 1.0f);
			}

			for (unsigned int frame = 0; frame < frame_count; frame++) {
				float current_time = (frame_count > 1) ? duration * ((float)frame / (float)(frame_count - 1)) : 0.0f;
				FbxTime lTime;
				lTime.SetSecondDouble(current_time);

				for (unsigned int t = 0; t < track_count && t < bone_count; t++) {
					if (t >= tracks.size()) break;
					PXDTrackKeyframes &tk = tracks[t];

					for (unsigned int i = 0; i < tk.loc_frames.size(); i++) {
						if (tk.loc_frames[i] == frame) {
							carry[t].position = tk.loc_values[i];
							break;
						}
					}

					for (unsigned int i = 0; i < tk.rot_frames.size(); i++) {
						if (tk.rot_frames[i] == frame) {
							carry[t].rotation = tk.rot_values[i];
							break;
						}
					}

					for (unsigned int i = 0; i < tk.scale_frames.size(); i++) {
						if (tk.scale_frames[i] == frame) {
							carry[t].scale = tk.scale_values[i];
							break;
						}
					}
				}

				vector<float> model_scale(bone_count, 1.0f);
				for (unsigned int k = 0; k < bone_count; k++) {
					float local_s = carry[k].scale.x;
					if (local_s == 0.0f) local_s = 1.0f;
					short par = skeleton->getBoneParentIndex(k);
					if (par >= 0 && (unsigned int)par < bone_count) {
						model_scale[k] = local_s * model_scale[(unsigned int)par];
					} else {
						model_scale[k] = local_s;
					}
				}

				for (unsigned int b = 0; b < bone_count; b++) {
					if (b >= skeleton_bones.size() || !skeleton_bones[b]) continue;

					Vector3 pos = carry[b].position;
					Quaternion rot = carry[b].rotation;
					float uniform_scale = carry[b].scale.x;
					if (uniform_scale == 0.0f) uniform_scale = 1.0f;

					short parent_id = skeleton->getBoneParentIndex(b);
					if (parent_id >= 0 && (unsigned int)parent_id < bone_count) {
						float pms = model_scale[(unsigned int)parent_id];
						if (pms != 0.0f) {
							pos.x /= pms;
							pos.y /= pms;
							pos.z /= pms;
						}
					}

					FbxQuaternion lcl_quat(rot.x, rot.y, rot.z, rot.w);
					FbxVector4 lcl_rotation;
					lcl_rotation.SetXYZ(lcl_quat);

					FbxAnimCurve *curveTX = skeleton_bones[b]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
					FbxAnimCurve *curveTY = skeleton_bones[b]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
					FbxAnimCurve *curveTZ = skeleton_bones[b]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);
					FbxAnimCurve *curveRX = skeleton_bones[b]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
					FbxAnimCurve *curveRY = skeleton_bones[b]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
					FbxAnimCurve *curveRZ = skeleton_bones[b]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);
					FbxAnimCurve *curveSX = skeleton_bones[b]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
					FbxAnimCurve *curveSY = skeleton_bones[b]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
					FbxAnimCurve *curveSZ = skeleton_bones[b]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

					if (curveTX) { curveTX->KeyModifyBegin(); int k = curveTX->KeyAdd(lTime); curveTX->KeySetValue(k, pos.x); curveTX->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveTX->KeyModifyEnd(); }
					if (curveTY) { curveTY->KeyModifyBegin(); int k = curveTY->KeyAdd(lTime); curveTY->KeySetValue(k, pos.y); curveTY->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveTY->KeyModifyEnd(); }
					if (curveTZ) { curveTZ->KeyModifyBegin(); int k = curveTZ->KeyAdd(lTime); curveTZ->KeySetValue(k, pos.z); curveTZ->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveTZ->KeyModifyEnd(); }
					if (curveSX) { curveSX->KeyModifyBegin(); int k = curveSX->KeyAdd(lTime); curveSX->KeySetValue(k, uniform_scale); curveSX->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveSX->KeyModifyEnd(); }
					if (curveSY) { curveSY->KeyModifyBegin(); int k = curveSY->KeyAdd(lTime); curveSY->KeySetValue(k, uniform_scale); curveSY->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveSY->KeyModifyEnd(); }
					if (curveSZ) { curveSZ->KeyModifyBegin(); int k = curveSZ->KeyAdd(lTime); curveSZ->KeySetValue(k, uniform_scale); curveSZ->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveSZ->KeyModifyEnd(); }
					if (curveRX) { curveRX->KeyModifyBegin(); int k = curveRX->KeyAdd(lTime); curveRX->KeySetValue(k, lcl_rotation[0]); curveRX->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveRX->KeyModifyEnd(); }
					if (curveRY) { curveRY->KeyModifyBegin(); int k = curveRY->KeyAdd(lTime); curveRY->KeySetValue(k, lcl_rotation[1]); curveRY->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveRY->KeyModifyEnd(); }
					if (curveRZ) { curveRZ->KeyModifyBegin(); int k = curveRZ->KeyAdd(lTime); curveRZ->KeySetValue(k, lcl_rotation[2]); curveRZ->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveRZ->KeyModifyEnd(); }
				}
			}
		}
		else {
			vector<vector<PXDTransform>> &frames = animation->getCompressedFrames();

			for (unsigned int frame = 0; frame < frame_count; frame++) {
				if (frame >= frames.size()) break;
				float current_time = (frame_count > 1) ? duration * ((float)frame / (float)(frame_count - 1)) : 0.0f;
				FbxTime lTime;
				lTime.SetSecondDouble(current_time);

				vector<float> model_scale(bone_count, 1.0f);
				for (unsigned int k = 0; k < bone_count && k < track_count; k++) {
					if (k >= frames[frame].size()) continue;
					float local_s = frames[frame][k].scale.x;
					if (local_s == 0.0f) local_s = 1.0f;
					short par = skeleton->getBoneParentIndex(k);
					if (par >= 0 && (unsigned int)par < bone_count) {
						model_scale[k] = local_s * model_scale[(unsigned int)par];
					} else {
						model_scale[k] = local_s;
					}
				}

				for (unsigned int b = 0; b < bone_count && b < track_count; b++) {
					if (b >= skeleton_bones.size() || !skeleton_bones[b]) continue;
					if (b >= frames[frame].size()) continue;

					PXDTransform &xform = frames[frame][b];
					Vector3 pos = xform.position;
					Quaternion rot = xform.rotation;
					float uniform_scale = xform.scale.x;
					if (uniform_scale == 0.0f) uniform_scale = 1.0f;

					short parent_id = skeleton->getBoneParentIndex(b);
					if (parent_id >= 0 && (unsigned int)parent_id < bone_count) {
						float pms = model_scale[(unsigned int)parent_id];
						if (pms != 0.0f) {
							pos.x /= pms;
							pos.y /= pms;
							pos.z /= pms;
						}
					}

					FbxQuaternion lcl_quat(rot.x, rot.y, rot.z, rot.w);
					FbxVector4 lcl_rotation;
					lcl_rotation.SetXYZ(lcl_quat);

					FbxAnimCurve *curveTX = skeleton_bones[b]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
					FbxAnimCurve *curveTY = skeleton_bones[b]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
					FbxAnimCurve *curveTZ = skeleton_bones[b]->LclTranslation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);
					FbxAnimCurve *curveRX = skeleton_bones[b]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
					FbxAnimCurve *curveRY = skeleton_bones[b]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
					FbxAnimCurve *curveRZ = skeleton_bones[b]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);
					FbxAnimCurve *curveSX = skeleton_bones[b]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true);
					FbxAnimCurve *curveSY = skeleton_bones[b]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true);
					FbxAnimCurve *curveSZ = skeleton_bones[b]->LclScaling.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true);

					if (curveTX) { curveTX->KeyModifyBegin(); int k = curveTX->KeyAdd(lTime); curveTX->KeySetValue(k, pos.x); curveTX->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveTX->KeyModifyEnd(); }
					if (curveTY) { curveTY->KeyModifyBegin(); int k = curveTY->KeyAdd(lTime); curveTY->KeySetValue(k, pos.y); curveTY->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveTY->KeyModifyEnd(); }
					if (curveTZ) { curveTZ->KeyModifyBegin(); int k = curveTZ->KeyAdd(lTime); curveTZ->KeySetValue(k, pos.z); curveTZ->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveTZ->KeyModifyEnd(); }
					if (curveSX) { curveSX->KeyModifyBegin(); int k = curveSX->KeyAdd(lTime); curveSX->KeySetValue(k, uniform_scale); curveSX->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveSX->KeyModifyEnd(); }
					if (curveSY) { curveSY->KeyModifyBegin(); int k = curveSY->KeyAdd(lTime); curveSY->KeySetValue(k, uniform_scale); curveSY->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveSY->KeyModifyEnd(); }
					if (curveSZ) { curveSZ->KeyModifyBegin(); int k = curveSZ->KeyAdd(lTime); curveSZ->KeySetValue(k, uniform_scale); curveSZ->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveSZ->KeyModifyEnd(); }
					if (curveRX) { curveRX->KeyModifyBegin(); int k = curveRX->KeyAdd(lTime); curveRX->KeySetValue(k, lcl_rotation[0]); curveRX->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveRX->KeyModifyEnd(); }
					if (curveRY) { curveRY->KeyModifyBegin(); int k = curveRY->KeyAdd(lTime); curveRY->KeySetValue(k, lcl_rotation[1]); curveRY->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveRY->KeyModifyEnd(); }
					if (curveRZ) { curveRZ->KeyModifyBegin(); int k = curveRZ->KeyAdd(lTime); curveRZ->KeySetValue(k, lcl_rotation[2]); curveRZ->KeySetInterpolation(k, FbxAnimCurveDef::eInterpolationLinear); curveRZ->KeyModifyEnd(); }
				}
			}
		}

		FbxAnimCurveFilterUnroll lFilter;
		for (size_t i = 0; i < skeleton_bones.size(); i++) {
			if (!skeleton_bones[i]) continue;

			FbxAnimCurve *lCurve[3];
			lCurve[0] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
			lCurve[1] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
			lCurve[2] = skeleton_bones[i]->LclRotation.GetCurve(lAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);

			if (lCurve[0] && lCurve[1] && lCurve[2] && lFilter.NeedApply(lCurve, 3)) {
				lFilter.Apply(lCurve, 3);
			}
		}
	}

	FbxMesh *FBX::addPXDNode(Model *model, PXDSkeleton *skeleton, vector<PXDAnimation *> animations, Matrix4 transform_matrix, bool skin) {
		FbxNode *lMeshNode = NULL;
		FbxMesh *lMesh = NULL;
		string model_name = "Dummy";

		if (model) {
			model_name = model->getName();
			models.push_back(model);

			lMeshNode = FbxNode::Create(scene, model_name.c_str());
			lMesh = FbxMesh::Create(scene, (model_name + "_mesh").c_str());

			while (lMesh->CreateLayer() != 3);
			FbxLayer *lLayer = lMesh->GetLayer(0);
			FbxLayer *lLayer1 = lMesh->GetLayer(1);
			FbxLayer *lLayer2 = lMesh->GetLayer(2);
			FbxLayer *lLayer3 = lMesh->GetLayer(3);

			Vector3 position;
			Vector3 scale;
			Quaternion orientation;
			transform_matrix.decomposition(position, scale, orientation);

			lMeshNode->LclTranslation.Set(FbxVector4(position.x, position.y, position.z));
			lMeshNode->LclScaling.Set(FbxVector4(scale.x, scale.y, scale.z));

			FbxQuaternion lcl_quat(orientation.x, orientation.y, orientation.z, orientation.w);
			FbxVector4 lcl_rotation;
			lcl_rotation.SetXYZ(lcl_quat);
			lMeshNode->LclRotation.Set(lcl_rotation);

			list<Vertex *> model_vertices;
			list<unsigned int> model_faces;
			list<string> material_names;
			vector<unsigned int> material_mappings;
			model->getTotalData(model_vertices, model_faces, material_names, material_mappings);

			lMesh->InitControlPoints(model_vertices.size());
			FbxVector4 *lControlPoints = lMesh->GetControlPoints();

			FbxLayerElementNormal *lLayerElementNormal = (FbxLayerElementNormal *)lLayer->CreateLayerElementOfType(FbxLayerElement::eNormal);
			lLayerElementNormal->SetMappingMode(FbxLayerElement::eByControlPoint);
			lLayerElementNormal->SetReferenceMode(FbxLayerElement::eDirect);

			FbxLayerElementBinormal *lLayerElementBinormal = (FbxLayerElementBinormal *)lLayer->CreateLayerElementOfType(FbxLayerElement::eBiNormal);
			lLayerElementBinormal->SetName("UVChannel_1");
			lLayerElementBinormal->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerElementBinormal->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementTangent *lLayerElementTangent = (FbxLayerElementTangent *)lLayer->CreateLayerElementOfType(FbxLayerElement::eTangent);
			lLayerElementTangent->SetName("UVChannel_1");
			lLayerElementTangent->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerElementTangent->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementMaterial *lMaterialLayer = (FbxLayerElementMaterial *)lLayer->CreateLayerElementOfType(FbxLayerElement::eMaterial);
			lMaterialLayer->SetMappingMode(FbxLayerElement::eByPolygon);
			lMaterialLayer->SetReferenceMode(FbxLayerElement::eIndexToDirect);

			FbxLayerElementVertexColor *lLayerElementVertexColor = (FbxLayerElementVertexColor *)lLayer->CreateLayerElementOfType(FbxLayerElement::eVertexColor);
			lLayerElementVertexColor->SetMappingMode(FbxGeometryElement::eByPolygonVertex);
			lLayerElementVertexColor->SetReferenceMode(FbxGeometryElement::eIndexToDirect);

			FbxLayerElementUV *lLayerUVElement = (FbxLayerElementUV *)lLayer->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUVElement->SetName("UVChannel_1");
			lLayerUVElement->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUVElement->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementUV *lLayerUV2Element = (FbxLayerElementUV *)lLayer1->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV2Element->SetName("UVChannel_2");
			lLayerUV2Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV2Element->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementUV *lLayerUV3Element = (FbxLayerElementUV *)lLayer2->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV3Element->SetName("UVChannel_3");
			lLayerUV3Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV3Element->SetReferenceMode(FbxGeometryElement::eDirect);

			FbxLayerElementUV *lLayerUV4Element = (FbxLayerElementUV *)lLayer3->CreateLayerElementOfType(FbxLayerElement::eUV);
			lLayerUV4Element->SetName("UVChannel_4");
			lLayerUV4Element->SetMappingMode(FbxGeometryElement::eByControlPoint);
			lLayerUV4Element->SetReferenceMode(FbxGeometryElement::eDirect);

			unsigned int index = 0;
			for (list<Vertex *>::iterator it = model_vertices.begin(); it != model_vertices.end(); it++) {
				Vector3 position = (*it)->getPosition();
				Vector3 normal = (*it)->getNormal();
				Vector3 binormal = (*it)->getBinormal();
				Vector3 tangent = (*it)->getTangent();
				Vector2 uv_0 = (*it)->getUV(0);
				Vector2 uv_1 = (*it)->getUV(1);
				Vector2 uv_2 = (*it)->getUV(2);
				Vector2 uv_3 = (*it)->getUV(3);
				Color color = (*it)->getColor();

				lControlPoints[index] = FbxVector4(position.x, position.y, position.z);
				lLayerElementNormal->GetDirectArray().Add(FbxVector4(normal.x, normal.y, normal.z));
				lLayerElementBinormal->GetDirectArray().Add(FbxVector4(binormal.x, binormal.y, binormal.z));
				lLayerElementTangent->GetDirectArray().Add(FbxVector4(tangent.x, tangent.y, tangent.z));
				lLayerUVElement->GetDirectArray().Add(FbxVector2(uv_0.x, 1.0 - uv_0.y));
				lLayerUV2Element->GetDirectArray().Add(FbxVector2(uv_1.x, 1.0 - uv_1.y));
				lLayerUV3Element->GetDirectArray().Add(FbxVector2(uv_2.x, 1.0 - uv_2.y));
				lLayerUV4Element->GetDirectArray().Add(FbxVector2(uv_3.x, 1.0 - uv_3.y));
				lLayerElementVertexColor->GetDirectArray().Add(FbxColor(color.r, color.g, color.b, color.a));
				index++;
			}

			unsigned int face_index = 0;
			unsigned int global_index = 0;
			for (list<unsigned int>::iterator it = model_faces.begin(); it != model_faces.end(); it++) {
				if (face_index == 0) {
					lMesh->BeginPolygon(material_mappings[global_index], -1, -1, false);
				}

				lMesh->AddPolygon((*it));

				face_index++;
				if (face_index >= 3) {
					lMesh->EndPolygon();
					face_index = 0;
				}

				lLayerElementVertexColor->GetIndexArray().Add(*it);
				global_index++;
			}

			for (list<string>::iterator it = material_names.begin(); it != material_names.end(); it++) {
				if (material_library) {
					Material *material = material_library->getMaterial(*it);
					if (material) {
						FbxSurfacePhong *lMaterial = material_map[material];
						if (!lMaterial) {
							lMaterial = addMaterial(material);
							material_map[material] = lMaterial;
						}

						if (lMaterial) {
							lMeshNode->AddMaterial(lMaterial);
						}
					}
				}
			}

			lMeshNode->SetNodeAttribute(lMesh);
			lMeshNode->SetShadingMode(FbxNode::eTextureShading);

			FbxNode *lRootNode = scene->GetRootNode();
			lRootNode->AddChild(lMeshNode);

			bind_pose->Add(lMeshNode, lMeshNode->EvaluateGlobalTransform());
		}

		if (skeleton && skin) {
			vector<FbxNode *> skeleton_bones;
			skeleton_bones.resize(skeleton->getBoneCount(), NULL);

			addPXDSkeleton(skeleton_bones, skeleton);

			if (lMeshNode && model) {
				skinModelToSkeleton(model, lMesh, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
			}

			for (size_t a = 0; a < animations.size(); a++) {
				if (animations[a]) {
					addPXDAnimation(skeleton_bones, skeleton, animations[a]);
				}
			}

			if (lMeshNode && model)
				addMorphModels(model, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
		}
		else if (lMeshNode && skin && model) {
			vector<FbxNode *> skeleton_bones;
			addSkeleton(skeleton_bones, model);

			if (skeleton_bones.size()) {
				skinModelToSkeleton(model, lMesh, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
			}

			addMorphModels(model, skeleton_bones, lMeshNode->EvaluateGlobalTransform());
		}

		return lMesh;
	}
}

#endif