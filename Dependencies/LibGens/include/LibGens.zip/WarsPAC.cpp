//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "WarsPAC.h"

#include <stdint.h>
#include "lz4/lz4.h"

namespace LibGens {
WarsPacExtension forces_exts[] = {
		{ "dds", "ResTexture", 1 },
		{ "model", "ResModel", 1 },
		{ "terrain-model", "ResMirageTerrainModel", 1 },
		{ "material", "ResMirageMaterial", 1 },
		{ "swif", "ResSurfRideProject", 0 },
		{ "terrain-instanceinfo", "ResMirageTerrainInstanceInfo", 0 },
		{ "uv-anim", "ResAnimTexSrt", 1 },
		{ "cemt", "ResCyanEffect", 0 },
		{ "rfl", "ResReflection", 0 },
		{ "skl.hkx", "ResSkeleton", 0 },
		{ "anm.hkx", "ResAnimSkeleton", 0 },
		{ "mat-anim", "ResAnimMaterial", 1 },
		{ "codetbl", "ResCodeTable", 0 },
		{ "cnvrs-text", "ResText", 0 },
		{ "light", "ResMirageLight", 0 },
		{ "asm", "ResAnimator", 0 },
		{ "model-instanceinfo", "ResModelInstanceInfo", 0 },
		{ "cam-anim", "ResAnimCameraContainer", 1 },
		{ "gedit", "ResObjectWorld", 0 },
		{ "phy.hkx", "ResHavokMesh", 0 },
		{ "vis-anim", "ResAnimVis", 1 },
		{ "grass.bin", "ResTerrainGrassInfo", 0 },
		{ "scene", "ResScene", 0 },
		{ "effdb", "ResParticleLocation", 0 },
		{ "shlf", "ResSHLightField", 0 },
		{ "gism", "ResGismoConfig", 0 },
		{ "probe", "ResProbe", 0 },
		{ "svcol.bin", "ResSvCol", 0 },
		{ "fxcol.bin", "ResFxColFile", 0 },
		{ "path", "ResSplinePath", 0 },
		{ "pt-anim", "ResAnimTexPat", 1 },
		{ "lit-anim", "ResAnimLightContainer", 1 },
		{ "cnvrs-proj", "ResTextProject", 0 },
		{ "cnvrs-meta", "ResTextMeta", 0 },
		{ "scfnt", "ResScalableFontSet", 0 },
		{ "pso", "ResMiragePixelShader", 1 },
		{ "vso", "ResMirageVertexShader", 1 },
		{ "shader-list", "ResShaderList", 0 },
		{ "vib", "ResVibration", 0 },
		{ "bfnt", "ResBitmapFont", 0 },
		{ "hhd", "ResCustomData", 0 },
		{ "lua", "ResLuaData", 0 },
		{ "lft", "ResMirageLightField", 0 },
		{ "xtb2", "ResXTB2Data", 0 }
	};

	class WarsPacChunk {
		public:
			unsigned int compressed_size;
			unsigned int uncompressed_size;
	};

	class WarsPacDependency {
		public:
			string name;
			vector<unsigned char> data;
			vector<WarsPacChunk> chunks;
			unsigned int compressed_size;
			unsigned int uncompressed_size;
	};

	class WarsPacStringPatch {
		public:
			string value;
			size_t address;
	};

	class WarsPacEntryPatch {
		public:
			unsigned int index;
			size_t address;
	};

	class WarsPacDataPatch {
		public:
			unsigned int index;
			size_t address;
	};

	class WarsPacData {
		public:
			vector<unsigned char> data;
			vector<size_t> dependency_data_addresses;
	};

	class WarsPacWriter {
		public:
			vector<unsigned char> data;

			size_t getAddress() {
				return data.size();
			}

			void writeU8(unsigned char v) {
				data.push_back(v);
			}

			void writeU16(unsigned int v) {
				data.push_back((unsigned char)(v & 0xFF));
				data.push_back((unsigned char)((v >> 8) & 0xFF));
			}

			void writeS16(int v) {
				writeU16((unsigned int)(unsigned short)v);
			}

			void writeU32(unsigned int v) {
				data.push_back((unsigned char)(v & 0xFF));
				data.push_back((unsigned char)((v >> 8) & 0xFF));
				data.push_back((unsigned char)((v >> 16) & 0xFF));
				data.push_back((unsigned char)((v >> 24) & 0xFF));
			}

			void writeS32(int v) {
				writeU32((unsigned int)v);
			}

			void writeU64(uint64_t v) {
				for (int i=0; i<8; i++) {
					data.push_back((unsigned char)((v >> (i * 8)) & 0xFF));
				}
			}

			void write(void *source, size_t size) {
				unsigned char *bytes = (unsigned char *) source;
				data.insert(data.end(), bytes, bytes + size);
			}

			void writeString(const char *text) {
				while (*text) {
					writeU8((unsigned char) *text);
					text++;
				}
			}

			void writeStringZ(string text) {
				if (text.size()) {
					write((void *) text.data(), text.size());
				}

				writeU8(0);
			}

			void writeNull(size_t size) {
				data.insert(data.end(), size, 0);
			}

			void fixPadding(size_t size) {
				size_t padding = (size - (getAddress() % size)) % size;
				writeNull(padding);
			}

			void writeVersion(int v) {
				writeU8((unsigned char)('0' + ((v / 100) % 10)));
				writeU8((unsigned char)('0' + ((v / 10) % 10)));
				writeU8((unsigned char)('0' + (v % 10)));
				writeU8('L');
			}

			void writeOffset(size_t address, uint64_t v) {
				if ((address + 8) > data.size()) return;

				for (int i=0; i<8; i++) {
					data[address+i] = (unsigned char)((v >> (i * 8)) & 0xFF);
				}
			}

			void writeFixedInt(size_t address, unsigned int v) {
				if ((address + 4) > data.size()) return;

				data[address+0] = (unsigned char)(v & 0xFF);
				data[address+1] = (unsigned char)((v >> 8) & 0xFF);
				data[address+2] = (unsigned char)((v >> 16) & 0xFF);
				data[address+3] = (unsigned char)((v >> 24) & 0xFF);
			}
	};

	string WarsPacLowerString(string text) {
		for (size_t i=0; i<text.size(); i++) {
			text[i] = (char) tolower((unsigned char) text[i]);
		}

		return text;
	}

	string WarsPacExtensionFromName(string filename) {
		size_t slash = filename.find_last_of("\\/");
		size_t start = (slash == string::npos) ? 0 : (slash + 1);
		size_t dot = filename.find('.', start);

		if (dot == string::npos) return "";
		return filename.substr(dot + 1);
	}

	string WarsPacNameFromName(string filename) {
		size_t slash = filename.find_last_of("\\/");
		size_t start = (slash == string::npos) ? 0 : (slash + 1);
		size_t dot = filename.find('.', start);

		if (dot == string::npos) return filename;
		return filename.substr(0, dot);
	}

	void WarsPacCreateDirectoryTree(string folder) {
		if (!folder.size()) return;

		for (size_t i=0; i<folder.size(); i++) {
			if (((folder[i] == '/') || (folder[i] == '\\')) && i) {
				string part = folder.substr(0, i);
				if (part.size() && (part[part.size()-1] != ':')) {
					CreateDirectory(part.c_str(), NULL);
				}
			}
		}

		if ((folder[folder.size()-1] != '/') && (folder[folder.size()-1] != '\\')) {
			CreateDirectory(folder.c_str(), NULL);
		}
	}

	int WarsPacReadFile(string filename, vector<unsigned char> *data) {
		File file(filename, LIBGENS_FILE_READ_BINARY);
		if (!file.valid()) return 0;

		size_t file_size = file.getFileSize();
		data->resize(file_size);
		if (file_size) {
			file.read(&(*data)[0], file_size);
		}

		file.close();
		return 1;
	}

	void WarsPacWriteFile(string filename, vector<unsigned char> *data) {
		WarsPacCreateDirectoryTree(File::folderFromFilename(filename));

		File file(filename, LIBGENS_FILE_WRITE_BINARY);
		if (!file.valid()) return;

		if (data->size()) {
			file.write(&(*data)[0], data->size());
		}

		file.close();
	}

	unsigned int WarsPacUid(string text) {
		unsigned int hash = 2166136261U;

		for (size_t i=0; i<text.size(); i++) {
			hash ^= (unsigned char) text[i];
			hash *= 16777619U;
		}

		return hash ? hash : 1;
	}

	void WarsPacPatchOffset(WarsPacWriter *writer, size_t address, uint64_t value, vector<uint64_t> *offsets) {
		writer->writeOffset(address, value);
		offsets->push_back(address);
	}

	void WarsPacWriteOffsetTable(WarsPacWriter *writer, vector<uint64_t> offsets, uint64_t base) {
		sort(offsets.begin(), offsets.end());

		uint64_t current_address = base;
		for (size_t i=0; i<offsets.size(); i++) {
			if (offsets[i] < current_address) continue;

			uint64_t difference = (offsets[i] - current_address) >> 2;
			if (difference <= 0x3F) {
				writer->writeU8((unsigned char)(0x40 | difference));
			}
			else if (difference <= 0x3FFF) {
				writer->writeU8((unsigned char)(0x80 | ((difference >> 8) & 0x3F)));
				writer->writeU8((unsigned char)(difference & 0xFF));
			}
			else {
				writer->writeU8((unsigned char)(0xC0 | ((difference >> 24) & 0x3F)));
				writer->writeU8((unsigned char)((difference >> 16) & 0xFF));
				writer->writeU8((unsigned char)((difference >> 8) & 0xFF));
				writer->writeU8((unsigned char)(difference & 0xFF));
			}

			current_address = offsets[i];
		}
	}

	void WarsPacWriteStrings(WarsPacWriter *writer, vector<WarsPacStringPatch> *strings, vector<uint64_t> *offsets) {
		map<string, uint64_t> string_addresses;

		for (size_t i=0; i<strings->size(); i++) {
			WarsPacStringPatch *patch = &(*strings)[i];

			if (!string_addresses.count(patch->value)) {
				string_addresses[patch->value] = writer->getAddress();
				writer->writeStringZ(patch->value);
			}

			writer->writeOffset(patch->address, string_addresses[patch->value]);
			offsets->push_back(patch->address);
		}

		writer->fixPadding(4);
	}

	size_t WarsPacWriteNode(WarsPacWriter *writer, string name, uint64_t data_address,
		int parent_index, int global_index, int data_index, unsigned short child_count,
		unsigned char has_data, unsigned char buffer_index, vector<WarsPacStringPatch> *strings) {
		size_t node_address = writer->getAddress();

		writer->writeU64(0);
		writer->writeU64(data_address);
		writer->writeU64(0);
		writer->writeS32(parent_index);
		writer->writeS32(global_index);
		writer->writeS32(data_index);
		writer->writeU16(child_count);
		writer->writeU8(has_data);
		writer->writeU8(buffer_index);

		if (name.size()) {
			WarsPacStringPatch patch;
			patch.value = name;
			patch.address = node_address;
			strings->push_back(patch);
		}

		return node_address;
	}

	int WarsPacCompareChar(char c) {
		if (c == '_') return 0;
		return tolower((unsigned char)c);
	}

	class WarsPacRadixNode {
		public:
			string name;
			int data;
			WarsPacRadixNode *parent;
			vector<WarsPacRadixNode *> children;
			int global_index;
			int data_node_index;
			size_t address;

			WarsPacRadixNode() {
				data = -1;
				parent = NULL;
				global_index = -1;
				data_node_index = -1;
				address = 0;
			}

			WarsPacRadixNode(string node_name, int node_data, WarsPacRadixNode *node_parent) {
				name = node_name;
				data = node_data;
				parent = node_parent;
				global_index = -1;
				data_node_index = -1;
				address = 0;
			}

			~WarsPacRadixNode() {
				for (size_t i=0; i<children.size(); i++) {
					delete children[i];
				}
			}

			unsigned int countNodes() {
				unsigned int count = 1;
				if (data != -1) count++;

				for (size_t i=0; i<children.size(); i++) {
					count += children[i]->countNodes();
				}

				return count;
			}

			unsigned int countData() {
				unsigned int count = (data != -1) ? 1 : 0;

				for (size_t i=0; i<children.size(); i++) {
					count += children[i]->countData();
				}

				return count;
			}

			size_t matchLength(string key) {
				size_t size = (name.size() < key.size()) ? name.size() : key.size();
				size_t i = 0;

				for (; i<size; i++) {
					if (name[i] != key[i]) break;
				}

				return i;
			}

			WarsPacRadixNode *insert(string key, int node_data) {
				WarsPacRadixNode *current = this;
				WarsPacRadixNode *match_node = NULL;
				size_t match_index = 0;
				size_t match_length = 0;
				size_t i = 0;

				while (i < current->children.size()) {
					WarsPacRadixNode *child = current->children[i];
					size_t current_match = child->matchLength(key);

					if (!current_match) {
						i++;
						continue;
					}

					if ((current_match == key.size()) && (current_match == child->name.size())) {
						child->data = node_data;
						return child;
					}

					match_node = child;
					match_index = i;
					match_length = current_match;

					if (current_match == child->name.size()) {
						key = key.substr(current_match);
						current = child;
						i = 0;
					}
					else {
						break;
					}
				}

				if (match_length && (match_length != match_node->name.size())) {
					string split_name = match_node->name.substr(0, match_length);
					string old_name = match_node->name.substr(match_length);
					string new_name = key.substr(match_length);
					WarsPacRadixNode *split_node = new WarsPacRadixNode(split_name, -1, match_node->parent);
					WarsPacRadixNode *new_node = NULL;

					match_node->name = old_name;
					match_node->parent = split_node;

					if (new_name.size()) {
						new_node = new WarsPacRadixNode(new_name, node_data, split_node);

						if (WarsPacCompareChar(new_name[0]) > WarsPacCompareChar(old_name[0])) {
							split_node->children.push_back(match_node);
							split_node->children.push_back(new_node);
						}
						else {
							split_node->children.push_back(new_node);
							split_node->children.push_back(match_node);
						}
					}
					else {
						split_node->data = node_data;
						split_node->children.push_back(match_node);
						new_node = split_node;
					}

					current->children[match_index] = split_node;
					return new_node;
				}

				WarsPacRadixNode *node = new WarsPacRadixNode(key, node_data, current);
				current->children.push_back(node);
				return node;
			}

			void writeNodes(WarsPacWriter *writer, int parent_index, int *node_index, int *data_index,
				unsigned char buffer_index, vector<WarsPacStringPatch> *strings,
				vector<int> *data_indices, vector<int> *data_order, vector<size_t> *data_addresses) {
				unsigned short child_count = (unsigned short) children.size();
				if (data != -1) child_count++;

				global_index = *node_index;
				address = WarsPacWriteNode(writer, name, 0, parent_index, global_index, -1,
					child_count, 0, buffer_index, strings);

				(*node_index)++;
				parent_index = global_index;
				buffer_index = (unsigned char)(buffer_index + name.size());

				if (data != -1) {
					data_node_index = *node_index;
					size_t data_node_address = WarsPacWriteNode(writer, "", 0, parent_index,
						data_node_index, *data_index, 0, 1, buffer_index, strings);

					data_indices->push_back(data_node_index);
					data_order->push_back(data);
					if (((size_t)data) >= data_addresses->size()) data_addresses->resize(data + 1);
					(*data_addresses)[data] = data_node_address + 8;

					(*node_index)++;
					(*data_index)++;
				}

				for (size_t i=0; i<children.size(); i++) {
					children[i]->writeNodes(writer, parent_index, node_index, data_index,
						buffer_index, strings, data_indices, data_order, data_addresses);
				}
			}

			void writeChildIndices(WarsPacWriter *writer, vector<uint64_t> *offsets) {
				if ((data != -1) || children.size()) {
					WarsPacPatchOffset(writer, address + 16, writer->getAddress(), offsets);

					if (data != -1) {
						writer->writeS32(data_node_index);
					}

					for (size_t i=0; i<children.size(); i++) {
						writer->writeS32(children[i]->global_index);
					}

					writer->fixPadding(8);
				}

				for (size_t i=0; i<children.size(); i++) {
					children[i]->writeChildIndices(writer, offsets);
				}
			}
	};

	class WarsPacRadixTree {
		public:
			WarsPacRadixNode root;
			size_t data_indices_address;
			vector<int> data_indices;
			vector<int> data_order;
			vector<size_t> data_addresses;

			WarsPacRadixTree() {
				data_indices_address = 0;
			}

			void insert(string key, int data) {
				root.insert(key, data);
			}

			void writeNodes(WarsPacWriter *writer, vector<WarsPacStringPatch> *strings,
				vector<uint64_t> *offsets) {
				writer->writeU32(root.countNodes());
				writer->writeU32(root.countData());
				size_t nodes_address = writer->getAddress();
				writer->writeU64(0);
				data_indices_address = writer->getAddress();
				writer->writeU64(0);

				WarsPacPatchOffset(writer, nodes_address, writer->getAddress(), offsets);

				int node_index = 0;
				int data_index = 0;
				root.writeNodes(writer, -1, &node_index, &data_index, 0, strings,
					&data_indices, &data_order, &data_addresses);
			}

			void writeDataIndices(WarsPacWriter *writer, vector<uint64_t> *offsets) {
				if (!data_indices.size()) return;

				WarsPacPatchOffset(writer, data_indices_address, writer->getAddress(), offsets);

				for (size_t i=0; i<data_indices.size(); i++) {
					writer->writeS32(data_indices[i]);
				}

				writer->fixPadding(8);
			}

			void writeChildIndices(WarsPacWriter *writer, vector<uint64_t> *offsets) {
				root.writeChildIndices(writer, offsets);
			}
	};

	void WarsPacBuildGroups(vector<WarsPacFile *> *files, unsigned short split_index,
		vector<vector<unsigned int> > *groups, vector<string> *types) {
		for (unsigned int i=0; i<files->size(); i++) {
			WarsPacFile *file = (*files)[i];

			if ((split_index != 0xFFFF) && (file->split_index != split_index)) {
				continue;
			}

			if (!types->size() || ((*types)[types->size()-1] != file->type)) {
				types->push_back(file->type);
				groups->push_back(vector<unsigned int>());
			}

			(*groups)[groups->size()-1].push_back(i);
		}
	}

	int WarsPacEntryIsHere(WarsPacFile *file, unsigned short split_index) {
		if (split_index == 0xFFFF) {
			return file->split_index == 0xFFFF;
		}

		return file->split_index == split_index;
	}

	int WarsPacEntryHasBina(WarsPacFile *file) {
		if (file->data.size() < 4) return 0;
		return (file->data[0] == 'B') && (file->data[1] == 'I') && (file->data[2] == 'N') && (file->data[3] == 'A');
	}

	void WarsPacWriteDependencies(WarsPacWriter *writer, vector<WarsPacDependency> *dependencies,
		int compressed, vector<WarsPacStringPatch> *strings, vector<uint64_t> *offsets,
		vector<size_t> *dependency_data_addresses) {
		if (!dependencies->size()) return;

		writer->writeU64(dependencies->size());
		size_t data_address = writer->getAddress();
		writer->writeU64(writer->getAddress() + 8);
		offsets->push_back(data_address);

		if (!compressed) {
			for (size_t i=0; i<dependencies->size(); i++) {
				WarsPacStringPatch patch;
				patch.value = (*dependencies)[i].name;
				patch.address = writer->getAddress();

				writer->writeU64(0);
				strings->push_back(patch);
			}

			return;
		}

		vector<size_t> name_addresses;
		vector<size_t> chunk_addresses;

		for (size_t i=0; i<dependencies->size(); i++) {
			name_addresses.push_back(writer->getAddress());
			writer->writeU64(0);
			writer->writeU32((*dependencies)[i].compressed_size);
			writer->writeU32((*dependencies)[i].uncompressed_size);
			dependency_data_addresses->push_back(writer->getAddress());
			writer->writeU32(0);
			writer->writeU32((unsigned int) (*dependencies)[i].chunks.size());
			chunk_addresses.push_back(writer->getAddress());
			writer->writeU64(0);
		}

		for (size_t i=0; i<dependencies->size(); i++) {
			if ((*dependencies)[i].name.size()) {
				WarsPacStringPatch patch;
				patch.value = (*dependencies)[i].name;
				patch.address = name_addresses[i];
				strings->push_back(patch);
			}

			WarsPacPatchOffset(writer, chunk_addresses[i], writer->getAddress(), offsets);
			for (size_t j=0; j<(*dependencies)[i].chunks.size(); j++) {
				writer->writeU32((*dependencies)[i].chunks[j].compressed_size);
				writer->writeU32((*dependencies)[i].chunks[j].uncompressed_size);
			}
		}
	}

	WarsPacData WarsPacWriteV3(vector<WarsPacFile *> *files, unsigned short split_index,
		int version, unsigned int uid, unsigned short type_flags, vector<WarsPacDependency> *dependencies,
		int lz4_dependencies) {
		WarsPacData result;
		WarsPacWriter writer;
		vector<uint64_t> offsets;
		vector<WarsPacStringPatch> strings;
		vector<WarsPacEntryPatch> entry_patches;
		vector<WarsPacDataPatch> data_patches;
		vector<vector<unsigned int> > groups;
		vector<string> types;

		WarsPacBuildGroups(files, split_index, &groups, &types);

		if (version >= 405) writer.writeU32(0);
		else writer.writeString("PACx");

		writer.writeVersion(version);
		writer.writeU32(uid);
		writer.writeNull(28);
		writer.writeU16(type_flags);
		writer.writeU16(8);
		writer.writeU32(0);

		size_t trees_address = writer.getAddress();
		unsigned int type_count = (unsigned int) groups.size();
		WarsPacRadixTree type_tree;
		vector<WarsPacRadixTree *> file_trees;

		for (unsigned int i=0; i<type_count; i++) {
			WarsPacRadixTree *file_tree = new WarsPacRadixTree();
			type_tree.insert(types[i], i);
			file_tree->data_addresses.resize(groups[i].size());

			for (size_t j=0; j<groups[i].size(); j++) {
				WarsPacFile *file = (*files)[groups[i][j]];
				file_tree->insert(file->name, (int)j);
			}

			file_trees.push_back(file_tree);
		}

		type_tree.data_addresses.resize(type_count);
		type_tree.writeNodes(&writer, &strings, &offsets);

		for (size_t i=0; i<type_tree.data_order.size(); i++) {
			unsigned int group_index = (unsigned int) type_tree.data_order[i];
			size_t file_tree_address = writer.getAddress();
			WarsPacPatchOffset(&writer, type_tree.data_addresses[group_index], file_tree_address, &offsets);
			file_trees[group_index]->writeNodes(&writer, &strings, &offsets);
		}

		type_tree.writeDataIndices(&writer, &offsets);

		for (size_t i=0; i<type_tree.data_order.size(); i++) {
			unsigned int group_index = (unsigned int) type_tree.data_order[i];
			file_trees[group_index]->writeDataIndices(&writer, &offsets);
		}

		type_tree.writeChildIndices(&writer, &offsets);

		for (size_t i=0; i<type_tree.data_order.size(); i++) {
			unsigned int group_index = (unsigned int) type_tree.data_order[i];
			file_trees[group_index]->writeChildIndices(&writer, &offsets);
		}

		for (size_t i=0; i<type_tree.data_order.size(); i++) {
			unsigned int group_index = (unsigned int) type_tree.data_order[i];
			WarsPacRadixTree *file_tree = file_trees[group_index];

			for (size_t j=0; j<file_tree->data_order.size(); j++) {
				int file_index = file_tree->data_order[j];

				WarsPacEntryPatch entry_patch;
				entry_patch.index = groups[group_index][file_index];
				entry_patch.address = file_tree->data_addresses[file_index];
				entry_patches.push_back(entry_patch);
			}
		}

		for (size_t i=0; i<file_trees.size(); i++) {
			delete file_trees[i];
		}

		size_t dependency_table_address = writer.getAddress();
		WarsPacWriteDependencies(&writer, dependencies, lz4_dependencies, &strings, &offsets, &result.dependency_data_addresses);

		size_t data_entries_address = writer.getAddress();
		for (size_t i=0; i<entry_patches.size(); i++) {
			WarsPacFile *file = (*files)[entry_patches[i].index];
			int is_here = WarsPacEntryIsHere(file, split_index);
			unsigned short flags = is_here ? 0 : 1;
			int file_split_index = (version >= 405) ? file->split_index : 0;

			if (is_here && WarsPacEntryHasBina(file)) flags |= 2;
			if (version >= 405) flags |= 4;

			size_t data_entry_address = writer.getAddress();
			WarsPacPatchOffset(&writer, entry_patches[i].address, data_entry_address, &offsets);

			writer.writeU32((version >= 400) ? (is_here ? (uid + 0x1000 + (unsigned int)i) : 0) : uid);
			writer.writeU32((unsigned int) file->data.size());
			writer.writeU64(0);

			WarsPacDataPatch data_patch;
			data_patch.index = entry_patches[i].index;
			data_patch.address = writer.getAddress();
			data_patches.push_back(data_patch);
			writer.writeU64(0);
			writer.writeU64(0);

			WarsPacStringPatch ext_patch;
			ext_patch.value = file->extension;
			ext_patch.address = writer.getAddress();
			writer.writeU64(0);
			strings.push_back(ext_patch);

			writer.writeU16(flags);
			writer.writeS16(file_split_index);
			writer.writeU32(0);
		}

		size_t string_table_address = writer.getAddress();
		WarsPacWriteStrings(&writer, &strings, &offsets);

		size_t file_data_address = writer.getAddress();
		for (size_t i=0; i<data_patches.size(); i++) {
			WarsPacFile *file = (*files)[data_patches[i].index];
			if (!WarsPacEntryIsHere(file, split_index)) continue;

			writer.fixPadding(LIBGENS_WARS_PAC_ALIGNMENT);
			WarsPacPatchOffset(&writer, data_patches[i].address, writer.getAddress(), &offsets);

			if (file->data.size()) {
				writer.write(&file->data[0], file->data.size());
			}
		}

		writer.fixPadding(8);
		size_t offset_table_address = writer.getAddress();
		WarsPacWriteOffsetTable(&writer, offsets, 0);
		writer.fixPadding(8);

		size_t end_address = writer.getAddress();
		writer.writeFixedInt(12, (unsigned int) end_address);
		writer.writeFixedInt(16, (unsigned int)(dependency_table_address - trees_address));
		writer.writeFixedInt(20, (unsigned int)(data_entries_address - dependency_table_address));
		writer.writeFixedInt(24, (unsigned int)(string_table_address - data_entries_address));
		writer.writeFixedInt(28, (unsigned int)(file_data_address - string_table_address));
		writer.writeFixedInt(32, (unsigned int)(offset_table_address - file_data_address));
		writer.writeFixedInt(36, (unsigned int)(end_address - offset_table_address));
		writer.writeFixedInt(44, (unsigned int) dependencies->size());

		result.data.swap(writer.data);
		return result;
	}

	int WarsPacCompressLz4(vector<unsigned char> *source, vector<unsigned char> *dest, vector<WarsPacChunk> *chunks) {
		dest->clear();
		chunks->clear();

		size_t source_address = 0;
		while (source_address < source->size()) {
			size_t chunk_size = source->size() - source_address;
			if (chunk_size > LIBGENS_WARS_PAC_LZ4_CHUNK_SIZE) chunk_size = LIBGENS_WARS_PAC_LZ4_CHUNK_SIZE;

			int bound = LZ4_compressBound((int) chunk_size);
			size_t dest_address = dest->size();
			dest->resize(dest_address + bound);

			int compressed_size = LZ4_compress_default(
				(const char *) &(*source)[source_address],
				(char *) &(*dest)[dest_address],
				(int) chunk_size, bound);

			if (compressed_size <= 0) return 0;

			dest->resize(dest_address + compressed_size);

			WarsPacChunk chunk;
			chunk.compressed_size = (unsigned int) compressed_size;
			chunk.uncompressed_size = (unsigned int) chunk_size;
			chunks->push_back(chunk);
			source_address += chunk_size;
		}

		return 1;
	}

	string WarsPacSplitName(string filename, unsigned int index) {
		char suffix[16];
		sprintf(suffix, ".%03u", index);
		return filename + ToString(suffix);
	}

	void WarsPacSaveWars(vector<WarsPacFile *> *files, unsigned short split_count, string filename, unsigned int uid) {
		vector<WarsPacDependency> dependencies;
		string base_name = File::nameFromFilename(filename);

		for (unsigned int i=0; i<split_count; i++) {
			vector<WarsPacDependency> no_dependencies;
			WarsPacData split = WarsPacWriteV3(files, (unsigned short) i, 301, uid, 2, &no_dependencies, 0);
			WarsPacWriteFile(WarsPacSplitName(filename, i), &split.data);

			WarsPacDependency dependency;
			dependency.name = WarsPacSplitName(base_name, i);
			dependencies.push_back(dependency);
		}

		unsigned short type_flags = 1;
		if (split_count) type_flags |= 4;

		WarsPacData root = WarsPacWriteV3(files, 0xFFFF, 301, uid, type_flags, &dependencies, 0);
		WarsPacWriteFile(filename, &root.data);
	}

	void WarsPacSaveV4(vector<WarsPacFile *> *files, unsigned short split_count,
		string filename, unsigned int uid, int version, int internal_version) {
		vector<WarsPacDependency> dependencies;
		string base_name = File::nameFromFilename(filename);

		for (unsigned int i=0; i<split_count; i++) {
			vector<WarsPacDependency> no_dependencies;
			WarsPacData split = WarsPacWriteV3(files, (unsigned short) i, internal_version, uid, 2, &no_dependencies, 0);

			WarsPacDependency dependency;
			dependency.name = (version >= 405) ? "" : WarsPacSplitName(base_name, i);
			dependency.uncompressed_size = (unsigned int) split.data.size();
			if (!WarsPacCompressLz4(&split.data, &dependency.data, &dependency.chunks)) return;
			dependency.compressed_size = (unsigned int) dependency.data.size();
			dependencies.push_back(dependency);
		}

		unsigned short type_flags = 1 | 8;
		if (split_count) type_flags |= 4;

		WarsPacData root = WarsPacWriteV3(files, 0xFFFF, internal_version, uid, type_flags, &dependencies, 1);
		WarsPacWriter writer;

		writer.writeString("PACx");
		writer.writeVersion(version);
		writer.writeU32(uid);
		writer.writeNull(16);
		writer.writeU16(0x81);
		writer.writeU16(0x208);

		size_t metadata_address = writer.getAddress();
		writer.writeNull(16);

		size_t chunk_table_address = writer.getAddress();
		size_t root_chunk_count_address = writer.getAddress();
		writer.writeU32(0);
		size_t root_chunks_address = writer.getAddress();
		size_t root_chunk_count = (root.data.size() + LIBGENS_WARS_PAC_LZ4_CHUNK_SIZE - 1) / LIBGENS_WARS_PAC_LZ4_CHUNK_SIZE;
		writer.writeNull(root_chunk_count * 8);
		writer.fixPadding(8);

		size_t string_table_address = writer.getAddress();
		size_t offset_table_address = writer.getAddress();
		writer.fixPadding(8);
		size_t metadata_end_address = writer.getAddress();

		writer.writeFixedInt(metadata_address + 0, (unsigned int)(chunk_table_address - (metadata_address + 16)));
		writer.writeFixedInt(metadata_address + 4, (unsigned int)(string_table_address - chunk_table_address));
		writer.writeFixedInt(metadata_address + 8, (unsigned int)(offset_table_address - string_table_address));
		writer.writeFixedInt(metadata_address + 12, (unsigned int)(metadata_end_address - offset_table_address));

		writer.fixPadding(16);

		for (size_t i=0; i<dependencies.size(); i++) {
			if (i < root.dependency_data_addresses.size()) {
				uint64_t split_address = writer.getAddress();
				for (int j=0; j<4; j++) {
					root.data[root.dependency_data_addresses[i]+j] =
						(unsigned char)((split_address >> (j * 8)) & 0xFF);
				}
			}

			if (dependencies[i].data.size()) {
				writer.write(&dependencies[i].data[0], dependencies[i].data.size());
			}

			writer.fixPadding(16);
		}

		vector<unsigned char> compressed_root;
		vector<WarsPacChunk> root_chunks;
		if (!WarsPacCompressLz4(&root.data, &compressed_root, &root_chunks)) return;

		writer.writeFixedInt(root_chunk_count_address, (unsigned int) root_chunks.size());
		for (size_t i=0; i<root_chunks.size(); i++) {
			writer.writeFixedInt(root_chunks_address + i * 8 + 0, root_chunks[i].compressed_size);
			writer.writeFixedInt(root_chunks_address + i * 8 + 4, root_chunks[i].uncompressed_size);
		}

		size_t root_address = writer.getAddress();
		if (compressed_root.size()) {
			writer.write(&compressed_root[0], compressed_root.size());
		}

		size_t root_end_address = writer.getAddress();
		writer.fixPadding(16);
		size_t end_address = writer.getAddress();

		writer.writeFixedInt(12, (unsigned int) end_address);
		writer.writeFixedInt(16, (unsigned int) root_address);
		writer.writeFixedInt(20, (unsigned int)(root_end_address - root_address));
		writer.writeFixedInt(24, (unsigned int) root.data.size());

		WarsPacWriteFile(filename, &writer.data);
	}

	unsigned short WarsPacReadU16(vector<unsigned char> *data, size_t address) {
		if ((address + 2) > data->size()) return 0;
		return (unsigned short)((*data)[address] | ((*data)[address+1] << 8));
	}

	unsigned int WarsPacReadU32(vector<unsigned char> *data, size_t address) {
		if ((address + 4) > data->size()) return 0;
		return (unsigned int)(*data)[address] |
			((unsigned int)(*data)[address+1] << 8) |
			((unsigned int)(*data)[address+2] << 16) |
			((unsigned int)(*data)[address+3] << 24);
	}

	uint64_t WarsPacReadU64(vector<unsigned char> *data, size_t address) {
		if ((address + 8) > data->size()) return 0;

		uint64_t value = 0;
		for (int i=0; i<8; i++) {
			value |= ((uint64_t)(*data)[address+i]) << (i * 8);
		}

		return value;
	}

	string WarsPacReadString(vector<unsigned char> *data, uint64_t address) {
		if (address >= data->size()) return "";

		size_t string_address = (size_t) address;
		size_t string_end = string_address;
		while ((string_end < data->size()) && (*data)[string_end]) string_end++;

		return string((char *) &(*data)[string_address], string_end - string_address);
	}

	int WarsPacCopyRange(vector<unsigned char> *source, size_t address, size_t size, vector<unsigned char> *dest) {
		if ((address > source->size()) || (size > (source->size() - address))) return 0;

		dest->resize(size);
		if (size) memcpy(&(*dest)[0], &(*source)[address], size);
		return 1;
	}

	vector<WarsPacChunk> WarsPacReadChunks(vector<unsigned char> *data, size_t address, unsigned int count) {
		vector<WarsPacChunk> chunks;

		for (unsigned int i=0; i<count; i++) {
			size_t chunk_address = address + i * 8;
			if ((chunk_address + 8) > data->size()) break;

			WarsPacChunk chunk;
			chunk.compressed_size = WarsPacReadU32(data, chunk_address);
			chunk.uncompressed_size = WarsPacReadU32(data, chunk_address + 4);
			chunks.push_back(chunk);
		}

		return chunks;
	}

	int WarsPacDecompressLz4(vector<unsigned char> *source, size_t address,
		unsigned int compressed_size, unsigned int uncompressed_size,
		vector<WarsPacChunk> *chunks, vector<unsigned char> *dest) {
		if (compressed_size == uncompressed_size) {
			return WarsPacCopyRange(source, address, uncompressed_size, dest);
		}

		if ((address > source->size()) || (compressed_size > (source->size() - address))) return 0;

		dest->resize(uncompressed_size);
		size_t source_address = address;
		size_t dest_address = 0;

		for (size_t i=0; i<chunks->size(); i++) {
			if ((source_address + (*chunks)[i].compressed_size) > source->size()) return 0;
			if ((dest_address + (*chunks)[i].uncompressed_size) > dest->size()) return 0;

			int result = LZ4_decompress_safe(
				(const char *) &(*source)[source_address],
				(char *) &(*dest)[dest_address],
				(*chunks)[i].compressed_size,
				(*chunks)[i].uncompressed_size);

			if (result != (int)(*chunks)[i].uncompressed_size) return 0;

			source_address += (*chunks)[i].compressed_size;
			dest_address += (*chunks)[i].uncompressed_size;
		}

		return 1;
	}

	void WarsPacSaveExtractedFile(string folder, string name, string extension,
		vector<unsigned char> *pac, uint64_t data_address, unsigned int data_size) {
		if ((data_address > pac->size()) || (data_size > (pac->size() - (size_t)data_address))) return;

		string filename = folder + name;
		if (extension.size()) filename += "." + extension;

		WarsPacCreateDirectoryTree(File::folderFromFilename(filename));

		File file(filename, LIBGENS_FILE_WRITE_BINARY);
		if (!file.valid()) return;

		if (data_size) {
			file.write(&(*pac)[(size_t)data_address], data_size);
		}

		file.close();
	}

	void WarsPacParseFileNode(vector<unsigned char> *pac, size_t nodes_address,
		unsigned int node_count, unsigned int node_index, string *path_buffer, string folder) {
		if (node_index >= node_count) return;

		size_t node_address = nodes_address + node_index * 0x28;
		if ((node_address + 0x28) > pac->size()) return;

		uint64_t name_address = WarsPacReadU64(pac, node_address);
		uint64_t data_address = WarsPacReadU64(pac, node_address + 8);
		uint64_t child_address = WarsPacReadU64(pac, node_address + 16);
		unsigned short child_count = WarsPacReadU16(pac, node_address + 36);
		unsigned char has_data = (*pac)[node_address + 38];
		unsigned char buffer_index = (*pac)[node_address + 39];

		if (has_data) {
			if (!buffer_index) return;
			if ((data_address + 0x30) > pac->size()) return;

			unsigned int data_size = WarsPacReadU32(pac, (size_t)data_address + 4);
			uint64_t file_data_address = WarsPacReadU64(pac, (size_t)data_address + 16);
			uint64_t extension_address = WarsPacReadU64(pac, (size_t)data_address + 32);
			unsigned short flags = WarsPacReadU16(pac, (size_t)data_address + 40);

			if ((flags & 1) == 0) {
				string name = path_buffer->substr(0, buffer_index);
				string extension = WarsPacReadString(pac, extension_address);
				WarsPacSaveExtractedFile(folder, name, extension, pac, file_data_address, data_size);
			}
		}
		else if (name_address) {
			string name = WarsPacReadString(pac, name_address);
			if ((buffer_index + name.size()) <= 255) {
				if (path_buffer->size() < 256) path_buffer->resize(256);
				memcpy(&(*path_buffer)[buffer_index], name.data(), name.size());
			}
		}

		for (unsigned int i=0; i<child_count; i++) {
			size_t child_index_address = (size_t) child_address + i * 4;
			if ((child_index_address + 4) > pac->size()) return;
			WarsPacParseFileNode(pac, nodes_address, node_count,
				WarsPacReadU32(pac, child_index_address), path_buffer, folder);
		}
	}

	void WarsPacParseV3(vector<unsigned char> *pac, string folder) {
		if (pac->size() < 0x30) return;

		size_t type_tree_address = 0x30;
		unsigned int type_node_count = WarsPacReadU32(pac, type_tree_address);
		unsigned int type_data_count = WarsPacReadU32(pac, type_tree_address + 4);
		uint64_t type_nodes = WarsPacReadU64(pac, type_tree_address + 8);
		uint64_t type_data_indices = WarsPacReadU64(pac, type_tree_address + 16);

		for (unsigned int i=0; i<type_data_count; i++) {
			size_t index_address = (size_t) type_data_indices + i * 4;
			if ((index_address + 4) > pac->size()) return;

			unsigned int type_index = WarsPacReadU32(pac, index_address);
			if (type_index >= type_node_count) continue;

			size_t type_node = (size_t) type_nodes + type_index * 0x28;
			if ((type_node + 0x28) > pac->size()) continue;

			uint64_t file_tree = WarsPacReadU64(pac, type_node + 8);
			if ((file_tree + 0x18) > pac->size()) continue;

			unsigned int file_node_count = WarsPacReadU32(pac, (size_t) file_tree);
			uint64_t file_nodes = WarsPacReadU64(pac, (size_t) file_tree + 8);
			string path_buffer(256, 0);

			WarsPacParseFileNode(pac, (size_t) file_nodes, file_node_count, 0, &path_buffer, folder);
		}
	}

	vector<string> WarsPacReadV3Dependencies(vector<unsigned char> *pac) {
		vector<string> dependencies;
		if (pac->size() < 0x30) return dependencies;

		unsigned int trees_size = WarsPacReadU32(pac, 16);
		unsigned int dependency_count = WarsPacReadU32(pac, 44);
		if (!dependency_count) return dependencies;

		size_t dependency_table = 0x30 + trees_size;
		if ((dependency_table + 16) > pac->size()) return dependencies;

		uint64_t count = WarsPacReadU64(pac, dependency_table);
		uint64_t data_address = WarsPacReadU64(pac, dependency_table + 8);
		if (count > dependency_count) count = dependency_count;

		for (uint64_t i=0; i<count; i++) {
			size_t info_address = (size_t) data_address + (size_t) i * 8;
			if ((info_address + 8) > pac->size()) break;

			dependencies.push_back(WarsPacReadString(pac, WarsPacReadU64(pac, info_address)));
		}

		return dependencies;
	}

	void WarsPacExtractV4(vector<unsigned char> *pac, string folder) {
		if (pac->size() < 0x20) return;

		unsigned int root_address = WarsPacReadU32(pac, 16);
		unsigned int root_compressed_size = WarsPacReadU32(pac, 20);
		unsigned int root_uncompressed_size = WarsPacReadU32(pac, 24);
		unsigned short flags_v4 = WarsPacReadU16(pac, 28);
		unsigned short flags_v3 = WarsPacReadU16(pac, 30);

		vector<WarsPacChunk> root_chunks;
		if ((flags_v4 & 0x80) && (flags_v3 & 0x200) && (pac->size() >= 0x34)) {
			size_t metadata_address = 0x20;
			unsigned int parents_size = WarsPacReadU32(pac, metadata_address);
			size_t chunk_table = metadata_address + 0x10 + parents_size;
			unsigned int chunk_count = WarsPacReadU32(pac, chunk_table);
			root_chunks = WarsPacReadChunks(pac, chunk_table + 4, chunk_count);
		}

		vector<unsigned char> root;
		if (!WarsPacDecompressLz4(pac, root_address, root_compressed_size,
			root_uncompressed_size, &root_chunks, &root)) return;

		WarsPacParseV3(&root, folder);

		if ((flags_v3 & 0x200) == 0) return;

		unsigned int trees_size = WarsPacReadU32(&root, 16);
		unsigned int dependency_count = WarsPacReadU32(&root, 44);
		if (!dependency_count) return;

		size_t dependency_table = 0x30 + trees_size;
		if ((dependency_table + 16) > root.size()) return;

		uint64_t count = WarsPacReadU64(&root, dependency_table);
		uint64_t data_address = WarsPacReadU64(&root, dependency_table + 8);
		if (count > dependency_count) count = dependency_count;

		for (uint64_t i=0; i<count; i++) {
			size_t info_address = (size_t) data_address + (size_t) i * 0x20;
			if ((info_address + 0x20) > root.size()) break;

			unsigned int compressed_size = WarsPacReadU32(&root, info_address + 8);
			unsigned int uncompressed_size = WarsPacReadU32(&root, info_address + 12);
			unsigned int split_address = WarsPacReadU32(&root, info_address + 16);
			unsigned int chunk_count = WarsPacReadU32(&root, info_address + 20);
			uint64_t chunks_address = WarsPacReadU64(&root, info_address + 24);

			vector<WarsPacChunk> chunks = WarsPacReadChunks(&root, (size_t) chunks_address, chunk_count);
			vector<unsigned char> split;
			if (WarsPacDecompressLz4(pac, split_address, compressed_size, uncompressed_size, &chunks, &split)) {
				WarsPacParseV3(&split, folder);
			}
		}
	}

	WarsPac::WarsPac() {
		extensions = forces_exts;
		extension_count = sizeof(forces_exts) / sizeof(forces_exts[0]);
		version = 301;
		internal_version = 301;
		compressed = 0;
		source_filename = "";
	}

	WarsPac::WarsPac(string filename) {
		extensions = forces_exts;
		extension_count = sizeof(forces_exts) / sizeof(forces_exts[0]);
		version = 301;
		internal_version = 301;
		compressed = 0;
		readFile(filename);
	}
	WarsPac::~WarsPac() {
		for (size_t i=0; i<files.size(); i++) {
			delete files[i];
		}
	}

	void WarsPac::readFile(string filename) {
		source_filename = filename;
	}

	const WarsPacExtension *WarsPac::findExtension(string extension) {
		string lower_extension = WarsPacLowerString(extension);

		for (size_t i=0; i<extension_count; i++) {
			if (lower_extension == extensions[i].extension) return &extensions[i];
		}

		return NULL;
	}

	void WarsPac::addFile(string filename, string pac_name) {
		if (!File::check(filename)) return;

		string extension = WarsPacExtensionFromName(pac_name);
		const WarsPacExtension *extension_info = findExtension(extension);

		WarsPacFile *file = new WarsPacFile();
		file->filename = filename;
		file->name = WarsPacNameFromName(pac_name);
		file->extension = extension;
		file->type = extension_info ? extension_info->type : "ResRawData";
		file->split = extension_info ? extension_info->split : 0;
		file->split_index = 0xFFFF;

		if (!WarsPacReadFile(filename, &file->data)) {
			delete file;
			return;
		}

		files.push_back(file);
	}

	void WarsPac::addFolder(string folder, string relative_folder) {
		set<string> filenames;

		WIN32_FIND_DATA find_file_data;
		HANDLE find_handle = FindFirstFile((folder + relative_folder + "*.*").c_str(), &find_file_data);
		if (find_handle != INVALID_HANDLE_VALUE) {
			do {
				const char *name = find_file_data.cFileName;
				if (name[0] == '.') continue;

				filenames.insert(ToString(name));
			} while (FindNextFile(find_handle, &find_file_data) != 0);

			FindClose(find_handle);
		}

		for (set<string>::iterator it=filenames.begin(); it!=filenames.end(); it++) {
			string full_filename = folder + relative_folder + *it;
			string pac_name = relative_folder + *it;

			DWORD attributes = GetFileAttributes(full_filename.c_str());
			if ((attributes != INVALID_FILE_ATTRIBUTES) && (attributes & FILE_ATTRIBUTE_DIRECTORY)) {
				addFolder(folder, pac_name + "/");
			}
			else {
				addFile(full_filename, pac_name);
			}
		}
	}

	void WarsPac::addFolder(string folder) {
		addFolder(folder, "");
	}

	void WarsPac::splitFiles() {
		sort(files.begin(), files.end(), [](WarsPacFile *a, WarsPacFile *b) {
			string at = WarsPacLowerString(a->type);
			string bt = WarsPacLowerString(b->type);
			if (at != bt) return at < bt;

			string an = WarsPacLowerString(a->name);
			string bn = WarsPacLowerString(b->name);
			if (an != bn) return an < bn;

			return WarsPacLowerString(a->extension) < WarsPacLowerString(b->extension);
		});

		unsigned short split_count = 0;
		size_t current_size = 0;
		int has_split_file = 0;

		for (size_t i=0; i<files.size(); i++) {
			if (!files[i]->split) {
				files[i]->split_index = 0xFFFF;
				continue;
			}

			size_t aligned_size = (current_size + (LIBGENS_WARS_PAC_ALIGNMENT - 1)) & ~(size_t)(LIBGENS_WARS_PAC_ALIGNMENT - 1);
			if (has_split_file && ((aligned_size + files[i]->data.size()) > LIBGENS_WARS_PAC_SPLIT_BYTES_LIMIT)) {
				split_count++;
				current_size = 0;
				aligned_size = 0;
			}

			files[i]->split_index = split_count;
			current_size = aligned_size + files[i]->data.size();
			has_split_file = 1;
		}
	}

	void WarsPac::save(string filename) {
		splitFiles();

		unsigned short split_count = 0;
		for (size_t i=0; i<files.size(); i++) {
			if (files[i]->split_index != 0xFFFF) {
				if ((files[i]->split_index + 1) > split_count) {
					split_count = files[i]->split_index + 1;
				}
			}
		}

		unsigned int uid = WarsPacUid(filename);

		if (compressed) WarsPacSaveV4(&files, split_count, filename, uid, version, internal_version);
		else WarsPacSaveWars(&files, split_count, filename, uid);
	}

	void WarsPac::extract(string folder) {
		vector<unsigned char> pac;
		if (!WarsPacReadFile(source_filename, &pac)) return;
		if (pac.size() < 8) return;

		WarsPacCreateDirectoryTree(folder);

		if (memcmp(&pac[0], "PACx", 4)) {
			return;
		}

		if (pac[4] == '3') {
			WarsPacParseV3(&pac, folder);

			vector<string> dependencies = WarsPacReadV3Dependencies(&pac);
			string root_folder = File::folderFromFilename(source_filename);
			for (size_t i=0; i<dependencies.size(); i++) {
				vector<unsigned char> dependency;
				if (WarsPacReadFile(root_folder + dependencies[i], &dependency)) {
					WarsPacParseV3(&dependency, folder);
				}
			}
		}
		else if (pac[4] == '4') {
			WarsPacExtractV4(&pac, folder);
		}
	}
};
