//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "PointCloud.h"
#include <stdint.h>

namespace LibGens {
	#define LIBGENS_POINT_CLOUD_SIGNATURE_BINA   0x414E4942
	#define LIBGENS_POINT_CLOUD_SIGNATURE_DATA   0x41544144
	#define LIBGENS_POINT_CLOUD_SIGNATURE_IMAG   0x47414D49
	#define LIBGENS_POINT_CLOUD_SIGNATURE_CPIC   0x43495043

	class PointCloudWriter {
		public:
			vector<unsigned char> data;

			size_t getAddress() {
				return data.size();
			}

			void writeU8(unsigned char v) {
				data.push_back(v);
			}

			void writeU16(uint16_t v) {
				data.push_back((unsigned char)(v & 0xFF));
				data.push_back((unsigned char)((v >> 8) & 0xFF));
			}

			void writeU32(uint32_t v) {
				data.push_back((unsigned char)(v & 0xFF));
				data.push_back((unsigned char)((v >> 8) & 0xFF));
				data.push_back((unsigned char)((v >> 16) & 0xFF));
				data.push_back((unsigned char)((v >> 24) & 0xFF));
			}

			void writeU64(uint64_t v) {
				for (size_t i=0; i<8; i++) {
					data.push_back((unsigned char)((v >> (i * 8)) & 0xFF));
				}
			}

			void writeS32(int v) {
				writeU32((uint32_t)v);
			}

			void writeFloat(float v) {
				uint32_t value = 0;
				memcpy(&value, &v, sizeof(float));
				writeU32(value);
			}

			void writeString(const char *v) {
				while (*v) {
					writeU8((unsigned char)*v);
					v++;
				}

				writeU8(0);
			}

			void writeString(string *v) {
				writeString(v->c_str());
			}

			void writeVector3(Vector3 v) {
				writeFloat(v.x);
				writeFloat(v.y);
				writeFloat(v.z);
			}

			void writeNull(size_t size) {
				for (size_t i=0; i<size; i++) {
					writeU8(0);
				}
			}

			void fixPadding(size_t multiple) {
				size_t extra = multiple - (getAddress() % multiple);
				if (extra != multiple) {
					writeNull(extra);
				}
			}

			void writeData(vector<unsigned char> *v) {
				data.insert(data.end(), v->begin(), v->end());
			}

			void patchU32(size_t address, uint32_t v) {
				data[address] = (unsigned char)(v & 0xFF);
				data[address + 1] = (unsigned char)((v >> 8) & 0xFF);
				data[address + 2] = (unsigned char)((v >> 16) & 0xFF);
				data[address + 3] = (unsigned char)((v >> 24) & 0xFF);
			}

			void patchU64(size_t address, uint64_t v) {
				for (size_t i=0; i<8; i++) {
					data[address + i] = (unsigned char)((v >> (i * 8)) & 0xFF);
				}
			}
	};

	unsigned int PointCloudReadU32(vector<unsigned char> *data, size_t address) {
		if ((address + 4) > data->size()) return 0;
		return (unsigned int)(*data)[address] | ((unsigned int)(*data)[address + 1] << 8) | ((unsigned int)(*data)[address + 2] << 16) | ((unsigned int)(*data)[address + 3] << 24);
	}

	unsigned short PointCloudReadU16(vector<unsigned char> *data, size_t address) {
		if ((address + 2) > data->size()) return 0;
		return (unsigned short)((*data)[address] | ((*data)[address + 1] << 8));
	}

	uint64_t PointCloudReadU64(vector<unsigned char> *data, size_t address) {
		uint64_t value = 0;
		if ((address + 8) > data->size()) return 0;

		for (size_t i=0; i<8; i++) {
			value |= ((uint64_t)(*data)[address + i]) << (i * 8);
		}

		return value;
	}

	float PointCloudReadFloat(vector<unsigned char> *data, size_t address) {
		uint32_t value = PointCloudReadU32(data, address);
		float f = 0.0f;
		memcpy(&f, &value, sizeof(float));
		return f;
	}

	string PointCloudReadString(vector<unsigned char> *data, size_t address) {
		string value = "";
		if (!address || (address >= data->size())) return value;

		while ((address < data->size()) && (*data)[address]) {
			value += (char)(*data)[address];
			address++;
		}

		return value;
	}

	size_t PointCloudAlign(size_t address, size_t multiple) {
		size_t extra = multiple - (address % multiple);
		if (extra == multiple) return address;
		return address + extra;
	}

	void PointCloudWriteOffsetTable(PointCloudWriter *writer, vector<uint64_t> offsets) {
		uint64_t current_address = 0;
		std::sort(offsets.begin(), offsets.end());

		for (size_t i=0; i<offsets.size(); i++) {
			uint64_t difference = (offsets[i] - current_address) >> 2;
			if (difference > 0x3FFF) {
				writer->writeU8((unsigned char)(0xC0 | (difference >> 24)));
				writer->writeU8((unsigned char)(difference >> 16));
				writer->writeU8((unsigned char)(difference >> 8));
				writer->writeU8((unsigned char)(difference & 0xFF));
			}
			else if (difference > 0x3F) {
				writer->writeU8((unsigned char)(0x80 | (difference >> 8)));
				writer->writeU8((unsigned char)(difference & 0xFF));
			}
			else {
				writer->writeU8((unsigned char)(0x40 | difference));
			}

			current_address = offsets[i];
		}

		writer->fixPadding(4);
	}

	PointCloudInstance::PointCloudInstance() {
		name = "";
		resource_name = "";
		position = Vector3();
		rotation = Vector3();
		scale = Vector3(1.0f, 1.0f, 1.0f);
		field_28 = 1;
	}

	void PointCloudInstance::setName(string v) {
		name = v;
	}

	void PointCloudInstance::setResourceName(string v) {
		resource_name = v;
	}

	void PointCloudInstance::setPosition(Vector3 v) {
		position = v;
	}

	void PointCloudInstance::setRotation(Vector3 v) {
		rotation = v;
	}

	void PointCloudInstance::setScale(Vector3 v) {
		scale = v;
	}

	void PointCloudInstance::setField28(int v) {
		field_28 = v;
	}

	string PointCloudInstance::getName() {
		return name;
	}

	string PointCloudInstance::getResourceName() {
		return resource_name;
	}

	Vector3 PointCloudInstance::getPosition() {
		return position;
	}

	Vector3 PointCloudInstance::getRotation() {
		return rotation;
	}

	Vector3 PointCloudInstance::getScale() {
		return scale;
	}

	int PointCloudInstance::getField28() {
		return field_28;
	}

	PointCloud::PointCloud() {
		name = "";
		format_version = LIBGENS_POINT_CLOUD_FORMAT_VERSION_2;
	}

	PointCloud::PointCloud(string filename) {
		name = filename;
		format_version = LIBGENS_POINT_CLOUD_FORMAT_VERSION_2;

		size_t sep = name.find_last_of("\\/");
		if (sep != std::string::npos) {
			name = name.substr(sep + 1, name.size() - sep - 1);
		}

		size_t dot = name.find_last_of(".");
		if (dot != string::npos) {
			name = name.substr(0, dot);
		}

		File file(filename, LIBGENS_FILE_READ_BINARY);
		if (file.valid()) {
			read(&file);
			file.close();
		}
	}

	PointCloud::~PointCloud() {
		for (vector<PointCloudInstance *>::iterator it=instances.begin(); it!=instances.end(); it++) {
			delete *it;
		}

		instances.clear();
	}

	void PointCloud::read(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_POINT_CLOUD_ERROR_MESSAGE_NULL_FILE);
			return;
		}

		for (vector<PointCloudInstance *>::iterator it=instances.begin(); it!=instances.end(); it++) {
			delete *it;
		}
		instances.clear();

		size_t file_size = file->getFileSize();
		vector<unsigned char> data(file_size);
		file->goToAddress(0);
		file->read(data.data(), file_size);

		size_t data_address = 0;
		unsigned int signature = PointCloudReadU32(&data, 0);

		if (signature == LIBGENS_POINT_CLOUD_SIGNATURE_BINA) {
			unsigned short chunk_count = PointCloudReadU16(&data, 12);
			size_t chunk_address = 16;

			for (size_t i=0; i<chunk_count; i++) {
				unsigned int chunk_signature = PointCloudReadU32(&data, chunk_address);
				if ((chunk_signature == LIBGENS_POINT_CLOUD_SIGNATURE_DATA) || (chunk_signature == LIBGENS_POINT_CLOUD_SIGNATURE_IMAG)) {
					unsigned short chunk_data_offset = PointCloudReadU16(&data, chunk_address + 20);
					data_address = chunk_address + 24 + chunk_data_offset;
					break;
				}

				unsigned int chunk_size = PointCloudReadU32(&data, chunk_address + 4);
				if (!chunk_size) break;
				chunk_address += chunk_size - 4;
			}
		}
		else if (PointCloudReadU32(&data, 32) == LIBGENS_POINT_CLOUD_SIGNATURE_CPIC) {
			data_address = 32;
		}

		if (PointCloudReadU32(&data, data_address) != LIBGENS_POINT_CLOUD_SIGNATURE_CPIC) {
			Error::addMessage(Error::EXCEPTION, LIBGENS_POINT_CLOUD_ERROR_MESSAGE_INVALID_FILE);
			return;
		}

		format_version = PointCloudReadU32(&data, data_address + 4);
		size_t instances_address = data_address + (size_t)PointCloudReadU64(&data, data_address + 8);
		uint64_t instance_count = PointCloudReadU64(&data, data_address + 16);

		for (uint64_t i=0; i<instance_count; i++) {
			if ((instances_address + 60) > data.size()) break;

			PointCloudInstance *instance = new PointCloudInstance();
			instance->setName(PointCloudReadString(&data, data_address + (size_t)PointCloudReadU64(&data, instances_address)));
			instance->setResourceName(PointCloudReadString(&data, data_address + (size_t)PointCloudReadU64(&data, instances_address + 8)));
			instance->setPosition(Vector3(PointCloudReadFloat(&data, instances_address + 16), PointCloudReadFloat(&data, instances_address + 20), PointCloudReadFloat(&data, instances_address + 24)));
			instance->setRotation(Vector3(PointCloudReadFloat(&data, instances_address + 28), PointCloudReadFloat(&data, instances_address + 32), PointCloudReadFloat(&data, instances_address + 36)));
			instance->setField28((int)PointCloudReadU32(&data, instances_address + 40));
			instance->setScale(Vector3(PointCloudReadFloat(&data, instances_address + 44), PointCloudReadFloat(&data, instances_address + 48), PointCloudReadFloat(&data, instances_address + 52)));
			instances.push_back(instance);

			instances_address += 60;
			if (i != (instance_count - 1)) {
				instances_address = PointCloudAlign(instances_address, 8);
			}
		}
	}

	void PointCloud::save(string filename) {
		File file(filename, LIBGENS_FILE_WRITE_BINARY);

		if (file.valid()) {
			write(&file);
			file.close();
		}
	}

	void PointCloud::write(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_POINT_CLOUD_ERROR_MESSAGE_WRITE_NULL_FILE);
			return;
		}

		PointCloudWriter data_writer;
		vector<uint64_t> offsets;
		vector<size_t> name_offset_addresses;
		vector<size_t> resource_offset_addresses;

		data_writer.writeU32(LIBGENS_POINT_CLOUD_SIGNATURE_CPIC);
		data_writer.writeU32(format_version);
		size_t instances_offset_address = data_writer.getAddress();
		data_writer.writeU64(0);
		data_writer.writeU64(instances.size());
		offsets.push_back(instances_offset_address);

		data_writer.patchU64(instances_offset_address, data_writer.getAddress());

		for (size_t i=0; i<instances.size(); i++) {
			name_offset_addresses.push_back(data_writer.getAddress());
			data_writer.writeU64(0);
			offsets.push_back(name_offset_addresses.back());

			resource_offset_addresses.push_back(data_writer.getAddress());
			data_writer.writeU64(0);
			offsets.push_back(resource_offset_addresses.back());

			data_writer.writeVector3(instances[i]->getPosition());
			data_writer.writeVector3(instances[i]->getRotation());
			data_writer.writeS32(instances[i]->getField28());
			data_writer.writeVector3(instances[i]->getScale());
			data_writer.writeNull(4);

			if (i != (instances.size() - 1)) {
				data_writer.fixPadding(8);
			}
		}

		for (size_t i=0; i<instances.size(); i++) {
			data_writer.patchU64(name_offset_addresses[i], data_writer.getAddress());
			string instance_name = instances[i]->getName();
			data_writer.writeString(&instance_name);

			data_writer.patchU64(resource_offset_addresses[i], data_writer.getAddress());
			string resource_name = instances[i]->getResourceName();
			data_writer.writeString(&resource_name);
		}

		data_writer.fixPadding(4);
		size_t base_size = data_writer.getAddress();
		PointCloudWriteOffsetTable(&data_writer, offsets);

		PointCloudWriter writer;
		writer.writeU32(LIBGENS_POINT_CLOUD_SIGNATURE_BINA);
		writer.writeU8('2');
		writer.writeU8('1');
		writer.writeU8('0');
		writer.writeU8('L');

		size_t file_size_address = writer.getAddress();
		writer.writeU32(0);
		writer.writeU16(1);
		writer.fixPadding(4);

		writer.writeU32(LIBGENS_POINT_CLOUD_SIGNATURE_DATA);
		writer.writeU32((unsigned int)(data_writer.getAddress() + 0x34));
		writer.writeU32((unsigned int)base_size);
		writer.writeU32(0);
		writer.writeU32((unsigned int)(data_writer.getAddress() - base_size));
		writer.writeU16(0x18);
		writer.writeU16(0);
		writer.writeNull(24);
		writer.writeData(&data_writer.data);

		writer.patchU32(file_size_address, (unsigned int)writer.getAddress());

		file->write(writer.data.data(), writer.data.size());
	}

	void PointCloud::addInstance(PointCloudInstance *instance) {
		instances.push_back(instance);
	}

	vector<PointCloudInstance *> PointCloud::getInstances() {
		return instances;
	}

	void PointCloud::setName(string v) {
		name = v;
	}

	string PointCloud::getName() {
		return name;
	}

	void PointCloud::setFormatVersion(unsigned int v) {
		format_version = v;
	}

	unsigned int PointCloud::getFormatVersion() {
		return format_version;
	}
};
