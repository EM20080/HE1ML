//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "Bone.h"

namespace LibGens {
	Bone::Bone() {
		parent_index = 0xFFFFFFFF;
	}

	Bone::Bone(string name_p, unsigned int parent_index_p, Matrix4 matrix_p) {
		name = name_p;
		parent_index = parent_index_p;
		matrix = matrix_p;
	}

	void Bone::readDescription(File *file) {
		size_t name_address=0;
		file->readInt32BE(&parent_index);
		file->readInt32BEA(&name_address);

		file->goToAddress(name_address);
		file->readString(&name);
	}

	void Bone::readMatrix(File *file) {
		matrix.read(file);
	}

	void Bone::writeDescription(File *file) {
		size_t name_slot_address=0;
		size_t name_address=0;
		file->writeInt32BE(&parent_index);
		name_slot_address = file->writeNullAddress();
		name_address = file->getCurrentAddress();
		file->writeString(&name);
		file->fixPadding();
		file->goToAddress(name_slot_address);
		file->writeInt32BEA(&name_address);
		file->goToEnd();
	}

	void Bone::writeMatrix(File *file) {
		matrix.write(file);
	}

	string Bone::getName() {
		return name;
	}

	unsigned int Bone::getParentIndex() {
		return parent_index;
	}

	Matrix4 Bone::getMatrix() {
		return matrix;
	}
};
