//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#pragma once

#ifndef _M_X64
namespace LibGens {
	class HavokPropertyDatabaseEntry {
		protected:
			unsigned int key;
			unsigned int value;
		public:
			HavokPropertyDatabaseEntry(TiXmlElement *parent);
			unsigned int getKey();
			unsigned int getValue();
	};

	class HavokPropertyDatabaseGroup {
		protected:
			string name;
			list<HavokPropertyDatabaseEntry *> entries;
		public:
			HavokPropertyDatabaseGroup(TiXmlElement *parent);
			string getName();
			list<HavokPropertyDatabaseEntry *> getEntries();
			void applyProperties(hkpRigidBody *rigid_body);
	};

	class HavokPropertyDatabase {
		protected:
			list<HavokPropertyDatabaseGroup *> groups;
		public:
			HavokPropertyDatabase(string filename);
			void applyProperties(hkpRigidBody *rigid_body);
	};
};
#endif