//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "PXDSkeleton.h"

namespace LibGens {
	PXDSkeleton::PXDSkeleton() {
	}

	PXDSkeleton::PXDSkeleton(string filename) {
		File file(filename, LIBGENS_FILE_READ_BINARY);
		if (file.valid()) {
			name = File::nameFromFilenameNoExtension(filename);
			size_t dot_pos = name.find(".skl");
			if (dot_pos != string::npos) {
				name = name.substr(0, dot_pos);
			}
			read(&file);
			file.close();
		}
	}

	PXDSkeleton::~PXDSkeleton() {
	}

	void PXDSkeleton::read(File *file) {
		if (!file) {
			Error::addMessage(Error::NULL_REFERENCE, LIBGENS_PXD_SKELETON_ERROR_FILE);
			return;
		}

		const size_t data_start = LIBGENS_PXD_SKELETON_DATA_START;

		file->goToAddress(data_start);
		char magic[5] = {};
		file->read(magic, 4);
		if (string(magic) != LIBGENS_PXD_SKELETON_MAGIC) {
			Error::addMessage(Error::EXCEPTION, LIBGENS_PXD_SKELETON_ERROR_MAGIC);
			return;
		}

		unsigned int version = 0;
		file->readInt32(&version);
		if (version != LIBGENS_PXD_SKELETON_VERSION) {
			Error::addMessage(Error::EXCEPTION, LIBGENS_PXD_SKELETON_ERROR_VERSION);
			return;
		}

		file->goToAddress(data_start + 0x08);
		unsigned int parenting_offset_raw = 0;
		file->readInt32(&parenting_offset_raw);
		size_t parenting_offset = parenting_offset_raw + data_start;

		file->goToAddress(data_start + 0x10);
		unsigned int bone_count = 0;
		file->readInt32(&bone_count);

		file->goToAddress(data_start + 0x28);
		unsigned int name_table_offset_raw = 0;
		file->readInt32(&name_table_offset_raw);
		size_t name_table_offset = name_table_offset_raw + data_start;

		file->goToAddress(data_start + 0x48);
		unsigned int pos_offset_raw = 0;
		file->readInt32(&pos_offset_raw);
		size_t pos_offset = pos_offset_raw + data_start;

		bones.resize(bone_count);

		for (unsigned int i = 0; i < bone_count; i++) {
			file->goToAddress(parenting_offset + i * 2);
			short parent = 0;
			file->readInt16((unsigned short *)&parent);
			bones[i].parent_index = parent;

			file->goToAddress(name_table_offset + i * 0x10);
			unsigned int name_offset_raw = 0;
			file->readInt32(&name_offset_raw);
			size_t name_offset = name_offset_raw + data_start;
			file->goToAddress(name_offset);
			file->readString(&bones[i].name);

			file->goToAddress(pos_offset + i * 0x30);
			float px = 0, py = 0, pz = 0;
			file->readFloat32(&px);
			file->readFloat32(&py);
			file->readFloat32(&pz);
			bones[i].position = Vector3(px, py, pz);

			file->goToAddress(pos_offset + i * 0x30 + 0x10);
			float qx = 0, qy = 0, qz = 0, qw = 0;
			file->readFloat32(&qx);
			file->readFloat32(&qy);
			file->readFloat32(&qz);
			file->readFloat32(&qw);
			bones[i].rotation = Quaternion(qw, qx, qy, qz);

			file->goToAddress(pos_offset + i * 0x30 + 0x20);
			float sx = 0, sy = 0, sz = 0;
			file->readFloat32(&sx);
			file->readFloat32(&sy);
			file->readFloat32(&sz);
			bones[i].scale = Vector3(sx, sy, sz);
		}
	}

	vector<PXDBone> &PXDSkeleton::getBones() {
		return bones;
	}

	unsigned int PXDSkeleton::getBoneCount() {
		return (unsigned int)bones.size();
	}

	string PXDSkeleton::getName() {
		return name;
	}

	void PXDSkeleton::setName(string v) {
		name = v;
	}

	short PXDSkeleton::getBoneParentIndex(unsigned int index) {
		if (index < bones.size()) return bones[index].parent_index;
		return -1;
	}

	string PXDSkeleton::getBoneName(unsigned int index) {
		if (index < bones.size()) return bones[index].name;
		return "";
	}

	Vector3 PXDSkeleton::getBonePosition(unsigned int index) {
		if (index < bones.size()) return bones[index].position;
		return Vector3();
	}

	Quaternion PXDSkeleton::getBoneRotation(unsigned int index) {
		if (index < bones.size()) return bones[index].rotation;
		return Quaternion();
	}

	Vector3 PXDSkeleton::getBoneScale(unsigned int index) {
		if (index < bones.size()) return bones[index].scale;
		return Vector3(1.0f, 1.0f, 1.0f);
	}
};
