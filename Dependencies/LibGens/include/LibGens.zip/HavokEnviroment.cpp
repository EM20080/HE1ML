//=========================================================================
//	  Copyright (c) 2016 SonicGLvl
//
//    This file is part of SonicGLvl, a community-created free level editor 
//    for the PC version of Sonic Generations.
//
//    SonicGLvl is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    SonicGLvl is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//    
//
//    Read AUTHORS.txt, LICENSE.txt and COPYRIGHT.txt for more details.
//=========================================================================

#include "Havok.h"
#include "HavokEnviroment.h"
#include "HavokPhysicsCache.h"
#include "HavokSkeletonCache.h"
#include "HavokAnimationCache.h"
#include "HavokEndianSwap.h"
#include "File.h"
#include <cstdint>
#include <sstream>
#ifdef _M_X64
#include "spike/io/binreader_stream.hpp"
#endif

namespace LibGens {
	void HavokEnviroment::addFolder(string folder) {
		bool found = false;
		for (list<string>::iterator it=search_paths.begin(); it!=search_paths.end(); it++) {
			if ((*it) == folder) {
				found = true;
				break;
			}
		}

		if (!found) {
			search_paths.push_back(folder);
		}
	}

	HavokEnviroment::HavokEnviroment(int bufferSize) {
#ifndef _M_X64
#ifdef HAVOK_5_5_0
		hkMemoryBlockServer* server = new hkSystemMemoryBlockServer(256 * 1024 * 1024);
		hkMemory* memoryManager = new hkFreeListMemory(server);
		hkThreadMemory* threadMemory = new hkThreadMemory(memoryManager, 16);
		threadMemory->setStackArea(new uint8_t[1024 * 1024], 1024 * 1024);

		hkBaseSystem::init(memoryManager, threadMemory, HavokErrorReport);
#else
		hkMemoryRouter * memoryRouter = hkMemoryInitUtil::initDefault( hkMallocAllocator::m_defaultMallocAllocator, hkMemorySystem::FrameInfo(bufferSize));
		hkBaseSystem::init(memoryRouter, HavokErrorReport);
#endif
#endif
	}

#ifdef _M_X64
	static IhkPackFile* loadHKXLib(const std::string& filename) {
		const vector<unsigned char>* memory_data = LibGens::File::getMemoryFileData(filename);
		if (memory_data) {
			try {
				string buffer(reinterpret_cast<const char*>(memory_data->data()), memory_data->size());
				std::istringstream stream(buffer, std::ios::binary | std::ios::in);
				BinReaderRef_e reader(stream);
				auto packFile = IhkPackFile::Create(reader);
				if (!packFile) {
					Error::addMessage(Error::FILE_NOT_FOUND, "Couldn't load " + filename + ".");
					return nullptr;
				}
				return packFile.release();
			}
			catch (const std::exception& e) {
				Error::addMessage(Error::FILE_NOT_FOUND, "Couldn't load " + filename + ". Reason: " + string(e.what()));
				return nullptr;
			}
		}

		try {
			auto packFile = IhkPackFile::Create(filename);
			if (!packFile) {
				Error::addMessage(Error::FILE_NOT_FOUND, "Couldn't load " + filename + " Havok file with HavokLib.");
				return nullptr;
			}
			return packFile.release();
		}
		catch (const std::exception& e) {
			Error::addMessage(Error::FILE_NOT_FOUND, "Couldn't load " + filename + " Havok file. Reason: " + string(e.what()));
			return nullptr;
		}
	}
#else
#ifndef HAVOK_5_5_0
	static hkResource* loadHKX(const std::string& filename) {
		hkSerializeUtil::ErrorDetails load_error;
		hkResource* data = hkSerializeUtil::load(filename.c_str(), &load_error);

		if (load_error.id == load_error.ERRORID_PACKFILE_PLATFORM) {
			if (data != NULL) {
				data->removeReference();
			}

			LibGens::File *file = new LibGens::File(filename, "rb");
			if (file && file->valid()) {
				vector<unsigned char> result = endianSwapHKX(file);
				file->close();
				delete file;
				file = NULL;

				load_error = {};
				data = hkSerializeUtil::load(result.data(), result.size(), &load_error);
			}
			if (file) {
				delete file;
			}
		}

		if (load_error.id != load_error.ERRORID_NONE) {
			if (data != NULL) {
				data->removeReference();
			}

			Error::addMessage(Error::FILE_NOT_FOUND, "Couldn't load " + filename + " Havok file. Reason: " + ToString(load_error.defaultMessage.cString()));
			return NULL;
		}

		return data;
	}
#endif
#endif

	HavokPhysicsCache *HavokEnviroment::getPhysics(string physics_name) {
#if !defined(_M_X64) && defined(HAVOK_5_5_0)
		(void)physics_name;
		return NULL;
#else

		for (list<HavokPhysicsCache *>::iterator it=physics_cache.begin(); it!=physics_cache.end(); it++) {
			if ((*it)->getName() == physics_name) {
				return (*it);
			}
		}

		for (list<string>::iterator it=search_paths.begin(); it!=search_paths.end(); it++) {
			string filename=(*it) + physics_name + LIBGENS_HAVOK_PHYSICS_EXTENSION;

			if (File::check(filename)) {
#ifdef _M_X64
				IhkPackFile* packFile = loadHKXLib(filename);
				if (packFile) {
					auto classes = packFile->GetClasses(JenHash("hkpPhysicsData"));
					if (!classes.empty()) {
					hkpPhysicsData* physics = reinterpret_cast<hkpPhysicsData*>(const_cast<IhkVirtualClass*>(classes[0]));
						if (physics) {
							HavokPhysicsCache* physics_cache_entry = new HavokPhysicsCache(packFile, filename, physics_name, physics);
							physics_cache.push_back(physics_cache_entry);
							return physics_cache_entry;
						}
					}
				}
#else
				hkResource* data = loadHKX(filename);

				if (data) {
					hkRootLevelContainer* container = data->getContents<hkRootLevelContainer>();
					if (container) {
						hkpPhysicsData* physics = container->findObject<hkpPhysicsData>();

						if (physics) {
							HavokPhysicsCache* physics_cache_entry = new HavokPhysicsCache(data, filename, physics_name, physics);
							physics_cache.push_back(physics_cache_entry);
							return physics_cache_entry;
						}
					}
				}
#endif
			}
		}

		return NULL;
#endif
	}

	HavokSkeletonCache *HavokEnviroment::getSkeleton(string skeleton_name) {
#if !defined(_M_X64) && defined(HAVOK_5_5_0)
		(void)skeleton_name;
		return NULL;
#else
		for (list<HavokSkeletonCache *>::iterator it=skeleton_cache.begin(); it!=skeleton_cache.end(); it++) {
			if ((*it)->getName() == skeleton_name) {
				return (*it);
			}
		}

		if (File::check(skeleton_name)) {
			string filename = skeleton_name;
#ifdef _M_X64
				IhkPackFile* packFile = loadHKXLib(filename);
				if (packFile) {
					auto classes = packFile->GetClasses(JenHash("hkaAnimationContainer"));
					if (!classes.empty()) {
						const hkaAnimationContainer* animations = static_cast<const hkaAnimationContainer*>(classes[0]);
						if (animations && animations->GetNumSkeletons() > 0) {
							hkaSkeleton* skeleton = const_cast<hkaSkeleton*>(animations->GetSkeleton(0));
							if (skeleton) {
								HavokSkeletonCache* skeleton_cache_entry = new HavokSkeletonCache(packFile, filename, skeleton_name, skeleton);
								skeleton_cache.push_back(skeleton_cache_entry);
								return skeleton_cache_entry;
							}
						}
					}

					auto skeleton_classes = packFile->GetClasses(JenHash("hkaSkeleton"));
					if (!skeleton_classes.empty()) {
						hkaSkeleton* skeleton = reinterpret_cast<hkaSkeleton*>(const_cast<IhkVirtualClass*>(skeleton_classes[0]));
						if (skeleton) {
							HavokSkeletonCache* skeleton_cache_entry = new HavokSkeletonCache(packFile, filename, skeleton_name, skeleton);
							skeleton_cache.push_back(skeleton_cache_entry);
							return skeleton_cache_entry;
						}
					}
				}
#else
				hkResource* data = loadHKX(filename);
				hkRootLevelContainer *container = data->getContents<hkRootLevelContainer>();
				if (container) {
					hkaAnimationContainer *animations = container->findObject<hkaAnimationContainer>();
					if (animations) {
						for (int i=0; i<animations->m_skeletons.getSize(); i++) {
							hkaSkeleton *skeleton=animations->m_skeletons[i];
							if (skeleton) {
								HavokSkeletonCache *skeleton_cache_entry = new HavokSkeletonCache(data, filename, skeleton_name, skeleton);
								skeleton_cache.push_back(skeleton_cache_entry);
								return skeleton_cache_entry;
							}
						}
					}
				}
#endif
		}

		for (list<string>::iterator it=search_paths.begin(); it!=search_paths.end(); it++) {
			string filename=(*it) + skeleton_name + LIBGENS_HAVOK_SKELETON_EXTENSION;

			if (File::check(filename)) {
#ifdef _M_X64
				IhkPackFile* packFile = loadHKXLib(filename);
				if (packFile) {
					auto classes = packFile->GetClasses(JenHash("hkaAnimationContainer"));
					if (!classes.empty()) {
						const hkaAnimationContainer* animations = static_cast<const hkaAnimationContainer*>(classes[0]);
						if (animations && animations->GetNumSkeletons() > 0) {
							hkaSkeleton* skeleton = const_cast<hkaSkeleton*>(animations->GetSkeleton(0));
							if (skeleton) {
								HavokSkeletonCache* skeleton_cache_entry = new HavokSkeletonCache(packFile, filename, skeleton_name, skeleton);
								skeleton_cache.push_back(skeleton_cache_entry);
								return skeleton_cache_entry;
							}
						}
					}

					auto skeleton_classes = packFile->GetClasses(JenHash("hkaSkeleton"));
					if (!skeleton_classes.empty()) {
						hkaSkeleton* skeleton = reinterpret_cast<hkaSkeleton*>(const_cast<IhkVirtualClass*>(skeleton_classes[0]));
						if (skeleton) {
							HavokSkeletonCache* skeleton_cache_entry = new HavokSkeletonCache(packFile, filename, skeleton_name, skeleton);
							skeleton_cache.push_back(skeleton_cache_entry);
							return skeleton_cache_entry;
						}
					}
				}
#else
				hkResource* data = loadHKX(filename);

				hkRootLevelContainer *container = data->getContents<hkRootLevelContainer>();
				if (container) {
					hkaAnimationContainer *animations = container->findObject<hkaAnimationContainer>();

					if (animations) {
						for (int i=0; i<animations->m_skeletons.getSize(); i++) {
							hkaSkeleton *skeleton=animations->m_skeletons[i];

							if (skeleton) {
								HavokSkeletonCache *skeleton_cache_entry = new HavokSkeletonCache(data, filename, skeleton_name, skeleton);
								skeleton_cache.push_back(skeleton_cache_entry);
								return skeleton_cache_entry;
							}
						}
					}
				}
#endif
			}
		}

		return NULL;
#endif
	}

	
	HavokAnimationCache *HavokEnviroment::getAnimation(string animation_name) {
#if !defined(_M_X64) && defined(HAVOK_5_5_0)
		(void)animation_name;
		return NULL;
#else
		for (list<HavokAnimationCache *>::iterator it=animation_cache.begin(); it!=animation_cache.end(); it++) {
			if ((*it)->getName() == animation_name) {
				return (*it);
			}
		}

		if (File::check(animation_name)) {
			string filename = animation_name;
#ifdef _M_X64
				IhkPackFile* packFile = loadHKXLib(filename);
				if (packFile) {
					auto classes = packFile->GetClasses(JenHash("hkaAnimationContainer"));
					if (!classes.empty()) {
						const hkaAnimationContainer* animations = static_cast<const hkaAnimationContainer*>(classes[0]);
						if (animations && animations->GetNumAnimations() > 0) {
							const hkaAnimation* animation = animations->GetAnimation(0);
							if (animation) {
								HavokAnimationCache* animation_cache_entry = new HavokAnimationCache(packFile, filename, animation_name, nullptr, const_cast<hkaAnimation*>(animation));
								animation_cache.push_back(animation_cache_entry);
								return animation_cache_entry;
							}
						}
					}

					auto animation_classes = packFile->GetClasses(JenHash("hkaAnimation"));
					if (!animation_classes.empty()) {
						hkaAnimation* animation = reinterpret_cast<hkaAnimation*>(const_cast<IhkVirtualClass*>(animation_classes[0]));
						if (animation) {
							auto binding_classes = packFile->GetClasses(JenHash("hkaAnimationBinding"));
							hkaAnimationBinding* binding = nullptr;
							if (!binding_classes.empty()) {
								binding = reinterpret_cast<hkaAnimationBinding*>(const_cast<IhkVirtualClass*>(binding_classes[0]));
							}

							HavokAnimationCache* animation_cache_entry = new HavokAnimationCache(packFile, filename, animation_name, binding, animation);
							animation_cache.push_back(animation_cache_entry);
							return animation_cache_entry;
						}
					}
				}
#else
#ifdef HAVOK_5_5_0
				hkResource* data = NULL;
				hkRootLevelContainer* container = loadHKX(filename, &data);
				if (container) {
					hkaAnimationContainer* animations = static_cast<hkaAnimationContainer*>(container->findObjectByType("hkaAnimationContainer"));
					if (animations) {
						for (int i=0; i<animations->m_bindings.getSize(); i++) {
							hkaAnimationBinding *animation_binding = animations->m_bindings[i];
							if (animation_binding) {
								HavokAnimationCache *animation_cache_entry = new HavokAnimationCache(data, filename, animation_name, animation_binding, animation_binding->m_animation);
								animation_cache.push_back(animation_cache_entry);
								return animation_cache_entry;
							}
						}
					}
				}
#else
				hkResource* data = loadHKX(filename);
				hkRootLevelContainer *container = data->getContents<hkRootLevelContainer>();
				if (container) {
					hkaAnimationContainer *animations = container->findObject<hkaAnimationContainer>();
					if (animations) {
						for (int i=0; i<animations->m_bindings.getSize(); i++) {
							hkaAnimationBinding *animation_binding=animations->m_bindings[i];
							if (animation_binding) {
								HavokAnimationCache *animation_cache_entry = new HavokAnimationCache(data, filename, animation_name, animation_binding, animation_binding->m_animation);
								animation_cache.push_back(animation_cache_entry);
								return animation_cache_entry;
							}
						}
					}
				}
#endif
#endif
		}

		for (list<string>::iterator it=search_paths.begin(); it!=search_paths.end(); it++) {
			string filename=(*it) + animation_name + LIBGENS_HAVOK_ANIMATION_EXTENSION;

			if (File::check(filename)) {
#ifdef _M_X64
				IhkPackFile* packFile = loadHKXLib(filename);
				if (packFile) {
					auto classes = packFile->GetClasses(JenHash("hkaAnimationContainer"));
					if (!classes.empty()) {
						const hkaAnimationContainer* animations = static_cast<const hkaAnimationContainer*>(classes[0]);
						if (animations && animations->GetNumAnimations() > 0) {
							const hkaAnimation* animation = animations->GetAnimation(0);
							if (animation) {
								HavokAnimationCache* animation_cache_entry = new HavokAnimationCache(packFile, filename, animation_name, nullptr, const_cast<hkaAnimation*>(animation));
								animation_cache.push_back(animation_cache_entry);
								return animation_cache_entry;
							}
						}
					}

					auto animation_classes = packFile->GetClasses(JenHash("hkaAnimation"));
					if (!animation_classes.empty()) {
						hkaAnimation* animation = reinterpret_cast<hkaAnimation*>(const_cast<IhkVirtualClass*>(animation_classes[0]));
						if (animation) {
							auto binding_classes = packFile->GetClasses(JenHash("hkaAnimationBinding"));
							hkaAnimationBinding* binding = nullptr;
							if (!binding_classes.empty()) {
								binding = reinterpret_cast<hkaAnimationBinding*>(const_cast<IhkVirtualClass*>(binding_classes[0]));
							}

							HavokAnimationCache* animation_cache_entry = new HavokAnimationCache(packFile, filename, animation_name, binding, animation);
							animation_cache.push_back(animation_cache_entry);
							return animation_cache_entry;
						}
					}
				}
#else
#ifdef HAVOK_5_5_0
				hkResource* data = NULL;
				hkRootLevelContainer* container = loadHKX(filename, &data);
				if (container) {
					hkaAnimationContainer* animations = static_cast<hkaAnimationContainer*>(container->findObjectByType("hkaAnimationContainer"));
					if (animations) {
						for (int i=0; i<animations->m_bindings.getSize(); i++) {
							hkaAnimationBinding *animation_binding = animations->m_bindings[i];
							if (animation_binding) {
								HavokAnimationCache *animation_cache_entry = new HavokAnimationCache(data, filename, animation_name, animation_binding, animation_binding->m_animation);
								animation_cache.push_back(animation_cache_entry);
								return animation_cache_entry;
							}
						}
					}
				}
#else
				hkResource* data = loadHKX(filename);

				hkRootLevelContainer *container = data->getContents<hkRootLevelContainer>();
				if (container) {
					hkaAnimationContainer *animations = container->findObject<hkaAnimationContainer>();

					if (animations) {
						for (int i=0; i<animations->m_bindings.getSize(); i++) {
							hkaAnimationBinding *animation_binding=animations->m_bindings[i];
							if (animation_binding) {
								HavokAnimationCache *animation_cache_entry = new HavokAnimationCache(data, filename, animation_name, animation_binding, animation_binding->m_animation);
								animation_cache.push_back(animation_cache_entry);
								return animation_cache_entry;
							}
						}
					}
				}
#endif
#endif
			}
		}

		return NULL;
#endif
	}

	bool HavokEnviroment::deletePhysicsEntry(string physics_name) {
#if !defined(_M_X64) && defined(HAVOK_5_5_0)
		(void)physics_name;
		return false;
#else
		for (list<HavokPhysicsCache *>::iterator it=physics_cache.begin(); it!=physics_cache.end(); it++) {
			if ((*it)->getName() == physics_name) {
				delete (*it);
				physics_cache.erase(it);
				return true;
			}
		}

		return false;
#endif
	}
};
